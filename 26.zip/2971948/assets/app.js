const client = ZAFClient.init();
let ticketsPlot = null;
let dailyPlotDetailed = null;
let monthlyPlotDetailed = null;
let comparisonPlot1 = null;
let comparisonPlot2 = null;
let hourlyComparisonPlot = null;
let monthlyComparisonPlot = null;
let updateIntervalId = null;

// Cache optimizado con índices pre-calculados
let ticketsCache = {
    data: [],
    lastFetch: null,
    cacheExpiry: 5 * 60 * 1000, // 5 minutos
    // Índices pre-calculados para búsquedas rápidas
    indices: {
        byDate: new Map(),      // Mapa fecha -> tickets
        byStatus: new Map(),    // Mapa status -> tickets
        byMonth: new Map(),     // Mapa mes -> tickets
        byYear: new Map(),      // Mapa año -> tickets
        byHour: new Map(),      // Mapa hora -> tickets
        byDay: new Map()        // Mapa día -> tickets
    },
    stats: {
        totalTickets: 0,
        dateRange: { min: null, max: null },
        statusDistribution: {},
        averagePerDay: 0,
        averagePerMonth: 0,
        lastCalculated: null
    }
};

// Flag para evitar múltiples llamadas simultáneas
let isFetchingTickets = false;

// Configuración de fechas por defecto
function setDefaultDates() {
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - 30);
    
    const dateInputs = ['startDate', 'endDate', 'startDate1', 'endDate1', 'startDate2', 'endDate2', 'startDateDetailed', 'endDateDetailed', 'startDateHourlyComp', 'endDateHourlyComp', 'startDateMonthlyComp', 'endDateMonthlyComp'];
    dateInputs.forEach(id => {
        const input = document.getElementById(id);
        if (input) {
            const dateValue = id.includes('start') ? startDate : endDate;
            input.value = dateValue.toISOString().split('T')[0];
        }
    });
}

// Función para alternar el modo oscuro
function toggleDarkMode() {
    document.body.classList.toggle('dark-mode');
    const isDarkMode = document.body.classList.contains('dark-mode');
    localStorage.setItem('darkMode', isDarkMode);
}

// Función para controlar la sincronización automática
function togglePeriodicUpdates() {
    const syncToggleButton = document.getElementById('syncToggle');
    if (updateIntervalId) {
        clearInterval(updateIntervalId);
        updateIntervalId = null;
        syncToggleButton.textContent = 'Iniciar Sincronización';
        console.log('Sincronización automática detenida.');
    } else {
        startPeriodicUpdates();
        syncToggleButton.textContent = 'Parar Sincronización';
        console.log('Sincronización automática iniciada.');
    }
}

// Función para cambiar de página
function changePage(pageId) {
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
    });
    document.querySelector(`[data-page="${pageId}"]`).classList.add('active');

    document.getElementById('dashboard-page').classList.toggle('d-none', pageId !== 'dashboard');
    document.getElementById('detailed-page').classList.toggle('d-none', pageId !== 'detailed');
    document.getElementById('comparison-page').classList.toggle('d-none', pageId !== 'comparison');

    if (pageId === 'comparison') {
        initComparisonPlots();
    } else if (pageId === 'detailed') {
        initDetailedPlots();
        updateDetailedAnalysis();
    }
}

// Crear versiones con debounce de las funciones de actualización
const debouncedUpdateTicketsData = debounce(updateTicketsData, 500);
const debouncedUpdateDashboard = debounce(updateDashboard, 500);
const debouncedUpdateDetailedAnalysis = debounce(updateDetailedAnalysis, 500);

// Inicializar la aplicación
async function init() {
    try {
        console.log('Iniciando aplicación...');
        setDefaultDates();
        if (localStorage.getItem('darkMode') === 'true') {
            document.body.classList.add('dark-mode');
        }

        // Event listeners para navegación
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                changePage(e.target.dataset.page);
            });
        });

        // Event listeners para botones
        document.getElementById('darkModeToggle').addEventListener('click', toggleDarkMode);
        document.getElementById('darkModeToggleDetailed').addEventListener('click', toggleDarkMode);
        document.getElementById('syncToggle').addEventListener('click', togglePeriodicUpdates);
        
        // Event listeners para filtros
        document.getElementById('applyFilter').addEventListener('click', async () => {
            const startDate = document.getElementById('startDate').value;
            const endDate = document.getElementById('endDate').value;
            
            if (!startDate || !endDate || new Date(startDate) > new Date(endDate)) {
                document.getElementById('date-filter-alert').classList.remove('d-none');
                return;
            }
            
            document.getElementById('date-filter-alert').classList.add('d-none');
            // Usar versiones con debounce para evitar múltiples llamadas
            await Promise.all([debouncedUpdateDashboard(), debouncedUpdateTicketsData()]);
        });

        document.getElementById('applyFilterDetailed').addEventListener('click', async () => {
            const startDate = document.getElementById('startDateDetailed').value;
            const endDate = document.getElementById('endDateDetailed').value;
            
            if (!startDate || !endDate || new Date(startDate) > new Date(endDate)) {
                document.getElementById('date-filter-alert-detailed').classList.remove('d-none');
                return;
            }
            
            document.getElementById('date-filter-alert-detailed').classList.add('d-none');
            await debouncedUpdateDetailedAnalysis();
        });

        // Event listeners para los botones de filtro de comparación (existentes y nuevos)
        document.querySelectorAll('.apply-filter').forEach(button => {
            button.addEventListener('click', async (e) => {
                const chartNum = e.target.dataset.chart;
                const type = e.target.dataset.type || 'daily'; // Por defecto es diario
                const startDate = document.getElementById(`startDate${chartNum}`).value;
                const endDate = document.getElementById(`endDate${chartNum}`).value;
                
                if (!startDate || !endDate || new Date(startDate) > new Date(endDate)) {
                    return;
                }
                
                // Actualizar el gráfico correspondiente según el número
                if (chartNum === '1') {
                    await updateComparisonChart(1, startDate, endDate, type);
                } else if (chartNum === '2') {
                    await updateComparisonChart(2, startDate, endDate, type);
                }
            });
        });

        document.querySelectorAll('.apply-filter-comp').forEach(button => {
            button.addEventListener('click', async (e) => {
                const chartType = e.target.dataset.chartType;
                const startDate = document.getElementById(`startDate${chartType}Comp`).value;
                const endDate = document.getElementById(`endDate${chartType}Comp`).value;

                if (!startDate || !endDate || new Date(startDate) > new Date(endDate)) {
                    return;
                }

                let plotInstance;
                let label;
                if (chartType === 'hourly') {
                    plotInstance = hourlyComparisonPlot;
                    label = 'Tickets por hora';
                } else if (chartType === 'monthly') {
                    plotInstance = monthlyComparisonPlot;
                    label = 'Tickets por mes';
                }

                if (plotInstance) {
                    await updateComparisonChartData(plotInstance, startDate, endDate, chartType, label);
                }
            });
        });

        console.log('Inicializando gráficos...');
        initTicketsPlot();
        
        console.log('Actualizando dashboard y datos iniciales...');
        await Promise.all([
            updateDashboard(),
            updateTicketsData()
        ]);
        
        console.log('Iniciando actualizaciones periódicas...');
        startPeriodicUpdates();
        document.getElementById('syncToggle').textContent = 'Parar Sincronización';

        console.log('Aplicación inicializada correctamente');
    } catch (error) {
        console.error('Error al inicializar la aplicación:', error);
    }
}

document.addEventListener('DOMContentLoaded', init);

// Inicializar gráfico de tickets
function initTicketsPlot() {
    console.log('Iniciando inicialización de gráficos...');
    
    const container = document.getElementById('realtimeTrend');
    
    console.log('Contenedores encontrados (Dashboard):', {
        realtime: !!container
    });

    if (!container) {
        console.error('No se encontró el contenedor del gráfico principal');
        return;
    }

    const baseOpts = {
        width: container.offsetWidth,
        height: 300,
        cursor: {
            show: true,
            sync: {
                key: "ticketSync"
            }
        },
        scales: {
            x: {
                time: true,
            },
            y: {
                auto: true,
            }
        },
        axes: [
            {
                stroke: "#03363d",
                grid: { show: true, stroke: "#d8dcde" },
                ticks: { show: true, stroke: "#03363d" },
                font: "12px Arial",
                values: (self, splits) => splits.map(s => {
                    const date = new Date(s * 1000);
                    const scale = document.getElementById('scaleDashboard').value; // Obtener la escala seleccionada para el dashboard
                    switch(scale) {
                        case 'hourly':
                            return new Intl.DateTimeFormat('es-EC', {
                                hour: 'numeric',
                                minute: 'numeric',
                                timeZone: 'America/Guayaquil'
                            }).format(date);
                        case 'daily':
                            return new Intl.DateTimeFormat('es-EC', {
                                month: 'short',
                                day: 'numeric',
                                timeZone: 'America/Guayaquil'
                            }).format(date);
                        case 'monthly':
                            return new Intl.DateTimeFormat('es-EC', {
                                month: 'long',
                                year: 'numeric',
                                timeZone: 'America/Guayaquil'
                            }).format(date);
                        case 'yearly':
                            return new Intl.DateTimeFormat('es-EC', {
                                year: 'numeric',
                                timeZone: 'America/Guayaquil'
                            }).format(date);
                    }
                }),
            },
            {
                stroke: "#03363d",
                grid: { show: true, stroke: "#d8dcde" },
                ticks: { show: true, stroke: "#03363d" },
                font: "12px Arial",
            }
        ]
    };

    try {
        console.log('Creando gráfico de tiempo real...');
        const opts = {
            ...baseOpts,
            title: "Tickets por Hora",
            series: [
                {},
                {
                    stroke: "#03363d",
                    width: 2,
                    fill: "rgba(3, 54, 61, 0.1)",
                    label: "Tickets reales",
                },
                {
                    label: "Límite superior",
                    stroke: "gold",
                    width: 2,
                    dash: [1, 5],
                }
            ]
        };
        ticketsPlot = new uPlot(opts, [[], []], container);
        console.log('Gráfico de tiempo real creado');

        // Inicializar con datos vacíos
        const emptyData = [[], []];
        ticketsPlot.setData(emptyData);

    } catch (error) {
        console.error('Error al crear los gráficos del dashboard:', error);
    }
}

// Inicializar gráficos de comparación
function initComparisonPlots() {
    console.log('Iniciando inicialización de gráficos de comparación...');

    const container1 = document.getElementById('chart1');
    const container2 = document.getElementById('chart2');

    // Destruir instancias de gráficos existentes si las hay
    if (comparisonPlot1) {
        comparisonPlot1.destroy();
        comparisonPlot1 = null;
    }
    if (comparisonPlot2) {
        comparisonPlot2.destroy();
        comparisonPlot2 = null;
    }

    console.log('Contenedores encontrados (Comparación):', {
        chart1: !!container1,
        chart2: !!container2
    });

    if (!container1 || !container2) {
        console.error('No se encontraron todos los contenedores necesarios para gráficos de comparación.');
        return;
    }

    const getBarColor = (value, maxValue) => {
        if (!Number.isFinite(maxValue) || maxValue <= 0) {
            maxValue = 1;
        }
        const percentage = value / maxValue;
        if (percentage < 0.33) return "#2196F3";
        if (percentage < 0.66) return "#4CAF50";
        return "#F44336";
    };

    const baseOpts = {
        width: container1.offsetWidth,
        height: 300,
        cursor: {
            show: true,
            sync: {
                key: "comparisonSync"
            }
        },
        scales: {
            x: {
                time: true,
            },
            y: {
                auto: true,
            }
        },
        axes: [
            {
                stroke: "#03363d",
                grid: { show: true, stroke: "#d8dcde" },
                ticks: { show: true, stroke: "#03363d" },
                font: "12px Arial",
                values: (self, splits) => splits.map(s => {
                    const date = new Date(s * 1000);
                    const scale = document.getElementById('scale1').value;
                    switch(scale) {
                        case 'daily':
                            return new Intl.DateTimeFormat('es-EC', {
                                month: 'short',
                                day: 'numeric',
                                timeZone: 'America/Guayaquil'
                            }).format(date);
                        case 'monthly':
                            return new Intl.DateTimeFormat('es-EC', {
                                month: 'long',
                                year: 'numeric',
                                timeZone: 'America/Guayaquil'
                            }).format(date);
                        case 'yearly':
                            return new Intl.DateTimeFormat('es-EC', {
                                year: 'numeric',
                                timeZone: 'America/Guayaquil'
                            }).format(date);
                    }
                }),
            },
            {
                stroke: "#03363d",
                grid: { show: true, stroke: "#d8dcde" },
                ticks: { show: true, stroke: "#03363d" },
                font: "12px Arial",
            }
        ],
        series: [
            {},
            {
                stroke: (u, seriesIdx, dataIdx) => {
                    const seriesData = (u && u.data && Array.isArray(u.data[seriesIdx])) ? u.data[seriesIdx] : [];
                    if (dataIdx < 0 || dataIdx >= seriesData.length) {
                        return "#CCCCCC";
                    }
                    const value = seriesData[dataIdx];
                    const maxValue = seriesData.length > 0 ? Math.max(...seriesData) : 1;
                    return getBarColor(value, maxValue);
                },
                width: 2,
                fill: (u, seriesIdx, dataIdx) => {
                    const seriesData = (u && u.data && Array.isArray(u.data[seriesIdx])) ? u.data[seriesIdx] : [];
                    if (dataIdx < 0 || dataIdx >= seriesData.length) {
                        return "#CCCCCC80";
                    }
                    const value = seriesData[dataIdx];
                    const maxValue = seriesData.length > 0 ? Math.max(...seriesData) : 1;
                    return getBarColor(value, maxValue) + "80";
                },
                points: { show: false },
            }
        ]
    };

    try {
        console.log('Creando gráfico de comparación 1...');
        comparisonPlot1 = new uPlot({
            ...baseOpts,
            title: "Gráfico 1",
            series: [{
                },
                {
                    ...baseOpts.series[1],
                    label: "Tickets",
                    paths: uPlot.paths.bars(),
                }]
        }, [[0,1],[0,0]], container1);
        console.log('Gráfico de comparación 1 creado:', comparisonPlot1);

        console.log('Creando gráfico de comparación 2...');
        comparisonPlot2 = new uPlot({
            ...baseOpts,
            title: "Gráfico 2",
            series: [{
                },
                {
                    ...baseOpts.series[1],
                    label: "Tickets",
                    paths: uPlot.paths.bars(),
                }]
        }, [[0,1],[0,0]], container2);
        console.log('Gráfico de comparación 2 creado:', comparisonPlot2);

        // Add resize listener for comparison plots
        window.addEventListener('resize', () => {
            if (comparisonPlot1 && container1) {
                comparisonPlot1.setSize({ width: container1.offsetWidth, height: 300 });
            }
            if (comparisonPlot2 && container2) {
                comparisonPlot2.setSize({ width: container2.offsetWidth, height: 300 });
            }
        });

    } catch (error) {
        console.error('Error al crear los gráficos de comparación:', error);
    }

    // Inicializar datos para los gráficos de comparación
    const startDate1 = document.getElementById('startDate1').value;
    const endDate1 = document.getElementById('endDate1').value;
    const startDate2 = document.getElementById('startDate2').value;
    const endDate2 = document.getElementById('endDate2').value;

    updateComparisonChart(1, startDate1, endDate1);
    updateComparisonChart(2, startDate2, endDate2);
}

// Actualizar gráfico de comparación (generalizado)
async function updateComparisonChartData(plotInstance, startDate, endDate, type, label) {
    try {
        console.log(`Actualizando gráfico de comparación (${type})...`);
        const tickets = await getTickets();
        const filteredTickets = tickets.filter(ticket => {
            const ticketDate = new Date(ticket.created_at);
            return ticketDate >= new Date(startDate) && ticketDate <= new Date(endDate + 'T23:59:59');
        });

        let data = {};
        let timestamps = [];
        let values = [];
        let start = new Date(startDate);
        let end = new Date(endDate + 'T23:59:59');

        if (type === 'daily') {
            filteredTickets.forEach(ticket => {
                const date = new Date(ticket.created_at);
                const dayKey = date.toISOString().split('T')[0];
                data[dayKey] = (data[dayKey] || 0) + 1;
            });

            for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
                const dayKey = d.toISOString().split('T')[0];
                timestamps.push(d.getTime() / 1000);
                values.push(data[dayKey] || 0);
            }
        } else if (type === 'hourly') {
            filteredTickets.forEach(ticket => {
                const date = new Date(ticket.created_at);
                const hourKey = date.toISOString().slice(0, 13);
                data[hourKey] = (data[hourKey] || 0) + 1;
            });
            for (let d = new Date(start); d <= end; d.setHours(d.getHours() + 1)) {
                const hourKey = d.toISOString().slice(0, 13);
                timestamps.push(d.getTime() / 1000);
                values.push(data[hourKey] || 0);
            }
        } else if (type === 'monthly') {
            filteredTickets.forEach(ticket => {
                const date = new Date(ticket.created_at);
                const monthKey = date.toISOString().slice(0, 7);
                data[monthKey] = (data[monthKey] || 0) + 1;
            });
            let currentMonth = new Date(start.getFullYear(), start.getMonth(), 1);
            while (currentMonth <= end) {
                const monthKey = currentMonth.toISOString().slice(0, 7);
                timestamps.push(currentMonth.getTime() / 1000);
                values.push(data[monthKey] || 0);
                currentMonth.setMonth(currentMonth.getMonth() + 1);
            }
        }

        if (plotInstance) {
            plotInstance.setData([timestamps, values]);
            // Actualizar la etiqueta de la serie si es necesario (para los gráficos de línea)
            if (type === 'hourly') {
                plotInstance.series[1].label = label;
            }
        } else {
            console.error(`La instancia del gráfico para ${type} no está inicializada.`);
        }

    } catch (error) {
        console.error(`Error al actualizar gráfico de comparación (${type}):`, error);
    }
}

// Función para analizar las diferencias entre dos conjuntos de datos
function analyzeDifferences(data1, data2) {
    const differences = {
        totalTickets1: data1.reduce((a, b) => a + b, 0),
        totalTickets2: data2.reduce((a, b) => a + b, 0),
        average1: data1.length > 0 ? data1.reduce((a, b) => a + b, 0) / data1.length : 0,
        average2: data2.length > 0 ? data2.reduce((a, b) => a + b, 0) / data2.length : 0,
        max1: Math.max(...data1),
        max2: Math.max(...data2),
        min1: Math.min(...data1),
        min2: Math.min(...data2)
    };

    const analysis = {
        totalDifference: differences.totalTickets1 - differences.totalTickets2,
        averageDifference: differences.average1 - differences.average2,
        maxDifference: differences.max1 - differences.max2,
        minDifference: differences.min1 - differences.min2,
        percentageChange: differences.totalTickets2 !== 0 ? 
            ((differences.totalTickets1 - differences.totalTickets2) / differences.totalTickets2 * 100) : 0
    };

    return {
        differences,
        analysis,
        interpretation: generateInterpretation(analysis)
    };
}

// Función para generar la interpretación de las diferencias
function generateInterpretation(analysis) {
    const interpretations = [];

    // Interpretación de la diferencia total
    if (Math.abs(analysis.totalDifference) > 0) {
        interpretations.push(
            `Diferencia total: ${analysis.totalDifference > 0 ? 'Aumento' : 'Disminución'} de ${Math.abs(analysis.totalDifference)} tickets ` +
            `(${analysis.percentageChange.toFixed(1)}% ${analysis.percentageChange > 0 ? 'más' : 'menos'} tickets)`
        );
    }

    // Interpretación de la diferencia promedio
    if (Math.abs(analysis.averageDifference) > 0) {
        interpretations.push(
            `Diferencia promedio: ${analysis.averageDifference > 0 ? 'Aumento' : 'Disminución'} de ${Math.abs(analysis.averageDifference).toFixed(1)} tickets por día`
        );
    }

    // Interpretación de la diferencia máxima
    if (Math.abs(analysis.maxDifference) > 0) {
        interpretations.push(
            `Diferencia en picos: ${analysis.maxDifference > 0 ? 'Aumento' : 'Disminución'} de ${Math.abs(analysis.maxDifference)} tickets en el día más ocupado`
        );
    }

    // Interpretación de la diferencia mínima
    if (Math.abs(analysis.minDifference) > 0) {
        interpretations.push(
            `Diferencia en días tranquilos: ${analysis.minDifference > 0 ? 'Aumento' : 'Disminución'} de ${Math.abs(analysis.minDifference)} tickets en el día menos ocupado`
        );
    }

    // Agregar conclusión general
    if (analysis.percentageChange > 10) {
        interpretations.push("Conclusión: Hay un cambio significativo en el volumen de tickets entre los períodos comparados.");
    } else if (analysis.percentageChange < -10) {
        interpretations.push("Conclusión: Hay una reducción notable en el volumen de tickets entre los períodos comparados.");
    } else {
        interpretations.push("Conclusión: El volumen de tickets se mantiene relativamente estable entre los períodos comparados.");
    }

    return interpretations;
}

// Actualizar gráfico de comparación (específico para los dos primeros gráficos diarios)
async function updateComparisonChart(chartNum, startDate, endDate, type) {
    try {
        console.log(`Actualizando gráfico de comparación ${type} ${chartNum}...`);
        const startTime = performance.now();
        
        const tickets = await getTickets();
        
        // Usar filtrado optimizado
        const filteredTickets = getFilteredTicketsOptimized(startDate, endDate);
        console.log(`Tickets filtrados para gráfico ${chartNum}:`, filteredTickets.length);

        const scale = document.getElementById(`scale${chartNum}`).value;

        // Usar agregación optimizada
        const aggregatedData = getAggregatedDataOptimized(filteredTickets, scale, startDate, endDate);

        const timestamps = Object.keys(aggregatedData).sort().map(key => {
            const date = parseKeyToDate(key, scale);
            return date.getTime() / 1000;
        });
        
        const values = Object.keys(aggregatedData).sort().map(key => aggregatedData[key]);

        // Asegurarse de que cada gráfico se actualice con sus propios datos
        if (chartNum === 1 && comparisonPlot1) {
            console.log('Actualizando gráfico 1 con datos específicos');
            comparisonPlot1.setData([timestamps, values]);
            window.chart1Data = values;
        } else if (chartNum === 2 && comparisonPlot2) {
            console.log('Actualizando gráfico 2 con datos específicos');
            comparisonPlot2.setData([timestamps, values]);
            window.chart2Data = values;
        } else {
            console.error(`La instancia del gráfico ${chartNum} no está inicializada.`);
        }

        // Actualizar el análisis de diferencias si ambos gráficos tienen datos
        if (window.chart1Data && window.chart2Data) {
            const analysis = analyzeDifferences(window.chart1Data, window.chart2Data);
            updateComparisonAnalysis(analysis);
        }

        const endTime = performance.now();
        console.log(`Gráfico de comparación ${chartNum} actualizado en ${(endTime - startTime).toFixed(2)}ms`);
        
    } catch (error) {
        console.error(`Error al actualizar gráfico de comparación ${type} ${chartNum}:`, error);
    }
}

// Función para actualizar el análisis de diferencias en la interfaz
function updateComparisonAnalysis(analysis) {
    const analysisContainer = document.getElementById('comparison-analysis');
    if (!analysisContainer) {
        console.error('No se encontró el contenedor de análisis de comparación');
        return;
    }

    // Crear el contenido HTML para el análisis
    const analysisHTML = `
        <div class="card mt-4">
            <div class="card-header">
                <h5 class="mb-0">Análisis de Diferencias</h5>
            </div>
            <div class="card-body">
                <ul class="list-group list-group-flush">
                    ${analysis.interpretation.map(interpretation => 
                        `<li class="list-group-item">${interpretation}</li>`
                    ).join('')}
                </ul>
            </div>
        </div>
    `;

    analysisContainer.innerHTML = analysisHTML;
}

// Funciones para mostrar/ocultar indicador de carga
function showLoadingIndicator() {
    const indicator = document.getElementById('loading-indicator');
    if (indicator) {
        indicator.classList.remove('d-none');
        indicator.style.display = 'flex';
    }
}

function hideLoadingIndicator() {
    const indicator = document.getElementById('loading-indicator');
    if (indicator) {
        indicator.classList.add('d-none');
        indicator.style.display = 'none';
    }
}

// Obtener tickets de Zendesk con paginación y cacheo
async function getTickets(forceRefresh = false) {
    try {
        // Verificar cache si no es un refresh forzado
        if (!forceRefresh && ticketsCache.data.length > 0 && ticketsCache.lastFetch) {
            const cacheAge = Date.now() - ticketsCache.lastFetch;
            if (cacheAge < ticketsCache.cacheExpiry) {
                console.log('Usando tickets del cache:', ticketsCache.data.length);
                return ticketsCache.data;
            }
        }

        // Evitar múltiples llamadas simultáneas
        if (isFetchingTickets) {
            console.log('Ya se están obteniendo tickets, esperando...');
            return ticketsCache.data; // Retornar cache mientras se actualiza
        }

        isFetchingTickets = true;
        
        // Mostrar indicador de carga solo en la primera carga o refresh forzado
        if (ticketsCache.data.length === 0 || forceRefresh) {
            showLoadingIndicator();
        }
        
        console.log('Obteniendo tickets de Zendesk...');

        let allTickets = [];
        let nextPage = '/api/v2/tickets.json?per_page=100'; // Comenzar con página 1
        let pageCount = 0;
        const maxPages = 100; // Límite de seguridad para evitar bucles infinitos

        while (nextPage && pageCount < maxPages) {
            try {
                console.log(`Obteniendo página ${pageCount + 1}...`);
                
                const response = await client.request({
                    url: nextPage,
                    type: 'GET',
                    contentType: 'application/json',
                    headers: {
                        'Accept': 'application/json'
                    }
                });

                if (response.tickets && Array.isArray(response.tickets)) {
                    allTickets = allTickets.concat(response.tickets);
                    console.log(`Página ${pageCount + 1}: ${response.tickets.length} tickets. Total: ${allTickets.length}`);
                }

                // Verificar si hay más páginas
                nextPage = response.next_page || null;
                pageCount++;

                // Pequeña pausa para no sobrecargar la API
                if (nextPage) {
                    await new Promise(resolve => setTimeout(resolve, 100));
                }

            } catch (pageError) {
                console.error(`Error en página ${pageCount + 1}:`, pageError);
                break; // Salir del bucle si hay error en una página
            }
        }

        console.log(`Total de tickets obtenidos: ${allTickets.length}`);

        // Actualizar cache y construir índices optimizados
        ticketsCache.data = allTickets;
        ticketsCache.lastFetch = Date.now();
        
        // Construir índices para búsquedas rápidas
        buildOptimizedIndices(allTickets);

        return allTickets;

    } catch (error) {
        console.error('Error al obtener tickets:', error);
        // En caso de error, retornar cache si existe
        return ticketsCache.data || [];
    } finally {
        isFetchingTickets = false;
        hideLoadingIndicator();
    }
}

// Función de debounce para evitar múltiples llamadas rápidas
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Procesar tickets en lotes para evitar bloquear la UI
function processTicketsInBatches(tickets, processorFunction, batchSize = 1000) {
    return new Promise((resolve) => {
        const results = [];
        let currentIndex = 0;

        function processBatch() {
            const batch = tickets.slice(currentIndex, currentIndex + batchSize);
            
            if (batch.length === 0) {
                resolve(results);
                return;
            }

            // Procesar lote actual
            const batchResults = processorFunction(batch);
            results.push(...batchResults);

            currentIndex += batchSize;

            // Usar setTimeout para no bloquear la UI
            setTimeout(processBatch, 0);
        }

        processBatch();
    });
}

// Actualizar datos del gráfico principal - optimizado
async function updateTicketsData() {
    try {
        console.log('Iniciando actualización de datos optimizada...');
        const startTime = performance.now();
        
        const startDate = document.getElementById('startDate').value;
        const endDate = document.getElementById('endDate').value;
        const scale = document.getElementById('scaleDashboard').value;
        
        // Mostrar indicador de carga
        const chartContainer = document.getElementById('realtimeTrend');
        if (chartContainer) {
            chartContainer.style.opacity = '0.5';
        }
        
        const tickets = await getTickets();
        console.log('Tickets obtenidos:', tickets.length);
        
        // Usar filtrado optimizado con índices
        const currentTickets = getFilteredTicketsOptimized(startDate, endDate);
        console.log('Tickets filtrados:', currentTickets.length);
        
        // Usar índices pre-calculados para agregación rápida
        const aggregatedData = getAggregatedDataOptimized(currentTickets, scale, startDate, endDate);

        const timestamps = Object.keys(aggregatedData).sort().map(key => {
            const date = parseKeyToDate(key, scale);
            return date.getTime() / 1000;
        });
        
        const values = Object.keys(aggregatedData).sort().map(key => aggregatedData[key]);
        const superiorLimitValues = new Array(values.length).fill(12);

        if (ticketsPlot) {
            const updateStart = performance.now();
            console.log(`Actualizando gráfico con ${values.length} puntos de datos...`);
            ticketsPlot.setData([timestamps, values, superiorLimitValues]);
            
            // Actualizar el título del gráfico
            let title = "";
            switch(scale) {
                case 'hourly': title = "Tickets por Hora"; break;
                case 'daily': title = "Tickets por Día"; break;
                case 'monthly': title = "Tickets por Mes"; break;
                case 'yearly': title = "Tickets por Año"; break;
            }
            if (ticketsPlot.setTitle) {
                ticketsPlot.setTitle(title);
            }
            
            const updateEnd = performance.now();
            console.log(`Gráfico actualizado en ${(updateEnd - updateStart).toFixed(2)}ms`);
        }

        // Restaurar opacidad
        if (chartContainer) {
            chartContainer.style.opacity = '1';
        }

        const endTime = performance.now();
        console.log(`Actualización completa en ${(endTime - startTime).toFixed(2)}ms`);
        
    } catch (error) {
        console.error('Error al actualizar datos del gráfico:', error);
        // Restaurar opacidad en caso de error
        const chartContainer = document.getElementById('realtimeTrend');
        if (chartContainer) {
            chartContainer.style.opacity = '1';
        }
    }
}

// Función optimizada para agregación de datos usando índices
function getAggregatedDataOptimized(tickets, scale, startDate, endDate) {
    const aggregatedData = {};
    const startDateObj = new Date(startDate);
    const endDateObj = new Date(endDate + 'T23:59:59');
    
    // Usar el índice apropiado según la escala
    let relevantIndex;
    switch(scale) {
        case 'hourly':
            relevantIndex = ticketsCache.indices.byHour;
            break;
        case 'daily':
            relevantIndex = ticketsCache.indices.byDate;
            break;
        case 'monthly':
            relevantIndex = ticketsCache.indices.byMonth;
            break;
        case 'yearly':
            relevantIndex = ticketsCache.indices.byYear;
            break;
        default:
            // Fallback al método tradicional
            return getAggregatedDataTraditional(tickets, scale);
    }
    
    // Generar todas las claves posibles en el rango de fechas
    const keys = generateDateKeys(startDateObj, endDateObj, scale);
    
    keys.forEach(key => {
        const ticketsForKey = relevantIndex.get(key);
        if (ticketsForKey) {
            // Filtrar por rango de fechas específico si es necesario
            const filteredTickets = ticketsForKey.filter(ticket => {
                const ticketDate = new Date(ticket.created_at);
                return ticketDate >= startDateObj && ticketDate <= endDateObj;
            });
            aggregatedData[key] = filteredTickets.length;
        } else {
            aggregatedData[key] = 0;
        }
    });
    
    return aggregatedData;
}

// Generar claves de fecha para un rango específico
function generateDateKeys(startDate, endDate, scale) {
    const keys = [];
    const current = new Date(startDate);
    
    switch(scale) {
        case 'hourly':
            while (current <= endDate) {
                keys.push(current.toISOString().slice(0, 13));
                current.setHours(current.getHours() + 1);
            }
            break;
        case 'daily':
            while (current <= endDate) {
                keys.push(current.toISOString().split('T')[0]);
                current.setDate(current.getDate() + 1);
            }
            break;
        case 'monthly':
            current.setDate(1); // Primer día del mes
            while (current <= endDate) {
                keys.push(current.toISOString().slice(0, 7));
                current.setMonth(current.getMonth() + 1);
            }
            break;
        case 'yearly':
            while (current.getFullYear() <= endDate.getFullYear()) {
                keys.push(current.getFullYear().toString());
                current.setFullYear(current.getFullYear() + 1);
            }
            break;
    }
    
    return keys;
}

// Convertir clave de fecha a objeto Date
function parseKeyToDate(key, scale) {
    switch(scale) {
        case 'hourly':
            return new Date(key + ':00:00');
        case 'daily':
            return new Date(key + 'T00:00:00');
        case 'monthly':
            return new Date(key + '-01T00:00:00');
        case 'yearly':
            return new Date(key + '-01-01T00:00:00');
        default:
            return new Date(key);
    }
}

// Método tradicional como fallback
function getAggregatedDataTraditional(tickets, scale) {
    const aggregatedData = {};
    
    tickets.forEach(ticket => {
        const date = new Date(ticket.created_at);
        let key;
        
        switch(scale) {
            case 'hourly':
                key = date.toISOString().slice(0, 13);
                break;
            case 'daily':
                key = date.toISOString().split('T')[0];
                break;
            case 'monthly':
                key = date.toISOString().slice(0, 7);
                break;
            case 'yearly':
                key = date.getFullYear().toString();
                break;
        }
        
        aggregatedData[key] = (aggregatedData[key] || 0) + 1;
    });
    
    return aggregatedData;
}

// Iniciar actualizaciones periódicas optimizadas
function startPeriodicUpdates() {
    // Actualizar inmediatamente con datos del cache si existen
    if (ticketsCache.data.length > 0) {
        debouncedUpdateTicketsData();
    } else {
        updateTicketsData(); // Primera carga completa
    }
    
    if (updateIntervalId) {
        clearInterval(updateIntervalId);
    }
    
    // Aumentar el intervalo a 10 minutos para reducir carga
    updateIntervalId = setInterval(() => {
        // Solo actualizar si la página está visible
        if (!document.hidden) {
            // Forzar refresh cada 10 minutos para obtener datos frescos
            getTickets(true).then(() => {
                debouncedUpdateTicketsData();
            });
        }
    }, 600000); // 10 minutos
}

// Optimizar la función de análisis de tickets
function analyzeTickets(tickets) {
    // Si hay muchos tickets, usar una muestra para métricas básicas
    const sampleSize = Math.min(tickets.length, 5000);
    const sample = tickets.length > sampleSize ? 
        tickets.slice(0, sampleSize) : tickets;
    
    const today = new Date().toISOString().split('T')[0];
    const totalTickets = tickets.length; // Usar el total real
    
    // Usar muestra para cálculos más complejos
    const ticketsToday = sample.filter(t => t.created_at.startsWith(today)).length;
    const pendingTickets = sample.filter(t => t.status === 'pending').length;
    const resolvedTickets = sample.filter(t => t.status === 'solved').length;
    
    // Extrapolar los resultados si se usó una muestra
    const scaleFactor = tickets.length / sample.length;
    const adjustedTicketsToday = Math.round(ticketsToday * scaleFactor);
    const adjustedPendingTickets = Math.round(pendingTickets * scaleFactor);
    const adjustedResolvedTickets = Math.round(resolvedTickets * scaleFactor);
    
    const resolutionRate = totalTickets > 0 ? 
        (adjustedResolvedTickets / totalTickets * 100).toFixed(1) : 0;

    return {
        totalTickets,
        ticketsToday: adjustedTicketsToday,
        pendingTickets: adjustedPendingTickets,
        resolutionRate
    };
}

// Actualizar el dashboard
async function updateDashboard() {
    try {
        const startDate = document.getElementById('startDate').value;
        const endDate = document.getElementById('endDate').value;
        
        const tickets = await getTickets();
        const filteredTickets = tickets.filter(ticket => {
            const ticketDate = new Date(ticket.created_at);
            return ticketDate >= new Date(startDate) && ticketDate <= new Date(endDate + 'T23:59:59');
        });
        
        const data = analyzeTickets(filteredTickets);
        updateMetrics(data);
    } catch (error) {
        console.error('Error al actualizar el dashboard:', error);
    }
}

// Actualizar métricas
function updateMetrics(data) {
    document.getElementById('total-tickets').textContent = data.totalTickets;
    document.getElementById('tickets-hoy').textContent = data.ticketsToday;
    document.getElementById('tickets-pendientes').textContent = data.pendingTickets;
    document.getElementById('tasa-resolucion').textContent = `${data.resolutionRate}%`;
}

// Inicializar gráficos de la página detallada
function initDetailedPlots() {
    console.log('Iniciando inicialización de gráficos detallados...');
    const dailyContainer = document.getElementById('dailyTrendDetailed');
    const monthlyContainer = document.getElementById('monthlyTrendDetailed');

    // Destruir instancias de gráficos existentes si las hay
    if (dailyPlotDetailed) {
        dailyPlotDetailed.destroy();
        dailyPlotDetailed = null;
    }
    if (monthlyPlotDetailed) {
        monthlyPlotDetailed.destroy();
        monthlyPlotDetailed = null;
    }

    console.log('Contenedores encontrados (Detallado):', {
        daily: !!dailyContainer,
        monthly: !!monthlyContainer
    });

    if (!dailyContainer || !monthlyContainer) {
        console.error('No se encontraron todos los contenedores necesarios para gráficos detallados.');
        return;
    }

    console.log('dailyContainer offsetWidth:', dailyContainer.offsetWidth);
    console.log('monthlyContainer offsetWidth:', monthlyContainer.offsetWidth);

    const getBarColor = (value, maxValue) => {
        // Asegurarse de que maxValue sea un número positivo finito para evitar divisiones por cero o NaN
        if (!Number.isFinite(maxValue) || maxValue <= 0) {
            maxValue = 1; // Usar 1 como valor por defecto si maxValue no es válido
        }

        const percentage = value / maxValue;
        if (percentage < 0.33) return "#2196F3"; // Azul para valores bajos
        if (percentage < 0.66) return "#4CAF50"; // Verde para valores medios
        return "#F44336"; // Rojo para valores altos
    };

    const baseOpts = {
        width: dailyContainer.offsetWidth, // Usar ancho del dailyContainer
        height: 300,
        cursor: {
            show: true,
            sync: {
                key: "detailedSync"
            }
        },
        scales: {
            x: {
                time: true,
            },
            y: {
                auto: true,
            }
        },
        axes: [
            {
                stroke: "#03363d",
                grid: { show: true, stroke: "#d8dcde" },
                ticks: { show: true, stroke: "#03363d" },
                font: "12px Arial",
                values: (self, splits) => splits.map(s => {
                    const date = new Date(s * 1000);
                    return new Intl.DateTimeFormat('es-EC', {
                        month: 'short',
                        day: 'numeric',
                        timeZone: 'America/Guayaquil'
                    }).format(date);
                }),
            },
            {
                stroke: "#03363d",
                grid: { show: true, stroke: "#d8dcde" },
                ticks: { show: true, stroke: "#03363d" },
                font: "12px Arial",
            }
        ]
    };

    try {
        console.log('Creando gráfico diario detallado...');
        const dailyOpts = {
            ...baseOpts,
            title: "Tickets por Día (Detallado)",
            series: [
                {},
                {
                    stroke: (u, seriesIdx, dataIdx) => {
                        // Comprobación robusta para asegurar que u y u.data existan y que seriesData sea un array
                        if (!u || !u.data || !Array.isArray(u.data[seriesIdx])) {
                            return "#CCCCCC"; // Color por defecto si los datos no son válidos
                        }
                        const seriesData = u.data[seriesIdx];
                        if (dataIdx < 0 || dataIdx >= seriesData.length) {
                            return "#CCCCCC"; 
                        }
                        const value = seriesData[dataIdx];
                        const maxValue = seriesData.length > 0 ? Math.max(...seriesData) : 1; 
                        return getBarColor(value, maxValue);
                    },
                    width: 2,
                    fill: (u, seriesIdx, dataIdx) => {
                        // Comprobación robusta para asegurar que u y u.data existan y que seriesData sea un array
                        if (!u || !u.data || !Array.isArray(u.data[seriesIdx])) {
                            return "#CCCCCC80"; // Color por defecto si los datos no son válidos
                        }
                        const seriesData = u.data[seriesIdx];
                        if (dataIdx < 0 || dataIdx >= seriesData.length) {
                            return "#CCCCCC80";
                        }
                        const value = seriesData[dataIdx];
                        const maxValue = seriesData.length > 0 ? Math.max(...seriesData) : 1; 
                        return getBarColor(value, maxValue) + "80";
                    },
                    label: "Tickets por día",
                    paths: uPlot.paths.bars(),
                    points: { show: false },
                }
            ]
        };
        dailyPlotDetailed = new uPlot(dailyOpts, [[0, 1], [0, 0]], dailyContainer); // Modificado para incluir dos puntos dummy
        console.log('Gráfico diario detallado creado:', dailyPlotDetailed);

        console.log('Creando gráfico mensual detallado...');
        const monthlyOpts = {
            ...baseOpts,
            title: "Tickets por Mes (Detallado)",
            series: [
                {},
                {
                    stroke: (u, seriesIdx, dataIdx) => {
                        // Comprobación robusta para asegurar que u y u.data existan y que seriesData sea un array
                        if (!u || !u.data || !Array.isArray(u.data[seriesIdx])) {
                            return "#CCCCCC"; // Color por defecto si los datos no son válidos
                        }
                        const seriesData = u.data[seriesIdx];
                        if (dataIdx < 0 || dataIdx >= seriesData.length) {
                            return "#CCCCCC"; 
                        }
                        const value = seriesData[dataIdx];
                        const maxValue = seriesData.length > 0 ? Math.max(...seriesData) : 1; 
                        return getBarColor(value, maxValue);
                    },
                    width: 2,
                    fill: (u, seriesIdx, dataIdx) => {
                        // Comprobación robusta para asegurar que u y u.data existan y que seriesData sea un array
                        if (!u || !u.data || !Array.isArray(u.data[seriesIdx])) {
                            return "#CCCCCC80"; // Color por defecto si los datos no son válidos
                        }
                        const seriesData = u.data[seriesIdx];
                        if (dataIdx < 0 || dataIdx >= seriesData.length) {
                            return "#CCCCCC80"; 
                        }
                        const value = seriesData[dataIdx];
                        const maxValue = seriesData.length > 0 ? Math.max(...seriesData) : 1; 
                        return getBarColor(value, maxValue) + "80";
                    },
                    label: "Tickets por mes",
                    paths: uPlot.paths.bars(),
                    points: { show: false },
                }
            ]
        };
        monthlyPlotDetailed = new uPlot(monthlyOpts, [[0, 1], [0, 0]], monthlyContainer); // Modificado para incluir dos puntos dummy
        console.log('Gráfico mensual detallado creado:', monthlyPlotDetailed);

        // Añadir listener de redimensionamiento para ambos gráficos detallados
        window.addEventListener('resize', () => {
            if (dailyPlotDetailed && dailyContainer) {
                dailyPlotDetailed.setSize({ width: dailyContainer.offsetWidth, height: 300 });
            }
            if (monthlyPlotDetailed && monthlyContainer) {
                monthlyPlotDetailed.setSize({ width: monthlyContainer.offsetWidth, height: 300 });
            }
        });

    } catch (error) {
        console.error('Error al crear los gráficos detallados:', error);
    }
}

// Actualizar análisis detallado
async function updateDetailedAnalysis() {
    try {
        console.log('Iniciando actualización de análisis detallado avanzado...');
        const startTime = performance.now();
        
        const startDate = document.getElementById('startDateDetailed').value;
        const endDate = document.getElementById('endDateDetailed').value;
        console.log('Fechas de filtro detallado:', { startDate, endDate });
        
        const tickets = await getTickets();
        console.log('Tickets obtenidos para análisis detallado:', tickets.length);
        
        // Usar filtrado optimizado
        const currentTickets = getFilteredTicketsOptimized(startDate, endDate);
        console.log('Tickets filtrados para análisis detallado:', currentTickets.length);

        // Realizar análisis avanzado
        const advancedAnalysis = performAdvancedAnalysis(currentTickets);
        console.log('Análisis avanzado completado:', advancedAnalysis);

        // Actualizar gráficos con datos optimizados
        await updateDetailedChartsOptimized(currentTickets, startDate, endDate);

        // Actualizar métricas básicas (optimizado)
        updateBasicMetrics(currentTickets, advancedAnalysis);

        // Actualizar análisis predictivo avanzado
        updateAdvancedPredictiveAnalysis(advancedAnalysis);

        // Mostrar insights y recomendaciones mejoradas
        updateAdvancedInsights(advancedAnalysis);

        const endTime = performance.now();
        console.log(`Análisis detallado completado en ${(endTime - startTime).toFixed(2)}ms`);

    } catch (error) {
        console.error('Error al actualizar análisis detallado:', error);
    }
}

// Actualizar gráficos detallados de forma optimizada
async function updateDetailedChartsOptimized(tickets, startDate, endDate) {
    // Usar índices pre-calculados para generar datos de gráficos
    const dailyData = getAggregatedDataOptimized(tickets, 'daily', startDate, endDate);
    const monthlyData = getAggregatedDataOptimized(tickets, 'monthly', startDate, endDate);

    // Actualizar gráfico diario
    const dailyTimestamps = Object.keys(dailyData).sort().map(key => {
        const date = parseKeyToDate(key, 'daily');
        return date.getTime() / 1000;
    });
    const dailyValues = Object.keys(dailyData).sort().map(key => dailyData[key]);
    
    console.log('Datos diarios para gráfico detallado:', { dailyTimestamps, dailyValues });

    if (dailyPlotDetailed) {
        console.log('Actualizando dailyPlotDetailed...');
        dailyPlotDetailed.setData([dailyTimestamps, dailyValues]);
    } else {
        console.error('dailyPlotDetailed no está inicializado.');
    }

    // Actualizar gráfico mensual
    const monthlyTimestamps = Object.keys(monthlyData).sort().map(key => {
        const date = parseKeyToDate(key, 'monthly');
        return date.getTime() / 1000;
    });
    const monthlyValues = Object.keys(monthlyData).sort().map(key => monthlyData[key]);
    
    console.log('Datos mensuales para gráfico detallado:', { monthlyTimestamps, monthlyValues });

    if (monthlyPlotDetailed) {
        console.log('Actualizando monthlyPlotDetailed...');
        monthlyPlotDetailed.setData([monthlyTimestamps, monthlyValues]);
    } else {
        console.error('monthlyPlotDetailed no está inicializado.');
    }
}

// Actualizar métricas básicas optimizado
function updateBasicMetrics(tickets, analysis) {
    if (tickets.length === 0) {
        ['dailyAverage', 'peakDays', 'seasonality'].forEach(id => {
            const element = document.getElementById(id);
            if (element) element.textContent = 'Sin datos';
        });
        return;
    }

    // Usar estadísticas pre-calculadas cuando sea posible
    const dailyValues = Object.values(getAggregatedDataOptimized(tickets, 'daily', 
        tickets[0].created_at.split('T')[0], 
        tickets[tickets.length - 1].created_at.split('T')[0]));
    
    if (dailyValues.length > 0) {
        const average = dailyValues.reduce((a, b) => a + b, 0) / dailyValues.length;
        const maxValue = Math.max(...dailyValues);
        const minValue = Math.min(...dailyValues);
        
        // Usar análisis de tendencias del análisis avanzado
        const trend = analysis.trends.temporal || { slope: 0 };
        const trendPercentage = trend.slope || 0;

        // Actualizar métricas en la UI
        const dailyAvgElement = document.getElementById('dailyAverage');
        if (dailyAvgElement) {
            dailyAvgElement.textContent = `Promedio: ${average.toFixed(1)} tickets por día`;
        }

        const peakDaysElement = document.getElementById('peakDays');
        if (peakDaysElement) {
            peakDaysElement.textContent = `Máximo: ${maxValue} tickets, Mínimo: ${minValue} tickets`;
        }

        const seasonalityElement = document.getElementById('seasonality');
        if (seasonalityElement) {
            seasonalityElement.textContent = `Tendencia: ${trendPercentage > 0 ? '↑' : trendPercentage < 0 ? '↓' : '→'} ${Math.abs(trendPercentage).toFixed(1)}%`;
        }
    }
}

// Actualizar análisis predictivo avanzado
function updateAdvancedPredictiveAnalysis(analysis) {
    const trendElement = document.getElementById('trendAnalysis');
    const predictionElement = document.getElementById('nextMonthPrediction');
    const recommendationsElement = document.getElementById('recommendations');

    if (!trendElement || !predictionElement || !recommendationsElement) {
        console.warn('Elementos de análisis predictivo no encontrados');
        return;
    }

    // Análisis de tendencias mejorado
    if (analysis.trends.temporal && analysis.trends.temporal.trend !== 'insufficient_data') {
        const trend = analysis.trends.temporal;
        let trendText = '';
        
        switch(trend.trend) {
            case 'increasing':
                trendText = `Tendencia creciente detectada con ${(trend.correlation * 100).toFixed(1)}% de confianza. `;
                if (trend.volatility > 0.5) {
                    trendText += 'Alta variabilidad observada. ';
                }
                if (trend.cycles.length > 0) {
                    trendText += `Patrón cíclico detectado cada ${trend.cycles[0].period} días.`;
                }
                break;
            case 'decreasing':
                trendText = `Tendencia decreciente detectada con ${(trend.correlation * 100).toFixed(1)}% de confianza. `;
                break;
            case 'stable':
                trendText = 'Volumen de tickets estable. ';
                if (trend.volatility > 0.5) {
                    trendText += 'Se observan fluctuaciones significativas.';
                }
                break;
        }
        
        trendElement.textContent = trendText;
    } else {
        trendElement.textContent = 'Datos insuficientes para análisis de tendencias.';
    }

    // Predicciones mejoradas
    if (analysis.predictions && !analysis.predictions.error) {
        const pred = analysis.predictions;
        const confidenceText = pred.confidence > 0.7 ? 'alta' : pred.confidence > 0.4 ? 'media' : 'baja';
        
        predictionElement.textContent = 
            `Predicciones (confianza ${confidenceText}): ` +
            `7 días: ${pred.next7Days} tickets, ` +
            `30 días: ${pred.next30Days} tickets, ` +
            `90 días: ${pred.next90Days} tickets.`;
    } else {
        predictionElement.textContent = 'No se pueden generar predicciones con los datos actuales.';
    }

    // Recomendaciones avanzadas
    const recommendations = generateAdvancedRecommendations(analysis);
    recommendationsElement.textContent = recommendations.join(' ');
}

// Generar recomendaciones avanzadas basadas en el análisis
function generateAdvancedRecommendations(analysis) {
    const recommendations = [];
    
    // Recomendaciones basadas en patrones semanales
    if (analysis.patterns.weeklyPattern) {
        const wp = analysis.patterns.weeklyPattern;
        const maxDeviation = Math.max(...wp.pattern.map(p => Math.abs(parseFloat(p.deviation))));
        
        if (maxDeviation > 50) {
            recommendations.push(`Considere ajustar la dotación de personal: ${wp.busiestDay.day} requiere ${wp.busiestDay.percentage}% más recursos.`);
        }
    }

    // Recomendaciones basadas en patrones horarios
    if (analysis.patterns.hourlyPattern) {
        const hp = analysis.patterns.hourlyPattern;
        const afterHoursPercentage = (hp.afterHours.reduce((sum, h) => sum + h.count, 0) / 
            (hp.businessHours.reduce((sum, h) => sum + h.count, 0) + hp.afterHours.reduce((sum, h) => sum + h.count, 0))) * 100;
        
        if (afterHoursPercentage > 20) {
            recommendations.push(`${afterHoursPercentage.toFixed(1)}% de tickets fuera de horario laboral. Considere soporte 24/7.`);
        }
        
        if (hp.peakHour.hour >= 9 && hp.peakHour.hour <= 17) {
            recommendations.push(`Hora pico: ${hp.peakHour.hour}:00. Optimice recursos durante este período.`);
        }
    }

    // Recomendaciones basadas en tendencias
    if (analysis.trends.temporal && analysis.trends.temporal.trend !== 'insufficient_data') {
        const trend = analysis.trends.temporal;
        
        if (trend.trend === 'increasing' && trend.slope > 1) {
            recommendations.push('Tendencia creciente significativa. Planifique expansión del equipo de soporte.');
        }
        
        if (trend.volatility > 0.7) {
            recommendations.push('Alta variabilidad detectada. Implemente estrategias de gestión de demanda variable.');
        }
        
        if (trend.cycles.length > 0) {
            const mainCycle = trend.cycles[0];
            recommendations.push(`Patrón cíclico cada ${mainCycle.period} días. Use para planificación predictiva.`);
        }
    }

    // Recomendaciones basadas en anomalías
    if (analysis.anomalies.length > 0) {
        const highAnomalies = analysis.anomalies.filter(a => a.significance === 'high');
        if (highAnomalies.length > 0) {
            recommendations.push(`${highAnomalies.length} anomalías significativas detectadas. Investigue causas raíz.`);
        }
    }

    // Recomendaciones por defecto si no hay suficientes datos
    if (recommendations.length === 0) {
        recommendations.push('Continúe monitoreando las métricas para obtener más insights.');
    }

    return recommendations;
}

// Actualizar insights avanzados
function updateAdvancedInsights(analysis) {
    // Crear sección de insights si no existe
    let insightsContainer = document.getElementById('advanced-insights');
    if (!insightsContainer) {
        // Crear el contenedor después del análisis predictivo
        const recommendationsElement = document.getElementById('recommendations');
        if (recommendationsElement && recommendationsElement.parentNode) {
            insightsContainer = document.createElement('div');
            insightsContainer.id = 'advanced-insights';
            insightsContainer.className = 'mt-4';
            recommendationsElement.parentNode.insertBefore(insightsContainer, recommendationsElement.nextSibling);
        }
    }

    if (!insightsContainer) return;

    // Generar HTML para insights avanzados
    let insightsHTML = '<div class="card"><div class="card-header"><h6 class="mb-0">🔍 Insights Avanzados</h6></div><div class="card-body">';
    
    if (analysis.insights.length > 0) {
        insightsHTML += '<ul class="list-group list-group-flush">';
        analysis.insights.forEach(insight => {
            insightsHTML += `<li class="list-group-item">${insight}</li>`;
        });
        insightsHTML += '</ul>';
    } else {
        insightsHTML += '<p class="text-muted">No hay suficientes datos para generar insights avanzados.</p>';
    }

    // Agregar sección de anomalías si existen
    if (analysis.anomalies.length > 0) {
        insightsHTML += '<div class="mt-3"><h6>⚠️ Anomalías Detectadas</h6><ul class="list-group list-group-flush">';
        analysis.anomalies.slice(0, 3).forEach(anomaly => {
            const typeIcon = anomaly.type === 'spike' ? '📈' : '📉';
            insightsHTML += `<li class="list-group-item">${typeIcon} ${anomaly.date}: ${anomaly.count} tickets (Z-score: ${anomaly.zScore})</li>`;
        });
        insightsHTML += '</ul></div>';
    }

    insightsHTML += '</div></div>';
    insightsContainer.innerHTML = insightsHTML;
}

// Calcular tendencia
function calculateTrend(values) {
    if (values.length < 2) return 0;
    const xMean = (values.length - 1) / 2;
    const yMean = values.reduce((a, b) => a + b, 0) / values.length;
    
    let numerator = 0;
    let denominator = 0;
    
    values.forEach((y, x) => {
        numerator += (x - xMean) * (y - yMean);
        denominator += Math.pow(x - xMean, 2);
    });
    
    const slope = numerator / denominator;
    return (slope / yMean) * 100;
}

// Predecir próximo mes
function predictNextMonth(values, trend) {
    const lastValue = values[values.length - 1];
    return lastValue * (1 + trend / 100);
}

// Generar recomendaciones
function generateRecommendations(trend, average, maxValue) {
    const recommendations = [];
    
    if (trend > 5) {
        recommendations.push("Considerar aumentar el personal de soporte.");
    } else if (trend < -5) {
        recommendations.push("Evaluar la eficiencia del equipo actual.");
    }
    
    if (maxValue > average * 2) {
        recommendations.push("Implementar estrategias para manejar picos de demanda.");
    }
    
    if (average > 50) {
        recommendations.push("Revisar procesos para optimizar tiempos de respuesta.");
    }
    
    return recommendations.length > 0 ? recommendations.join(" ") : "No se requieren cambios inmediatos.";
}

// Función para construir índices optimizados
function buildOptimizedIndices(tickets) {
    console.log('Construyendo índices optimizados...');
    const start = performance.now();
    
    // Limpiar índices existentes
    Object.values(ticketsCache.indices).forEach(map => map.clear());
    
    // Construir índices en una sola pasada
    tickets.forEach(ticket => {
        const date = new Date(ticket.created_at);
        const dateKey = date.toISOString().split('T')[0];
        const monthKey = date.toISOString().slice(0, 7);
        const yearKey = date.getFullYear().toString();
        const hourKey = date.toISOString().slice(0, 13);
        const dayOfWeek = date.getDay();
        
        // Índice por fecha
        if (!ticketsCache.indices.byDate.has(dateKey)) {
            ticketsCache.indices.byDate.set(dateKey, []);
        }
        ticketsCache.indices.byDate.get(dateKey).push(ticket);
        
        // Índice por status
        if (!ticketsCache.indices.byStatus.has(ticket.status)) {
            ticketsCache.indices.byStatus.set(ticket.status, []);
        }
        ticketsCache.indices.byStatus.get(ticket.status).push(ticket);
        
        // Índice por mes
        if (!ticketsCache.indices.byMonth.has(monthKey)) {
            ticketsCache.indices.byMonth.set(monthKey, []);
        }
        ticketsCache.indices.byMonth.get(monthKey).push(ticket);
        
        // Índice por año
        if (!ticketsCache.indices.byYear.has(yearKey)) {
            ticketsCache.indices.byYear.set(yearKey, []);
        }
        ticketsCache.indices.byYear.get(yearKey).push(ticket);
        
        // Índice por hora
        if (!ticketsCache.indices.byHour.has(hourKey)) {
            ticketsCache.indices.byHour.set(hourKey, []);
        }
        ticketsCache.indices.byHour.get(hourKey).push(ticket);
        
        // Índice por día de la semana
        if (!ticketsCache.indices.byDay.has(dayOfWeek)) {
            ticketsCache.indices.byDay.set(dayOfWeek, []);
        }
        ticketsCache.indices.byDay.get(dayOfWeek).push(ticket);
    });
    
    // Calcular estadísticas básicas
    calculateBasicStats(tickets);
    
    const end = performance.now();
    console.log(`Índices construidos en ${(end - start).toFixed(2)}ms`);
}

// Función para calcular estadísticas básicas
function calculateBasicStats(tickets) {
    if (tickets.length === 0) return;
    
    const dates = tickets.map(t => new Date(t.created_at)).sort();
    const statusCounts = {};
    
    tickets.forEach(ticket => {
        statusCounts[ticket.status] = (statusCounts[ticket.status] || 0) + 1;
    });
    
    ticketsCache.stats = {
        totalTickets: tickets.length,
        dateRange: {
            min: dates[0],
            max: dates[dates.length - 1]
        },
        statusDistribution: statusCounts,
        averagePerDay: tickets.length / Math.max(1, (dates[dates.length - 1] - dates[0]) / (1000 * 60 * 60 * 24)),
        averagePerMonth: tickets.length / Math.max(1, (dates[dates.length - 1] - dates[0]) / (1000 * 60 * 60 * 24 * 30)),
        lastCalculated: Date.now()
    };
}

// Función de filtrado optimizado usando índices
function getFilteredTicketsOptimized(startDate, endDate, additionalFilters = {}) {
    const start = performance.now();
    
    if (ticketsCache.indices.byDate.size === 0) {
        console.warn('Índices no construidos, usando filtrado tradicional');
        return ticketsCache.data.filter(ticket => {
            const ticketDate = new Date(ticket.created_at);
            return ticketDate >= new Date(startDate) && ticketDate <= new Date(endDate + 'T23:59:59');
        });
    }
    
    const startDateObj = new Date(startDate);
    const endDateObj = new Date(endDate + 'T23:59:59');
    const filteredTickets = [];
    
    // Iterar solo sobre las fechas en el rango
    for (let d = new Date(startDateObj); d <= endDateObj; d.setDate(d.getDate() + 1)) {
        const dateKey = d.toISOString().split('T')[0];
        const dayTickets = ticketsCache.indices.byDate.get(dateKey);
        
        if (dayTickets) {
            if (additionalFilters.status) {
                filteredTickets.push(...dayTickets.filter(t => t.status === additionalFilters.status));
            } else {
                filteredTickets.push(...dayTickets);
            }
        }
    }
    
    const end = performance.now();
    console.log(`Filtrado optimizado completado en ${(end - start).toFixed(2)}ms. Tickets: ${filteredTickets.length}`);
    
    return filteredTickets;
}

// Análisis avanzado de patrones y tendencias
function performAdvancedAnalysis(tickets) {
    const analysis = {
        patterns: {},
        trends: {},
        predictions: {},
        anomalies: [],
        insights: []
    };
    
    if (tickets.length === 0) return analysis;
    
    // 1. Análisis de patrones por día de la semana
    analysis.patterns.weeklyPattern = analyzeWeeklyPattern(tickets);
    
    // 2. Análisis de patrones por hora del día
    analysis.patterns.hourlyPattern = analyzeHourlyPattern(tickets);
    
    // 3. Análisis de tendencias temporales
    analysis.trends.temporal = analyzeTemporal(tickets);
    
    // 4. Detección de anomalías
    analysis.anomalies = detectAnomalies(tickets);
    
    // 5. Predicciones basadas en tendencias
    analysis.predictions = generatePredictions(tickets);
    
    // 6. Insights automáticos
    analysis.insights = generateInsights(analysis);
    
    return analysis;
}

// Análisis de patrones semanales
function analyzeWeeklyPattern(tickets) {
    const dayNames = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
    const dayCounts = new Array(7).fill(0);
    
    tickets.forEach(ticket => {
        const dayOfWeek = new Date(ticket.created_at).getDay();
        dayCounts[dayOfWeek]++;
    });
    
    const total = dayCounts.reduce((a, b) => a + b, 0);
    const averagePerDay = total / 7;
    
    const pattern = dayCounts.map((count, index) => ({
        day: dayNames[index],
        count,
        percentage: ((count / total) * 100).toFixed(1),
        deviation: ((count - averagePerDay) / averagePerDay * 100).toFixed(1)
    }));
    
    const busiestDay = pattern.reduce((max, day) => day.count > max.count ? day : max);
    const quietestDay = pattern.reduce((min, day) => day.count < min.count ? day : min);
    
    return {
        pattern,
        busiestDay,
        quietestDay,
        variance: calculateVariance(dayCounts)
    };
}

// Análisis de patrones por hora
function analyzeHourlyPattern(tickets) {
    const hourCounts = new Array(24).fill(0);
    
    tickets.forEach(ticket => {
        const hour = new Date(ticket.created_at).getHours();
        hourCounts[hour]++;
    });
    
    const total = hourCounts.reduce((a, b) => a + b, 0);
    const pattern = hourCounts.map((count, hour) => ({
        hour,
        count,
        percentage: ((count / total) * 100).toFixed(1)
    }));
    
    const peakHour = pattern.reduce((max, hour) => hour.count > max.count ? hour : max);
    const quietestHour = pattern.reduce((min, hour) => hour.count < min.count ? hour : min);
    
    return {
        pattern,
        peakHour,
        quietestHour,
        businessHours: pattern.filter(h => h.hour >= 9 && h.hour <= 17),
        afterHours: pattern.filter(h => h.hour < 9 || h.hour > 17)
    };
}

// Análisis temporal de tendencias
function analyzeTemporal(tickets) {
    if (tickets.length < 7) return { trend: 'insufficient_data' };
    
    // Agrupar por días
    const dailyData = {};
    tickets.forEach(ticket => {
        const date = new Date(ticket.created_at).toISOString().split('T')[0];
        dailyData[date] = (dailyData[date] || 0) + 1;
    });
    
    const sortedDates = Object.keys(dailyData).sort();
    const values = sortedDates.map(date => dailyData[date]);
    
    // Calcular tendencia usando regresión lineal simple
    const trend = calculateLinearTrend(values);
    
    // Calcular volatilidad
    const volatility = calculateVolatility(values);
    
    // Detectar ciclos
    const cycles = detectCycles(values);
    
    return {
        trend: trend.slope > 0.1 ? 'increasing' : trend.slope < -0.1 ? 'decreasing' : 'stable',
        slope: trend.slope,
        correlation: trend.correlation,
        volatility,
        cycles,
        movingAverage: calculateMovingAverage(values, 7)
    };
}

// Detección de anomalías
function detectAnomalies(tickets) {
    const dailyData = {};
    tickets.forEach(ticket => {
        const date = new Date(ticket.created_at).toISOString().split('T')[0];
        dailyData[date] = (dailyData[date] || 0) + 1;
    });
    
    const values = Object.values(dailyData);
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    const stdDev = Math.sqrt(values.reduce((sq, n) => sq + Math.pow(n - mean, 2), 0) / values.length);
    
    const anomalies = [];
    Object.entries(dailyData).forEach(([date, count]) => {
        const zScore = Math.abs((count - mean) / stdDev);
        if (zScore > 2) { // Más de 2 desviaciones estándar
            anomalies.push({
                date,
                count,
                zScore: zScore.toFixed(2),
                type: count > mean ? 'spike' : 'drop',
                significance: zScore > 3 ? 'high' : 'medium'
            });
        }
    });
    
    return anomalies.sort((a, b) => b.zScore - a.zScore);
}

// Generar predicciones
function generatePredictions(tickets) {
    const analysis = analyzeTemporal(tickets);
    
    if (analysis.trend === 'insufficient_data') {
        return { error: 'Datos insuficientes para predicciones' };
    }
    
    const lastValue = analysis.movingAverage[analysis.movingAverage.length - 1];
    const trendMultiplier = analysis.slope;
    
    // Predicciones para los próximos 7, 30 y 90 días
    const predictions = {
        next7Days: Math.max(0, Math.round(lastValue + (trendMultiplier * 7))),
        next30Days: Math.max(0, Math.round(lastValue + (trendMultiplier * 30))),
        next90Days: Math.max(0, Math.round(lastValue + (trendMultiplier * 90))),
        confidence: Math.max(0.1, Math.min(0.9, 1 - analysis.volatility))
    };
    
    return predictions;
}

// Generar insights automáticos
function generateInsights(analysis) {
    const insights = [];
    
    if (analysis.patterns.weeklyPattern) {
        const wp = analysis.patterns.weeklyPattern;
        insights.push(`El ${wp.busiestDay.day} es el día más ocupado con ${wp.busiestDay.count} tickets (${wp.busiestDay.percentage}% del total)`);
        insights.push(`El ${wp.quietestDay.day} es el día más tranquilo con ${wp.quietestDay.count} tickets`);
    }
    
    if (analysis.patterns.hourlyPattern) {
        const hp = analysis.patterns.hourlyPattern;
        insights.push(`La hora pico es ${hp.peakHour.hour}:00 con ${hp.peakHour.count} tickets`);
        
        const businessHoursTotal = hp.businessHours.reduce((sum, h) => sum + h.count, 0);
        const afterHoursTotal = hp.afterHours.reduce((sum, h) => sum + h.count, 0);
        const businessHoursPercentage = ((businessHoursTotal / (businessHoursTotal + afterHoursTotal)) * 100).toFixed(1);
        
        insights.push(`${businessHoursPercentage}% de los tickets ocurren en horario laboral (9-17h)`);
    }
    
    if (analysis.trends.temporal && analysis.trends.temporal.trend !== 'insufficient_data') {
        const trend = analysis.trends.temporal;
        if (trend.trend === 'increasing') {
            insights.push(`Tendencia creciente detectada: aumento promedio de ${trend.slope.toFixed(1)} tickets por día`);
        } else if (trend.trend === 'decreasing') {
            insights.push(`Tendencia decreciente detectada: disminución promedio de ${Math.abs(trend.slope).toFixed(1)} tickets por día`);
        }
        
        if (trend.volatility > 0.5) {
            insights.push('Alta variabilidad en el volumen de tickets detectada');
        }
    }
    
    if (analysis.anomalies.length > 0) {
        const significantAnomalies = analysis.anomalies.filter(a => a.significance === 'high');
        if (significantAnomalies.length > 0) {
            insights.push(`${significantAnomalies.length} anomalías significativas detectadas en el período`);
        }
    }
    
    return insights;
}

// Funciones auxiliares para cálculos estadísticos
function calculateVariance(values) {
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    return values.reduce((sq, n) => sq + Math.pow(n - mean, 2), 0) / values.length;
}

function calculateLinearTrend(values) {
    const n = values.length;
    const x = Array.from({length: n}, (_, i) => i);
    const sumX = x.reduce((a, b) => a + b, 0);
    const sumY = values.reduce((a, b) => a + b, 0);
    const sumXY = x.reduce((sum, xi, i) => sum + xi * values[i], 0);
    const sumXX = x.reduce((sum, xi) => sum + xi * xi, 0);
    
    const slope = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);
    const intercept = (sumY - slope * sumX) / n;
    
    // Calcular correlación
    const meanX = sumX / n;
    const meanY = sumY / n;
    const num = x.reduce((sum, xi, i) => sum + (xi - meanX) * (values[i] - meanY), 0);
    const denX = Math.sqrt(x.reduce((sum, xi) => sum + Math.pow(xi - meanX, 2), 0));
    const denY = Math.sqrt(values.reduce((sum, yi) => sum + Math.pow(yi - meanY, 2), 0));
    const correlation = num / (denX * denY);
    
    return { slope, intercept, correlation };
}

function calculateVolatility(values) {
    if (values.length < 2) return 0;
    const returns = values.slice(1).map((val, i) => (val - values[i]) / Math.max(1, values[i]));
    const meanReturn = returns.reduce((a, b) => a + b, 0) / returns.length;
    const variance = returns.reduce((sq, r) => sq + Math.pow(r - meanReturn, 2), 0) / returns.length;
    return Math.sqrt(variance);
}

function detectCycles(values) {
    // Implementación simple de detección de ciclos usando autocorrelación
    const cycles = [];
    for (let lag = 1; lag <= Math.min(30, Math.floor(values.length / 2)); lag++) {
        const correlation = calculateAutocorrelation(values, lag);
        if (correlation > 0.3) {
            cycles.push({ period: lag, strength: correlation });
        }
    }
    return cycles.sort((a, b) => b.strength - a.strength);
}

function calculateAutocorrelation(values, lag) {
    const n = values.length - lag;
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    
    let num = 0, den = 0;
    for (let i = 0; i < n; i++) {
        num += (values[i] - mean) * (values[i + lag] - mean);
    }
    
    for (let i = 0; i < values.length; i++) {
        den += Math.pow(values[i] - mean, 2);
    }
    
    return den === 0 ? 0 : num / den;
}

function calculateMovingAverage(values, window) {
    const result = [];
    for (let i = window - 1; i < values.length; i++) {
        const avg = values.slice(i - window + 1, i + 1).reduce((a, b) => a + b, 0) / window;
        result.push(avg);
    }
    return result;
}
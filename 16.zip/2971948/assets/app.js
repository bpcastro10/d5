const client = ZAFClient.init();
let ticketsPlot = null;
let dailyPlotDetailed = null;
let monthlyPlotDetailed = null;
let comparisonPlot1 = null;
let comparisonPlot2 = null;
let updateIntervalId = null;

// Configuración de fechas por defecto
function setDefaultDates() {
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - 30);
    
    const dateInputs = ['startDate', 'endDate', 'startDate1', 'endDate1', 'startDate2', 'endDate2', 'startDateDetailed', 'endDateDetailed'];
    dateInputs.forEach(id => {
        const input = document.getElementById(id);
        if (input) {
            const dateValue = id.includes('start') ? startDate : endDate;
            input.value = dateValue.toISOString().split('T')[0];
        }
    });
}

// Función para alternar el modo oscuro
function toggleDarkMode() {
    document.body.classList.toggle('dark-mode');
    const isDarkMode = document.body.classList.contains('dark-mode');
    localStorage.setItem('darkMode', isDarkMode);
}

// Función para controlar la sincronización automática
function togglePeriodicUpdates() {
    const syncToggleButton = document.getElementById('syncToggle');
    if (updateIntervalId) {
        clearInterval(updateIntervalId);
        updateIntervalId = null;
        syncToggleButton.textContent = 'Iniciar Sincronización';
        console.log('Sincronización automática detenida.');
    } else {
        startPeriodicUpdates();
        syncToggleButton.textContent = 'Parar Sincronización';
        console.log('Sincronización automática iniciada.');
    }
}

// Función para cambiar de página
function changePage(pageId) {
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
    });
    document.querySelector(`[data-page="${pageId}"]`).classList.add('active');

    document.getElementById('dashboard-page').classList.toggle('d-none', pageId !== 'dashboard');
    document.getElementById('detailed-page').classList.toggle('d-none', pageId !== 'detailed');
    document.getElementById('comparison-page').classList.toggle('d-none', pageId !== 'comparison');

    if (pageId === 'comparison') {
        initComparisonPlots();
    } else if (pageId === 'detailed') {
        initDetailedPlots();
        updateDetailedAnalysis();
    }
}

// Inicializar la aplicación
async function init() {
    try {
        console.log('Iniciando aplicación...');
        setDefaultDates();
        if (localStorage.getItem('darkMode') === 'true') {
            document.body.classList.add('dark-mode');
        }

        // Event listeners para navegación
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                changePage(e.target.dataset.page);
            });
        });

        // Event listeners para botones
        document.getElementById('darkModeToggle').addEventListener('click', toggleDarkMode);
        document.getElementById('darkModeToggleDetailed').addEventListener('click', toggleDarkMode);
        document.getElementById('syncToggle').addEventListener('click', togglePeriodicUpdates);
        
        // Event listeners para filtros
        document.getElementById('applyFilter').addEventListener('click', async () => {
            const startDate = document.getElementById('startDate').value;
            const endDate = document.getElementById('endDate').value;
            
            if (!startDate || !endDate || new Date(startDate) > new Date(endDate)) {
                document.getElementById('date-filter-alert').classList.remove('d-none');
                return;
            }
            
            document.getElementById('date-filter-alert').classList.add('d-none');
            await Promise.all([updateDashboard(), updateTicketsData()]);
        });

        document.getElementById('applyFilterDetailed').addEventListener('click', async () => {
            const startDate = document.getElementById('startDateDetailed').value;
            const endDate = document.getElementById('endDateDetailed').value;
            
            if (!startDate || !endDate || new Date(startDate) > new Date(endDate)) {
                document.getElementById('date-filter-alert-detailed').classList.remove('d-none');
                return;
            }
            
            document.getElementById('date-filter-alert-detailed').classList.add('d-none');
            await updateDetailedAnalysis();
        });

        // Event listeners para los botones de filtro de comparación
        document.querySelectorAll('.apply-filter').forEach(button => {
            button.addEventListener('click', async (e) => {
                const chartNum = e.target.dataset.chart;
                const startDate = document.getElementById(`startDate${chartNum}`).value;
                const endDate = document.getElementById(`endDate${chartNum}`).value;
                
                if (!startDate || !endDate || new Date(startDate) > new Date(endDate)) {
                    return;
                }
                
                await updateComparisonChart(chartNum, startDate, endDate);
            });
        });

        console.log('Inicializando gráficos...');
        initTicketsPlot();
        
        console.log('Actualizando dashboard y datos iniciales...');
        await Promise.all([
            updateDashboard(),
            updateTicketsData()
        ]);
        
        console.log('Iniciando actualizaciones periódicas...');
        startPeriodicUpdates();
        document.getElementById('syncToggle').textContent = 'Parar Sincronización';

        console.log('Aplicación inicializada correctamente');
    } catch (error) {
        console.error('Error al inicializar la aplicación:', error);
    }
}

document.addEventListener('DOMContentLoaded', init);

// Inicializar gráfico de tickets
function initTicketsPlot() {
    console.log('Iniciando inicialización de gráficos...');
    
    const container = document.getElementById('realtimeTrend');
    
    console.log('Contenedores encontrados (Dashboard):', {
        realtime: !!container
    });

    if (!container) {
        console.error('No se encontró el contenedor del gráfico principal');
        return;
    }

    const baseOpts = {
        width: container.offsetWidth,
        height: 300,
        cursor: {
            show: true,
            sync: {
                key: "ticketSync"
            }
        },
        scales: {
            x: {
                time: true,
            },
            y: {
                auto: true,
            }
        },
        axes: [
            {
                stroke: "#03363d",
                grid: { show: true, stroke: "#d8dcde" },
                ticks: { show: true, stroke: "#03363d" },
                font: "12px Arial",
                values: (self, splits) => splits.map(s => {
                    const date = new Date(s * 1000);
                    return new Intl.DateTimeFormat('es-EC', {
                        month: 'short',
                        day: 'numeric',
                        timeZone: 'America/Guayaquil'
                    }).format(date);
                }),
            },
            {
                stroke: "#03363d",
                grid: { show: true, stroke: "#d8dcde" },
                ticks: { show: true, stroke: "#03363d" },
                font: "12px Arial",
            }
        ]
    };

    try {
        console.log('Creando gráfico de tiempo real...');
        const opts = {
            ...baseOpts,
            title: "Tickets por Hora",
            series: [
                {},
                {
                    stroke: "#03363d",
                    width: 2,
                    fill: "rgba(3, 54, 61, 0.1)",
                    label: "Tickets reales",
                },
                {
                    label: "Límite superior",
                    stroke: "gold",
                    width: 2,
                    dash: [1, 5],
                }
            ]
        };
        ticketsPlot = new uPlot(opts, [[], []], container);
        console.log('Gráfico de tiempo real creado');

        // Inicializar con datos vacíos
        const emptyData = [[], []];
        ticketsPlot.setData(emptyData);

    } catch (error) {
        console.error('Error al crear los gráficos del dashboard:', error);
    }
}

// Inicializar gráficos de comparación
function initComparisonPlots() {
    const container1 = document.getElementById('chart1');
    const container2 = document.getElementById('chart2');
    if (!container1 || !container2) return;

    const opts = {
        width: container1.offsetWidth,
        height: 300,
        title: "Tickets por Día",
        cursor: {
            show: true,
            sync: {
                key: "comparisonSync"
            }
        },
        scales: {
            x: {
                time: true,
            },
            y: {
                auto: true,
            }
        },
        axes: [
            {
                stroke: "#03363d",
                grid: { show: true, stroke: "#d8dcde" },
                ticks: { show: true, stroke: "#03363d" },
                font: "12px Arial",
                values: (self, splits) => splits.map(s => {
                    const date = new Date(s * 1000);
                    return new Intl.DateTimeFormat('es-EC', {
                        month: 'short',
                        day: 'numeric',
                        timeZone: 'America/Guayaquil'
                    }).format(date);
                }),
            },
            {
                stroke: "#03363d",
                grid: { show: true, stroke: "#d8dcde" },
                ticks: { show: true, stroke: "#03363d" },
                font: "12px Arial",
            }
        ],
        series: [
            {},
            {
                stroke: "#03363d",
                width: 2,
                fill: "rgba(3, 54, 61, 0.1)",
                label: "Tickets por día",
                paths: uPlot.paths.bars(),
                points: { show: false },
            }
        ]
    };

    comparisonPlot1 = new uPlot(opts, [[], []], container1);
    comparisonPlot2 = new uPlot(opts, [[], []], container2);

    // Inicializar datos para ambos gráficos
    const startDate1 = document.getElementById('startDate1').value;
    const endDate1 = document.getElementById('endDate1').value;
    const startDate2 = document.getElementById('startDate2').value;
    const endDate2 = document.getElementById('endDate2').value;

    updateComparisonChart(1, startDate1, endDate1);
    updateComparisonChart(2, startDate2, endDate2);
}

// Actualizar gráfico de comparación
async function updateComparisonChart(chartNum, startDate, endDate) {
    try {
        const tickets = await getTickets();
        const filteredTickets = tickets.filter(ticket => {
            const ticketDate = new Date(ticket.created_at);
            return ticketDate >= new Date(startDate) && ticketDate <= new Date(endDate + 'T23:59:59');
        });

        const dailyData = {};
        filteredTickets.forEach(ticket => {
            const date = new Date(ticket.created_at);
            const dayKey = date.toISOString().split('T')[0];
            dailyData[dayKey] = (dailyData[dayKey] || 0) + 1;
        });

        const timestamps = [];
        const values = [];

        const start = new Date(startDate);
        const end = new Date(endDate + 'T23:59:59');

        for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
            const dayKey = d.toISOString().split('T')[0];
            timestamps.push(d.getTime() / 1000);
            values.push(dailyData[dayKey] || 0);
        }

        const plot = chartNum === 1 ? comparisonPlot1 : comparisonPlot2;
        if (plot) {
            plot.setData([timestamps, values]);
        }
    } catch (error) {
        console.error(`Error al actualizar gráfico de comparación ${chartNum}:`, error);
    }
}

// Obtener tickets de Zendesk
async function getTickets() {
    try {
        const response = await client.request({
            url: '/api/v2/tickets.json',
            type: 'GET',
            contentType: 'application/json',
            headers: {
                'Accept': 'application/json'
            }
        });
        return response.tickets || [];
    } catch (error) {
        console.error('Error al obtener tickets:', error);
        return [];
    }
}

// Actualizar datos del gráfico principal
async function updateTicketsData() {
    try {
        console.log('Iniciando actualización de datos...');
        const startDate = document.getElementById('startDate').value;
        const endDate = document.getElementById('endDate').value;
        
        const tickets = await getTickets();
        console.log('Tickets obtenidos:', tickets.length);
        
        const currentTickets = tickets.filter(ticket => {
            const ticketDate = new Date(ticket.created_at);
            return ticketDate >= new Date(startDate) && ticketDate <= new Date(endDate + 'T23:59:59');
        });
        
        console.log('Tickets filtrados:', currentTickets.length);
        
        // Datos por hora
        const hourlyData = {};

        currentTickets.forEach(ticket => {
            const date = new Date(ticket.created_at);
            const hourKey = date.toISOString().slice(0, 13);
            
            hourlyData[hourKey] = (hourlyData[hourKey] || 0) + 1;
        });

        // Actualizar gráfico por hora
        const timestamps = [];
        const values = [];
        const superiorLimitValues = [];

        const start = new Date(startDate);
        const end = new Date(endDate + 'T23:59:59');
        const SUPERIOR_LIMIT_VALUE = 12;

        for (let d = new Date(start); d <= end; d.setHours(d.getHours() + 1)) {
            const hourKey = d.toISOString().slice(0, 13);
            timestamps.push(d.getTime() / 1000);
            values.push(hourlyData[hourKey] || 0);
            superiorLimitValues.push(SUPERIOR_LIMIT_VALUE);
        }

        if (ticketsPlot) {
            console.log('Actualizando gráfico por hora...');
            ticketsPlot.setData([timestamps, values, superiorLimitValues]);
        }

        console.log('Actualización de datos completada (Dashboard)');
    } catch (error) {
        console.error('Error al actualizar datos del gráfico:', error);
    }
}

// Iniciar actualizaciones periódicas
function startPeriodicUpdates() {
    updateTicketsData();
    if (updateIntervalId) {
        clearInterval(updateIntervalId);
    }
    updateIntervalId = setInterval(updateTicketsData, 300000);
}

// Actualizar el dashboard
async function updateDashboard() {
    try {
        const startDate = document.getElementById('startDate').value;
        const endDate = document.getElementById('endDate').value;
        
        const tickets = await getTickets();
        const filteredTickets = tickets.filter(ticket => {
            const ticketDate = new Date(ticket.created_at);
            return ticketDate >= new Date(startDate) && ticketDate <= new Date(endDate + 'T23:59:59');
        });
        
        const data = analyzeTickets(filteredTickets);
        updateMetrics(data);
    } catch (error) {
        console.error('Error al actualizar el dashboard:', error);
    }
}

// Analizar tickets
function analyzeTickets(tickets) {
    const today = new Date().toISOString().split('T')[0];
    const totalTickets = tickets.length;
    const ticketsToday = tickets.filter(t => t.created_at.startsWith(today)).length;
    const pendingTickets = tickets.filter(t => t.status === 'pending').length;
    const resolvedTickets = tickets.filter(t => t.status === 'solved').length;
    const resolutionRate = totalTickets > 0 ? (resolvedTickets / totalTickets * 100).toFixed(1) : 0;

    return {
        totalTickets,
        ticketsToday,
        pendingTickets,
        resolutionRate
    };
}

// Actualizar métricas
function updateMetrics(data) {
    document.getElementById('total-tickets').textContent = data.totalTickets;
    document.getElementById('tickets-hoy').textContent = data.ticketsToday;
    document.getElementById('tickets-pendientes').textContent = data.pendingTickets;
    document.getElementById('tasa-resolucion').textContent = `${data.resolutionRate}%`;
}

// Inicializar gráficos de la página detallada
function initDetailedPlots() {
    console.log('Iniciando inicialización de gráficos detallados...');
    const dailyContainer = document.getElementById('dailyTrendDetailed');
    const monthlyContainer = document.getElementById('monthlyTrendDetailed');

    console.log('Contenedores encontrados (Detallado):', {
        daily: !!dailyContainer,
        monthly: !!monthlyContainer
    });

    if (!dailyContainer || !monthlyContainer) {
        console.error('No se encontraron todos los contenedores necesarios para gráficos detallados.');
        return;
    }

    console.log('dailyContainer offsetWidth:', dailyContainer.offsetWidth);
    console.log('monthlyContainer offsetWidth:', monthlyContainer.offsetWidth);

    const getBarColor = (value, maxValue) => {
        const percentage = value / maxValue;
        if (percentage < 0.33) return "#2196F3"; // Azul para valores bajos
        if (percentage < 0.66) return "#4CAF50"; // Verde para valores medios
        return "#F44336"; // Rojo para valores altos
    };

    const baseOpts = {
        width: dailyContainer.offsetWidth, // Use width from dailyContainer
        height: 300,
        cursor: {
            show: true,
            sync: {
                key: "detailedSync"
            }
        },
        scales: {
            x: {
                time: true,
            },
            y: {
                auto: true,
            }
        },
        axes: [
            {
                stroke: "#03363d",
                grid: { show: true, stroke: "#d8dcde" },
                ticks: { show: true, stroke: "#03363d" },
                font: "12px Arial",
                values: (self, splits) => splits.map(s => {
                    const date = new Date(s * 1000);
                    return new Intl.DateTimeFormat('es-EC', {
                        month: 'short',
                        day: 'numeric',
                        timeZone: 'America/Guayaquil'
                    }).format(date);
                }),
            },
            {
                stroke: "#03363d",
                grid: { show: true, stroke: "#d8dcde" },
                ticks: { show: true, stroke: "#03363d" },
                font: "12px Arial",
            }
        ]
    };

    try {
        console.log('Creando gráfico diario detallado...');
        const dailyOpts = {
            ...baseOpts,
            title: "Tickets por Día (Detallado)",
            series: [
                {},
                {
                    stroke: (u, seriesIdx, dataIdx) => {
                        const value = u.data[seriesIdx][dataIdx];
                        const maxValue = Math.max(...u.data[seriesIdx]);
                        return getBarColor(value, maxValue);
                    },
                    width: 2,
                    fill: (u, seriesIdx, dataIdx) => {
                        const value = u.data[seriesIdx][dataIdx];
                        const maxValue = Math.max(...u.data[seriesIdx]);
                        return getBarColor(value, maxValue) + "80";
                    },
                    label: "Tickets por día",
                    paths: uPlot.paths.bars(),
                    points: { show: false },
                }
            ]
        };
        dailyPlotDetailed = new uPlot(dailyOpts, [[], []], dailyContainer);
        console.log('Gráfico diario detallado creado:', dailyPlotDetailed);

        console.log('Creando gráfico mensual detallado...');
        const monthlyOpts = {
            ...baseOpts,
            title: "Tickets por Mes (Detallado)",
            series: [
                {},
                {
                    stroke: (u, seriesIdx, dataIdx) => {
                        const value = u.data[seriesIdx][dataIdx];
                        const maxValue = Math.max(...u.data[seriesIdx]);
                        return getBarColor(value, maxValue);
                    },
                    width: 2,
                    fill: (u, seriesIdx, dataIdx) => {
                        const value = u.data[seriesIdx][dataIdx];
                        const maxValue = Math.max(...u.data[seriesIdx]);
                        return getBarColor(value, maxValue) + "80";
                    },
                    label: "Tickets por mes",
                    paths: uPlot.paths.bars(),
                    points: { show: false },
                }
            ]
        };
        monthlyPlotDetailed = new uPlot(monthlyOpts, [[], []], monthlyContainer);
        console.log('Gráfico mensual detallado creado:', monthlyPlotDetailed);

        // Add resize listener for both detailed plots
        window.addEventListener('resize', () => {
            if (dailyPlotDetailed && dailyContainer) {
                dailyPlotDetailed.setSize({ width: dailyContainer.offsetWidth, height: 300 });
            }
            if (monthlyPlotDetailed && monthlyContainer) {
                monthlyPlotDetailed.setSize({ width: monthlyContainer.offsetWidth, height: 300 });
            }
        });

    } catch (error) {
        console.error('Error al crear los gráficos detallados:', error);
    }
}

// Actualizar análisis detallado
async function updateDetailedAnalysis() {
    try {
        console.log('Iniciando actualización de análisis detallado...');
        const startDate = document.getElementById('startDateDetailed').value;
        const endDate = document.getElementById('endDateDetailed').value;
        console.log('Fechas de filtro detallado:', { startDate, endDate });
        
        const tickets = await getTickets();
        console.log('Tickets obtenidos para análisis detallado:', tickets.length);
        
        const currentTickets = tickets.filter(ticket => {
            const ticketDate = new Date(ticket.created_at);
            return ticketDate >= new Date(startDate) && ticketDate <= new Date(endDate + 'T23:59:59');
        });
        
        console.log('Tickets filtrados para análisis detallado:', currentTickets.length);

        // Actualizar gráficos
        const dailyData = {};
        const monthlyData = {};

        currentTickets.forEach(ticket => {
            const date = new Date(ticket.created_at);
            const dayKey = date.toISOString().slice(0, 10);
            const monthKey = date.toISOString().slice(0, 7);
            
            dailyData[dayKey] = (dailyData[dayKey] || 0) + 1;
            monthlyData[monthKey] = (monthlyData[monthKey] || 0) + 1;
        });

        // Actualizar gráfico diario
        const dailyTimestamps = [];
        const dailyValues = [];
        const startDay = new Date(startDate);
        const endDay = new Date(endDate + 'T23:59:59');
        for (let d = new Date(startDay); d <= endDay; d.setDate(d.getDate() + 1)) {
            const dayKey = d.toISOString().slice(0, 10);
            dailyTimestamps.push(d.getTime() / 1000);
            dailyValues.push(dailyData[dayKey] || 0);
        }
        console.log('Datos diarios para gráfico detallado:', { dailyTimestamps, dailyValues });

        if (dailyPlotDetailed) {
            console.log('Actualizando dailyPlotDetailed...');
            dailyPlotDetailed.setData([dailyTimestamps, dailyValues]);
        } else {
            console.error('dailyPlotDetailed no está inicializado.');
        }

        // Actualizar gráfico mensual
        const monthlyTimestamps = [];
        const monthlyValues = [];
        const startMonth = new Date(startDate);
        startMonth.setDate(1); // Establecer al primer día del mes de inicio
        const endMonth = new Date(endDate);
        endMonth.setMonth(endMonth.getMonth() + 1, 0); // Establecer al último día del mes de fin

        for (let d = new Date(startMonth); d <= endMonth; d.setMonth(d.getMonth() + 1)) {
            const monthKey = d.toISOString().slice(0, 7);
            monthlyTimestamps.push(d.getTime() / 1000);
            monthlyValues.push(monthlyData[monthKey] || 0);
        }
        console.log('Datos mensuales para gráfico detallado:', { monthlyTimestamps, monthlyValues });

        if (monthlyPlotDetailed) {
            console.log('Actualizando monthlyPlotDetailed...');
            monthlyPlotDetailed.setData([monthlyTimestamps, monthlyValues]);
        } else {
            console.error('monthlyPlotDetailed no está inicializado.');
        }

        // Análisis predictivo
        const dailyValuesArray = Object.values(dailyData);
        if (dailyValuesArray.length > 0) {
            const average = dailyValuesArray.reduce((a, b) => a + b, 0) / dailyValuesArray.length;
            const maxValue = Math.max(...dailyValuesArray);
            const minValue = Math.min(...dailyValuesArray);
            const trend = calculateTrend(dailyValuesArray);

            // Actualizar métricas
            document.getElementById('dailyAverage').textContent = `Promedio: ${average.toFixed(1)} tickets por día`;
            document.getElementById('peakDays').textContent = `Máximo: ${maxValue} tickets, Mínimo: ${minValue} tickets`;
            document.getElementById('seasonality').textContent = `Tendencia: ${trend > 0 ? '↑' : trend < 0 ? '↓' : '→'} ${Math.abs(trend).toFixed(1)}%`;

            // Actualizar análisis predictivo
            const nextMonthPrediction = predictNextMonth(dailyValuesArray, trend);
            document.getElementById('trendAnalysis').textContent = `La tendencia actual muestra ${trend > 0 ? 'un aumento' : trend < 0 ? 'una disminución' : 'estabilidad'} en el número de tickets.`;
            document.getElementById('nextMonthPrediction').textContent = `Se esperan aproximadamente ${nextMonthPrediction.toFixed(0)} tickets para el próximo mes.`;
            document.getElementById('recommendations').textContent = generateRecommendations(trend, average, maxValue);
        } else {
            document.getElementById('dailyAverage').textContent = `Sin datos`;
            document.getElementById('peakDays').textContent = `Sin datos`;
            document.getElementById('seasonality').textContent = `Sin datos`;
            document.getElementById('trendAnalysis').textContent = `No hay datos para realizar el análisis.`;
            document.getElementById('nextMonthPrediction').textContent = `No hay datos para realizar la predicción.`;
            document.getElementById('recommendations').textContent = `No hay datos para generar recomendaciones.`;
        }

        console.log('Actualización de análisis detallado completada.');

    } catch (error) {
        console.error('Error al actualizar análisis detallado:', error);
    }
}

// Calcular tendencia
function calculateTrend(values) {
    if (values.length < 2) return 0;
    const xMean = (values.length - 1) / 2;
    const yMean = values.reduce((a, b) => a + b, 0) / values.length;
    
    let numerator = 0;
    let denominator = 0;
    
    values.forEach((y, x) => {
        numerator += (x - xMean) * (y - yMean);
        denominator += Math.pow(x - xMean, 2);
    });
    
    const slope = numerator / denominator;
    return (slope / yMean) * 100;
}

// Predecir próximo mes
function predictNextMonth(values, trend) {
    const lastValue = values[values.length - 1];
    return lastValue * (1 + trend / 100);
}

// Generar recomendaciones
function generateRecommendations(trend, average, maxValue) {
    const recommendations = [];
    
    if (trend > 5) {
        recommendations.push("Considerar aumentar el personal de soporte.");
    } else if (trend < -5) {
        recommendations.push("Evaluar la eficiencia del equipo actual.");
    }
    
    if (maxValue > average * 2) {
        recommendations.push("Implementar estrategias para manejar picos de demanda.");
    }
    
    if (average > 50) {
        recommendations.push("Revisar procesos para optimizar tiempos de respuesta.");
    }
    
    return recommendations.length > 0 ? recommendations.join(" ") : "No se requieren cambios inmediatos.";
}
// Inicializar cliente de Zendesk
const client = ZAFClient.init();

// Variables globales
let groupsData = [];
let usersData = [];
let groupMembersData = [];
let allGroupsData = []; // Para almacenar todos los datos sin filtrar

// Inicializar la aplicación
async function init() {
    console.log('Iniciando Dashboard de Grupos...');
    
    // Event listeners
    setupEventListeners();
    
    // Cargar datos inicialmente
    await loadGroupsAndMembers();
}

// Configurar event listeners
function setupEventListeners() {
    document.getElementById('refreshDataBtn').addEventListener('click', async () => {
        await loadGroupsAndMembers(true);
    });
    
    document.getElementById('exportExcelBtn').addEventListener('click', exportToExcel);
    document.getElementById('groupFilter').addEventListener('input', filterGroups);
    document.getElementById('clearFilter').addEventListener('click', clearFilter);
}

// Cargar grupos y miembros
async function loadGroupsAndMembers(forceRefresh = false) {
    try {
        showLoadingState();
        updateLoadingStatus('Cargando datos...');
        
        const startTime = Date.now();
        
        // Obtener grupos y usuarios en paralelo
        const [groups, users] = await Promise.all([
            getGroups(),
            getUsers()
        ]);
        
        groupsData = groups;
        usersData = users;
        
        // Procesar datos para crear la estructura de la tabla
        groupMembersData = processGroupsAndMembers(groups, users);
        
        const loadTime = Date.now() - startTime;
        
        // Renderizar tabla
        renderGroupsTable();
        
        // Actualizar información de estado
        updateStatus(groupMembersData.length, loadTime);
        
        console.log('Datos cargados exitosamente:', {
            grupos: groups.length,
            usuarios: users.length,
            registros: groupMembersData.length,
            tiempoCarga: loadTime + 'ms'
        });
        
    } catch (error) {
        console.error('Error al cargar datos:', error);
        showErrorState(error.message);
    }
}

// Obtener todos los grupos
async function getGroups() {
    try {
        console.log('Obteniendo grupos...');
        const response = await client.request('/api/v2/groups.json');
        return response.groups || [];
    } catch (error) {
        console.error('Error al obtener grupos:', error);
        throw new Error('No se pudieron cargar los grupos');
    }
}

// Obtener todos los usuarios (admin y agent)
async function getUsers() {
    try {
        console.log('Obteniendo usuarios...');
        const response = await client.request('/api/v2/users.json?role[]=admin&role[]=agent');
        return response.users || [];
            } catch (error) {
        console.error('Error al obtener usuarios:', error);
        throw new Error('No se pudieron cargar los usuarios');
    }
}

// Procesar grupos y miembros para crear la estructura de datos de la tabla
function processGroupsAndMembers(groups, users) {
    const processedData = [];
    
    groups.forEach((group, index) => {
        // Filtrar usuarios que pertenecen a este grupo
        const groupMembers = users.filter(user => 
            user.default_group_id === group.id
        );
        
        if (groupMembers.length > 0) {
            groupMembers.forEach((member, memberIndex) => {
                processedData.push({
                    rowNumber: processedData.length + 1,
                    groupId: group.id,
                    groupName: group.name,
                    groupDescription: group.description,
                    memberId: member.id,
                    memberName: member.name,
                    memberEmail: member.email,
                    memberRole: member.role,
                    isFirstMemberOfGroup: memberIndex === 0,
                    groupMemberCount: groupMembers.length
                });
            });
        } else {
            // Grupo sin miembros
            processedData.push({
                rowNumber: processedData.length + 1,
                groupId: group.id,
                groupName: group.name,
                groupDescription: group.description,
                memberId: null,
                memberName: 'Sin miembros',
                memberEmail: '',
                memberRole: '',
                isFirstMemberOfGroup: true,
                groupMemberCount: 0
            });
        }
    });
    
    return processedData;
}

// Renderizar tabla de grupos
function renderGroupsTable() {
    const tbody = document.getElementById('groupsTableBody');
    
    if (groupMembersData.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="4" class="text-center py-5 text-muted">
                    <div class="empty-state">
                        <div class="display-1">
                            <i class="fas fa-inbox text-primary"></i>
            </div>
                        <h3 class="text-primary">No hay datos disponibles</h3>
                        <p>No se encontraron grupos con miembros en el sistema.</p>
                        <button class="btn btn-outline-primary" onclick="loadGroupsAndMembers(true)">
                            <i class="fas fa-sync-alt me-2"></i>
                            Intentar de nuevo
                        </button>
                    </div>
                </td>
            </tr>
        `;
        return;
    }

    let html = '';
    let currentGroupId = null;
    
    groupMembersData.forEach((row, index) => {
        const isNewGroup = row.groupId !== currentGroupId;
        currentGroupId = row.groupId;
        
        html += `
            <tr>
                <td class="group-id">${row.groupId}</td>
                <td>
                    ${isNewGroup ? `
                        <div class="group-name">
                            <i class="fas fa-layer-group me-2 text-primary"></i>
                            ${escapeHtml(row.groupName)}
                        </div>
                        ${row.groupDescription ? `<div class="group-description" title="${escapeHtml(row.groupDescription)}"><i class="fas fa-info-circle me-1"></i>${escapeHtml(row.groupDescription)}</div>` : ''}
                    ` : ''}
                </td>
                <td>
                    <div class="member-item">
                        <div>
                            <div class="member-name">
                                <i class="fas fa-user me-2 text-secondary"></i>
                                ${escapeHtml(row.memberName)}
                            </div>
                            ${row.memberEmail ? `<div class="member-email"><i class="fas fa-envelope me-1"></i>${escapeHtml(row.memberEmail)}</div>` : ''}
                        </div>
                    </div>
                </td>
                <td>
                    ${row.memberRole ? `
                        <span class="role-badge role-${row.memberRole}">
                            <i class="fas ${getRoleIcon(row.memberRole)} me-1"></i>
                            ${getRoleDisplayName(row.memberRole)}
                        </span>
                    ` : ''}
                </td>
            </tr>
        `;
    });
    
    tbody.innerHTML = html;
    
    // Inicializar contadores del filtro
    updateFilterCounters(groupMembersData.length, groupMembersData.length);
}

// Obtener nombre de visualización del rol
function getRoleDisplayName(role) {
    const roleNames = {
        'admin': 'Admin',
        'agent': 'Agente',
        'end-user': 'Usuario Final'
    };
    return roleNames[role] || role;
}

// Obtener icono del rol
function getRoleIcon(role) {
    const roleIcons = {
        'admin': 'fa-crown',
        'agent': 'fa-headset',
        'end-user': 'fa-user'
    };
    return roleIcons[role] || 'fa-user';
}

// Escapar HTML
function escapeHtml(text) {
    if (!text) return '';
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.toString().replace(/[&<>"']/g, m => map[m]);
}

// Función para exportar a Excel
function exportToExcel() {
    try {
        if (!groupMembersData || groupMembersData.length === 0) {
            showModal('errorModal', 'No hay datos para exportar. Por favor, carga los datos primero.');
            return;
        }
        
        // Preparar datos agrupados para Excel
        const excelData = [];
        let currentGroupId = null;
        let isFirstMemberOfGroup = true;
        
        groupMembersData.forEach((row, index) => {
            // Verificar si es un nuevo grupo
            const isNewGroup = row.groupId !== currentGroupId;
            
            if (isNewGroup) {
                currentGroupId = row.groupId;
                isFirstMemberOfGroup = true;
            }
            
            // Crear fila para Excel
            const excelRow = {
                '#': row.rowNumber,
                'Grupo': isFirstMemberOfGroup ? row.groupName : '', // Solo mostrar grupo en la primera fila
                'Integrantes': row.memberName,
                'Rol': row.memberRole ? getRoleDisplayName(row.memberRole) : 'Sin rol'
            };
            
            excelData.push(excelRow);
            isFirstMemberOfGroup = false;
        });
        
        // Crear libro de Excel
        const wb = XLSX.utils.book_new();
        const ws = XLSX.utils.json_to_sheet(excelData);
        
        // Ajustar ancho de columnas
        const colWidths = [
            { wch: 8 },  // #
            { wch: 35 }, // Grupo
            { wch: 40 }, // Integrantes
            { wch: 12 }  // Rol
        ];
        ws['!cols'] = colWidths;
        
        // Aplicar estilos a las celdas (opcional, para mejor presentación)
        const range = XLSX.utils.decode_range(ws['!ref']);
        
        // Estilo para las celdas de grupo (solo cuando tienen contenido)
        for (let R = range.s.r + 1; R <= range.e.r; ++R) {
            const groupCell = ws[XLSX.utils.encode_cell({r: R, c: 1})]; // Columna Grupo
            if (groupCell && groupCell.v && groupCell.v.trim() !== '') {
                // Esta es una celda con nombre de grupo
                if (!ws['!merges']) ws['!merges'] = [];
                
                // Encontrar cuántas filas pertenecen a este grupo
                let groupRowCount = 1;
                for (let nextR = R + 1; nextR <= range.e.r; nextR++) {
                    const nextGroupCell = ws[XLSX.utils.encode_cell({r: nextR, c: 1})];
                    if (nextGroupCell && nextGroupCell.v && nextGroupCell.v.trim() !== '') {
                        break; // Nuevo grupo encontrado
                    }
                    groupRowCount++;
                }
                
                // Fusionar celdas del grupo si hay múltiples miembros
                if (groupRowCount > 1) {
                    ws['!merges'].push({
                        s: {r: R, c: 1}, // start
                        e: {r: R + groupRowCount - 1, c: 1} // end
                    });
                }
                
                // Saltar las filas ya procesadas
                R += groupRowCount - 1;
            }
        }
        
        XLSX.utils.book_append_sheet(wb, ws, 'Grupos y Miembros');
        
        // Generar nombre de archivo con fecha y hora
        const now = new Date();
        const dateString = now.toISOString().split('T')[0];
        const timeString = now.toTimeString().split(' ')[0].replace(/:/g, '-');
        const fileName = `grupos_miembros_${dateString}_${timeString}.xlsx`;
        
        // Descargar archivo
        XLSX.writeFile(wb, fileName);
        
        // Calcular estadísticas para el mensaje
        const uniqueGroups = [...new Set(groupMembersData.map(row => row.groupId))].length;
        const totalMembers = groupMembersData.filter(row => row.memberRole).length;
        
        showModal('successModal', 
            `Archivo Excel "${fileName}" exportado exitosamente.\n\n` +
            `📊 Estadísticas:\n` +
            `• ${uniqueGroups} grupos únicos\n` +
            `• ${totalMembers} miembros totales\n` +
            `• ${excelData.length} filas en Excel\n\n` +
            `✅ Formato: Grupos agrupados sin repetición`
        );
        
    } catch (error) {
        console.error('Error exporting to Excel:', error);
        showModal('errorModal', 'Error al exportar a Excel: ' + error.message);
    }
}

// Mostrar modal
function showModal(modalId, message) {
    const modal = document.getElementById(modalId);
    const messageElement = modal.querySelector(modalId === 'errorModal' ? '#errorMessage' : '#successMessage');
    
    messageElement.textContent = message;
    
    // Usar Bootstrap modal si está disponible, sino mostrar alerta
    if (typeof bootstrap !== 'undefined') {
        new bootstrap.Modal(modal).show();
        } else {
        alert(message);
    }
}

// Mostrar estado de carga
function showLoadingState() {
    const tbody = document.getElementById('groupsTableBody');
    tbody.innerHTML = `
        <tr>
            <td colspan="4" class="text-center py-5 text-muted">
                <div class="spinner-border" role="status">
                    <span class="visually-hidden">Cargando...</span>
                        </div>
                <div class="mt-2">Cargando datos de grupos...</div>
                </td>
            </tr>
        `;
    
    document.getElementById('recordsCount').textContent = 'Total de registros: Cargando...';
}

// Mostrar estado de error
function showErrorState(message) {
    const tbody = document.getElementById('groupsTableBody');
    tbody.innerHTML = `
        <tr>
            <td colspan="4" class="text-center py-5 text-muted">
                <div class="error-row">
                    <div class="display-1 text-danger">⚠️</div>
                    <h3 class="text-danger">Error al cargar datos</h3>
                    <p>${escapeHtml(message)}</p>
                    <button class="btn btn-outline-primary" onclick="loadGroupsAndMembers(true)">
                        Reintentar
                        </button>
                    </div>
                </td>
            </tr>
        `;
    
    updateLoadingStatus('Error al cargar datos');
    document.getElementById('recordsCount').textContent = 'Total de registros: Error';
}

// Actualizar estado de carga
function updateLoadingStatus(status) {
    document.getElementById('loadingStatus').innerHTML = `<small>${status}</small>`;
}

// Actualizar información de estado
function updateStatus(recordCount, loadTime) {
    const now = new Date();
    const timeString = now.toLocaleTimeString();
    
    document.getElementById('lastUpdate').textContent = timeString;
    document.getElementById('loadTime').textContent = `${loadTime}ms`;
    document.getElementById('recordsCount').textContent = `Total de registros: ${recordCount}`;
    
    updateLoadingStatus('Datos cargados exitosamente');
}

// Función para filtrar grupos
function filterGroups() {
    const filterValue = document.getElementById('groupFilter').value.toLowerCase().trim();
    const tableBody = document.getElementById('groupsTableBody');
    const rows = tableBody.querySelectorAll('tr');
    
    let visibleCount = 0;
    const totalCount = rows.length;
    
    rows.forEach(row => {
        // Buscar en la columna del nombre del grupo (segunda columna)
        const groupNameCell = row.cells[1];
        if (groupNameCell) {
            const groupNameElement = groupNameCell.querySelector('.group-name');
            if (groupNameElement) {
                const groupName = groupNameElement.textContent.toLowerCase();
                
                if (filterValue === '' || groupName.includes(filterValue)) {
                    row.classList.remove('filtered-hidden');
                    row.style.display = '';
                    visibleCount++;
                } else {
                    row.classList.add('filtered-hidden');
                    row.style.display = 'none';
                }
            } else {
                // Si no hay nombre de grupo (fila de miembro adicional), mantener visible si el grupo anterior era visible
                const prevRow = row.previousElementSibling;
                if (prevRow && !prevRow.classList.contains('filtered-hidden')) {
                    row.classList.remove('filtered-hidden');
                    row.style.display = '';
                    visibleCount++;
                } else {
                    row.classList.add('filtered-hidden');
                    row.style.display = 'none';
                }
            }
        }
    });
    
    // Actualizar contadores
    updateFilterCounters(visibleCount, totalCount);
    
    // Mostrar mensaje si no hay resultados
    showNoResultsMessage(visibleCount, filterValue);
}

// Función para limpiar el filtro
function clearFilter() {
    document.getElementById('groupFilter').value = '';
    filterGroups();
    document.getElementById('groupFilter').focus();
}

// Función para actualizar contadores del filtro
function updateFilterCounters(visible, total) {
    document.getElementById('visibleRows').textContent = visible;
    document.getElementById('totalRows').textContent = total;
    
    // Cambiar color del badge según el filtro
    const badge = document.getElementById('filteredCount');
    if (visible < total) {
        badge.className = 'badge bg-warning';
            } else {
        badge.className = 'badge bg-secondary';
    }
}

// Función para mostrar mensaje de sin resultados
function showNoResultsMessage(visibleCount, filterValue) {
    const tableBody = document.getElementById('groupsTableBody');
    let noResultsRow = document.getElementById('noResultsRow');
    
    if (visibleCount === 0 && filterValue !== '') {
        if (!noResultsRow) {
            noResultsRow = document.createElement('tr');
            noResultsRow.id = 'noResultsRow';
            noResultsRow.innerHTML = `
                <td colspan="4" class="text-center py-4">
                    <i class="fas fa-search fa-2x text-muted mb-2"></i>
                    <div class="text-muted">
                        <strong>No se encontraron grupos</strong>
                    </div>
                    <small class="text-muted">
                        No hay grupos que coincidan con "${filterValue}"
                    </small>
                </td>
            `;
            tableBody.appendChild(noResultsRow);
        }
        noResultsRow.style.display = '';
    } else {
        if (noResultsRow) {
            noResultsRow.style.display = 'none';
        }
    }
}

// Inicializar cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', init);

// También inicializar cuando el cliente ZAF esté listo
client.on('app.registered', init); 
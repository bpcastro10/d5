const client = ZAFClient.init();
let ticketsPlot = null;
let dailyPlot = null;
let monthlyPlot = null;
let comparisonPlot1 = null;
let comparisonPlot2 = null;
let updateIntervalId = null;

// Configuración de fechas por defecto
function setDefaultDates() {
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - 30);
    
    const dateInputs = ['startDate', 'endDate', 'startDate1', 'endDate1', 'startDate2', 'endDate2'];
    dateInputs.forEach(id => {
        const input = document.getElementById(id);
        if (input) {
            input.value = id.includes('start') ? startDate.toISOString().split('T')[0] : endDate.toISOString().split('T')[0];
        }
    });
}

// Función para alternar el modo oscuro
function toggleDarkMode() {
    document.body.classList.toggle('dark-mode');
    const isDarkMode = document.body.classList.contains('dark-mode');
    localStorage.setItem('darkMode', isDarkMode);
}

// Función para controlar la sincronización automática
function togglePeriodicUpdates() {
    const syncToggleButton = document.getElementById('syncToggle');
    if (updateIntervalId) {
        clearInterval(updateIntervalId);
        updateIntervalId = null;
        syncToggleButton.textContent = 'Iniciar Sincronización';
        console.log('Sincronización automática detenida.');
    } else {
        startPeriodicUpdates();
        syncToggleButton.textContent = 'Parar Sincronización';
        console.log('Sincronización automática iniciada.');
    }
}

// Función para cambiar de página
function changePage(pageId) {
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
    });
    document.querySelector(`[data-page="${pageId}"]`).classList.add('active');

    document.getElementById('dashboard-page').classList.toggle('d-none', pageId !== 'dashboard');
    document.getElementById('comparison-page').classList.toggle('d-none', pageId !== 'comparison');

    if (pageId === 'comparison') {
        initComparisonPlots();
    }
}

// Inicializar la aplicación
async function init() {
    try {
        setDefaultDates();
        if (localStorage.getItem('darkMode') === 'true') {
            document.body.classList.add('dark-mode');
        }

        // Event listeners para navegación
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                changePage(e.target.dataset.page);
            });
        });

        // Event listeners para botones
        document.getElementById('darkModeToggle').addEventListener('click', toggleDarkMode);
        document.getElementById('syncToggle').addEventListener('click', togglePeriodicUpdates);
        document.getElementById('applyFilter').addEventListener('click', async () => {
            const startDate = document.getElementById('startDate').value;
            const endDate = document.getElementById('endDate').value;
            
            if (!startDate || !endDate || new Date(startDate) > new Date(endDate)) {
                document.getElementById('date-filter-alert').classList.remove('d-none');
                return;
            }
            
            document.getElementById('date-filter-alert').classList.add('d-none');
            await Promise.all([updateDashboard(), updateTicketsData()]);
        });

        // Event listeners para los botones de filtro de comparación
        document.querySelectorAll('.apply-filter').forEach(button => {
            button.addEventListener('click', async (e) => {
                const chartNum = e.target.dataset.chart;
                const startDate = document.getElementById(`startDate${chartNum}`).value;
                const endDate = document.getElementById(`endDate${chartNum}`).value;
                
                if (!startDate || !endDate || new Date(startDate) > new Date(endDate)) {
                    return;
                }
                
                await updateComparisonChart(chartNum, startDate, endDate);
            });
        });

        await updateDashboard();
        initTicketsPlot();
        startPeriodicUpdates();
        document.getElementById('syncToggle').textContent = 'Parar Sincronización';

    } catch (error) {
        console.error('Error al inicializar la aplicación:', error);
    }
}

document.addEventListener('DOMContentLoaded', init);

// Inicializar gráfico de tickets
function initTicketsPlot() {
    const container = document.getElementById('realtimeTrend');
    const dailyContainer = document.getElementById('dailyTrend');
    const monthlyContainer = document.getElementById('monthlyTrend');
    if (!container || !dailyContainer || !monthlyContainer) return;

    const opts = {
        width: container.offsetWidth,
        height: 300,
        title: "Tickets por Hora",
        cursor: {
            show: true,
            sync: {
                key: "ticketSync"
            }
        },
        scales: {
            x: {
                time: true,
            },
            y: {
                auto: true,
            }
        },
        axes: [
            {
                stroke: "#03363d",
                grid: { show: true, stroke: "#d8dcde" },
                ticks: { show: true, stroke: "#03363d" },
                font: "12px Arial",
                values: (self, splits) => splits.map(s => {
                    const date = new Date(s * 1000);
                    return new Intl.DateTimeFormat('es-EC', {
                        month: 'short',
                        day: 'numeric',
                        timeZone: 'America/Guayaquil'
                    }).format(date);
                }),
            },
            {
                stroke: "#03363d",
                grid: { show: true, stroke: "#d8dcde" },
                ticks: { show: true, stroke: "#03363d" },
                font: "12px Arial",
            }
        ],
        series: [
            {},
            {
                stroke: "#03363d",
                width: 2,
                fill: "rgba(3, 54, 61, 0.1)",
                label: "Tickets reales",
            },
            {
                label: "Límite superior",
                stroke: "gold",
                width: 2,
                dash: [1, 5],
            }
        ]
    };

    const dailyOpts = {
        ...opts,
        title: "Tickets por Día",
        series: [
            {},
            {
                stroke: "#03363d",
                width: 2,
                fill: "rgba(3, 54, 61, 0.1)",
                label: "Tickets por día",
                paths: uPlot.paths.bars(),
                points: { show: false },
            }
        ]
    };

    const monthlyOpts = {
        ...opts,
        title: "Tickets por Mes",
        series: [
            {},
            {
                stroke: "#03363d",
                width: 2,
                fill: "rgba(3, 54, 61, 0.1)",
                label: "Tickets por mes",
                paths: uPlot.paths.bars(),
                points: { show: false },
            }
        ]
    };

    ticketsPlot = new uPlot(opts, [[], []], container);
    dailyPlot = new uPlot(dailyOpts, [[], []], dailyContainer);
    monthlyPlot = new uPlot(monthlyOpts, [[], []], monthlyContainer);
}

// Inicializar gráficos de comparación
function initComparisonPlots() {
    const container1 = document.getElementById('chart1');
    const container2 = document.getElementById('chart2');
    if (!container1 || !container2) return;

    const opts = {
        width: container1.offsetWidth,
        height: 300,
        title: "Tickets por Día",
        cursor: {
            show: true,
            sync: {
                key: "comparisonSync"
            }
        },
        scales: {
            x: {
                time: true,
            },
            y: {
                auto: true,
            }
        },
        axes: [
            {
                stroke: "#03363d",
                grid: { show: true, stroke: "#d8dcde" },
                ticks: { show: true, stroke: "#03363d" },
                font: "12px Arial",
                values: (self, splits) => splits.map(s => {
                    const date = new Date(s * 1000);
                    return new Intl.DateTimeFormat('es-EC', {
                        month: 'short',
                        day: 'numeric',
                        timeZone: 'America/Guayaquil'
                    }).format(date);
                }),
            },
            {
                stroke: "#03363d",
                grid: { show: true, stroke: "#d8dcde" },
                ticks: { show: true, stroke: "#03363d" },
                font: "12px Arial",
            }
        ],
        series: [
            {},
            {
                stroke: "#03363d",
                width: 2,
                fill: "rgba(3, 54, 61, 0.1)",
                label: "Tickets por día",
                paths: uPlot.paths.bars(),
                points: { show: false },
            }
        ]
    };

    comparisonPlot1 = new uPlot(opts, [[], []], container1);
    comparisonPlot2 = new uPlot(opts, [[], []], container2);

    // Inicializar datos para ambos gráficos
    const startDate1 = document.getElementById('startDate1').value;
    const endDate1 = document.getElementById('endDate1').value;
    const startDate2 = document.getElementById('startDate2').value;
    const endDate2 = document.getElementById('endDate2').value;

    updateComparisonChart(1, startDate1, endDate1);
    updateComparisonChart(2, startDate2, endDate2);
}

// Actualizar gráfico de comparación
async function updateComparisonChart(chartNum, startDate, endDate) {
    try {
        const tickets = await getTickets();
        const filteredTickets = tickets.filter(ticket => {
            const ticketDate = new Date(ticket.created_at);
            return ticketDate >= new Date(startDate) && ticketDate <= new Date(endDate + 'T23:59:59');
        });

        const dailyData = {};
        filteredTickets.forEach(ticket => {
            const date = new Date(ticket.created_at);
            const dayKey = date.toISOString().split('T')[0];
            dailyData[dayKey] = (dailyData[dayKey] || 0) + 1;
        });

        const timestamps = [];
        const values = [];

        const start = new Date(startDate);
        const end = new Date(endDate + 'T23:59:59');

        for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
            const dayKey = d.toISOString().split('T')[0];
            timestamps.push(d.getTime() / 1000);
            values.push(dailyData[dayKey] || 0);
        }

        const plot = chartNum === 1 ? comparisonPlot1 : comparisonPlot2;
        if (plot) {
            plot.setData([timestamps, values]);
        }
    } catch (error) {
        console.error(`Error al actualizar gráfico de comparación ${chartNum}:`, error);
    }
}

// Obtener tickets de Zendesk
async function getTickets() {
    try {
        const response = await client.request({
            url: '/api/v2/tickets.json',
            type: 'GET',
            contentType: 'application/json',
            headers: {
                'Accept': 'application/json'
            }
        });
        return response.tickets || [];
    } catch (error) {
        console.error('Error al obtener tickets:', error);
        return [];
    }
}

// Actualizar datos del gráfico principal
async function updateTicketsData() {
    try {
        const startDate = document.getElementById('startDate').value;
        const endDate = document.getElementById('endDate').value;
        
        const tickets = await getTickets();
        const currentTickets = tickets.filter(ticket => {
            const ticketDate = new Date(ticket.created_at);
            return ticketDate >= new Date(startDate) && ticketDate <= new Date(endDate + 'T23:59:59');
        });
        
        // Datos por hora
        const hourlyData = {};
        // Datos por día
        const dailyData = {};
        // Datos por mes
        const monthlyData = {};

        currentTickets.forEach(ticket => {
            const date = new Date(ticket.created_at);
            const hourKey = date.toISOString().slice(0, 13);
            const dayKey = date.toISOString().slice(0, 10);
            const monthKey = date.toISOString().slice(0, 7);
            
            hourlyData[hourKey] = (hourlyData[hourKey] || 0) + 1;
            dailyData[dayKey] = (dailyData[dayKey] || 0) + 1;
            monthlyData[monthKey] = (monthlyData[monthKey] || 0) + 1;
        });

        // Actualizar gráfico por hora
        const timestamps = [];
        const values = [];
        const superiorLimitValues = [];

        const start = new Date(startDate);
        const end = new Date(endDate + 'T23:59:59');
        const SUPERIOR_LIMIT_VALUE = 12;

        for (let d = new Date(start); d <= end; d.setHours(d.getHours() + 1)) {
            const hourKey = d.toISOString().slice(0, 13);
            timestamps.push(d.getTime() / 1000);
            values.push(hourlyData[hourKey] || 0);
            superiorLimitValues.push(SUPERIOR_LIMIT_VALUE);
        }

        if (ticketsPlot) {
            ticketsPlot.setData([timestamps, values, superiorLimitValues]);
        }

        // Actualizar gráfico por día
        const dailyTimestamps = [];
        const dailyValues = [];
        for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
            const dayKey = d.toISOString().slice(0, 10);
            dailyTimestamps.push(d.getTime() / 1000);
            dailyValues.push(dailyData[dayKey] || 0);
        }

        if (dailyPlot) {
            dailyPlot.setData([dailyTimestamps, dailyValues]);
        }

        // Actualizar gráfico por mes
        const monthlyTimestamps = [];
        const monthlyValues = [];
        const firstDayOfMonth = new Date(start.getFullYear(), start.getMonth(), 1);
        const lastDayOfMonth = new Date(end.getFullYear(), end.getMonth() + 1, 0);

        for (let d = new Date(firstDayOfMonth); d <= lastDayOfMonth; d.setMonth(d.getMonth() + 1)) {
            const monthKey = d.toISOString().slice(0, 7);
            monthlyTimestamps.push(d.getTime() / 1000);
            monthlyValues.push(monthlyData[monthKey] || 0);
        }

        if (monthlyPlot) {
            monthlyPlot.setData([monthlyTimestamps, monthlyValues]);
        }
    } catch (error) {
        console.error('Error al actualizar datos del gráfico:', error);
    }
}

// Iniciar actualizaciones periódicas
function startPeriodicUpdates() {
    updateTicketsData();
    if (updateIntervalId) {
        clearInterval(updateIntervalId);
    }
    updateIntervalId = setInterval(updateTicketsData, 300000);
}

// Actualizar el dashboard
async function updateDashboard() {
    try {
        const startDate = document.getElementById('startDate').value;
        const endDate = document.getElementById('endDate').value;
        
        const tickets = await getTickets();
        const filteredTickets = tickets.filter(ticket => {
            const ticketDate = new Date(ticket.created_at);
            return ticketDate >= new Date(startDate) && ticketDate <= new Date(endDate + 'T23:59:59');
        });
        
        const data = analyzeTickets(filteredTickets);
        updateMetrics(data);
    } catch (error) {
        console.error('Error al actualizar el dashboard:', error);
    }
}

// Analizar tickets
function analyzeTickets(tickets) {
    const today = new Date().toISOString().split('T')[0];
    const totalTickets = tickets.length;
    const ticketsToday = tickets.filter(t => t.created_at.startsWith(today)).length;
    const pendingTickets = tickets.filter(t => t.status === 'pending').length;
    const resolvedTickets = tickets.filter(t => t.status === 'solved').length;
    const resolutionRate = totalTickets > 0 ? (resolvedTickets / totalTickets * 100).toFixed(1) : 0;

    return {
        totalTickets,
        ticketsToday,
        pendingTickets,
        resolutionRate
    };
}

// Actualizar métricas
function updateMetrics(data) {
    document.getElementById('total-tickets').textContent = data.totalTickets;
    document.getElementById('tickets-hoy').textContent = data.ticketsToday;
    document.getElementById('tickets-pendientes').textContent = data.pendingTickets;
    document.getElementById('tasa-resolucion').textContent = `${data.resolutionRate}%`;
}
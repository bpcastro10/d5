// Inicializar cliente de Zendesk
const client = ZAFClient.init();

// Variables globales para Dashboard de Grupos
let groupsData = [];
let usersData = [];
let groupMembersData = [];
let allGroupsData = []; // Para almacenar todos los datos sin filtrar

// Variables globales para Licencias
let licensesData = [];
let groupMembershipsData = [];
let accountSettingsData = {};
let processedLicensesData = [];
let customRolesData = [];
let licensingData = {};

// Variables globales para paginación de grupos
let groupsCurrentPage = 1;
let groupsPageSize = 25;
let groupsFilteredData = [];

// Variables globales para paginación de licencias
let licensesCurrentPage = 1;
let licensesPageSize = 25;
let licensesFilteredData = [];

// Inicializar la aplicación
async function init() {
    console.log('Iniciando Dashboard de Gestión...');
    
    // Event listeners
    setupEventListeners();
    
    // Cargar datos inicialmente solo del dashboard activo
    await loadGroupsAndMembers();
}

// Configurar event listeners
function setupEventListeners() {
    // Event listeners para Dashboard de Grupos
    document.getElementById('refreshDataBtn').addEventListener('click', async () => {
        await loadGroupsAndMembers(true);
    });
    
    document.getElementById('exportExcelBtn').addEventListener('click', exportToExcel);
    document.getElementById('groupFilter').addEventListener('input', filterGroups);
    document.getElementById('clearFilter').addEventListener('click', clearFilter);
    
    // Event listeners para Licencias
    document.getElementById('refreshLicensesBtn').addEventListener('click', async () => {
        await loadLicensesData(true);
    });
    
    document.getElementById('exportLicensesExcelBtn').addEventListener('click', exportLicensesToExcel);
    document.getElementById('licensesFilter').addEventListener('input', filterLicenses);
    document.getElementById('clearLicensesFilter').addEventListener('click', clearLicensesFilter);
    
    // Event listeners para paginación de grupos
    document.getElementById('groupsPageSize').addEventListener('change', function() {
        groupsPageSize = parseInt(this.value);
        groupsCurrentPage = 1;
        renderGroupsTable();
    });
    
    // Event listeners para paginación de licencias
    document.getElementById('licensesPageSize').addEventListener('change', function() {
        licensesPageSize = parseInt(this.value);
        licensesCurrentPage = 1;
        renderLicensesTable();
    });
    
    // Event listener para cambio de pestañas
    document.getElementById('nav-licenses-tab').addEventListener('shown.bs.tab', async function (event) {
        // Cargar datos de licencias cuando se activa la pestaña por primera vez
        if (processedLicensesData.length === 0) {
            await loadLicensesData();
        }
    });
}

// ==========================================
// FUNCIONES PARA DASHBOARD DE GRUPOS
// ==========================================

// Cargar grupos y miembros
async function loadGroupsAndMembers(forceRefresh = false) {
    try {
        showLoadingState();
        updateLoadingStatus('Cargando datos...');
        
        const startTime = Date.now();
        
        // Obtener grupos y usuarios en paralelo
        const [groups, users] = await Promise.all([
            getGroups(),
            getUsers()
        ]);
        
        groupsData = groups;
        usersData = users;
        
        // Procesar datos para crear la estructura de la tabla
        groupMembersData = processGroupsAndMembers(groups, users);
        
        const loadTime = Date.now() - startTime;
        
        // Renderizar tabla
        renderGroupsTable();
        
        // Actualizar información de estado
        updateStatus(groupMembersData.length, loadTime);
        
        console.log('Datos cargados exitosamente:', {
            grupos: groups.length,
            usuarios: users.length,
            registros: groupMembersData.length,
            tiempoCarga: loadTime + 'ms'
        });
        
    } catch (error) {
        console.error('Error al cargar datos:', error);
        showErrorState(error.message);
    }
}

// Obtener todos los grupos
async function getGroups() {
    try {
        console.log('Obteniendo grupos...');
        const response = await client.request('/api/v2/groups.json');
        return response.groups || [];
    } catch (error) {
        console.error('Error al obtener grupos:', error);
        throw new Error('No se pudieron cargar los grupos');
    }
}

// Obtener todos los usuarios (admin y agent)
async function getUsers() {
    try {
        console.log('Obteniendo usuarios...');
        const response = await client.request('/api/v2/users.json?role[]=admin&role[]=agent');
        return response.users || [];
            } catch (error) {
        console.error('Error al obtener usuarios:', error);
        throw new Error('No se pudieron cargar los usuarios');
    }
}

// Procesar grupos y miembros para crear la estructura de datos de la tabla
function processGroupsAndMembers(groups, users) {
    const processedData = [];
    
    groups.forEach((group, index) => {
        // Filtrar usuarios que pertenecen a este grupo
        const groupMembers = users.filter(user => 
            user.default_group_id === group.id
        );
        
        if (groupMembers.length > 0) {
            groupMembers.forEach((member, memberIndex) => {
                processedData.push({
                    rowNumber: processedData.length + 1,
                    groupId: group.id,
                    groupName: group.name,
                    groupDescription: group.description,
                    memberId: member.id,
                    memberName: member.name,
                    memberEmail: member.email,
                    memberRole: member.role,
                    isFirstMemberOfGroup: memberIndex === 0,
                    groupMemberCount: groupMembers.length
                });
            });
        } else {
            // Grupo sin miembros
            processedData.push({
                rowNumber: processedData.length + 1,
                groupId: group.id,
                groupName: group.name,
                groupDescription: group.description,
                memberId: null,
                memberName: 'Sin miembros',
                memberEmail: '',
                memberRole: '',
                isFirstMemberOfGroup: true,
                groupMemberCount: 0
            });
        }
    });
    
    return processedData;
}

// ==========================================
// FUNCIONES DE PAGINACIÓN
// ==========================================

// Función genérica para crear controles de paginación
function createPaginationControls(containerId, currentPage, totalPages, onPageChange) {
    const container = document.getElementById(containerId);
    if (!container) return;
    
    let html = '';
    
    // Botón anterior
    const prevDisabled = currentPage <= 1 ? 'disabled' : '';
    html += `
        <li class="page-item ${prevDisabled}">
            <a class="page-link" href="#" onclick="${onPageChange}(${currentPage - 1}); return false;">
                <i class="fas fa-chevron-left"></i>
            </a>
        </li>
    `;
    
    // Números de página
    const maxVisiblePages = 5;
    let startPage = Math.max(1, currentPage - Math.floor(maxVisiblePages / 2));
    let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);
    
    // Ajustar startPage si estamos cerca del final
    if (endPage - startPage < maxVisiblePages - 1) {
        startPage = Math.max(1, endPage - maxVisiblePages + 1);
    }
    
    // Primera página si no está visible
    if (startPage > 1) {
        html += `
            <li class="page-item">
                <a class="page-link" href="#" onclick="${onPageChange}(1); return false;">1</a>
            </li>
        `;
        if (startPage > 2) {
            html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
        }
    }
    
    // Páginas visibles
    for (let i = startPage; i <= endPage; i++) {
        const activeClass = i === currentPage ? 'active' : '';
        html += `
            <li class="page-item ${activeClass}">
                <a class="page-link" href="#" onclick="${onPageChange}(${i}); return false;">${i}</a>
            </li>
        `;
    }
    
    // Última página si no está visible
    if (endPage < totalPages) {
        if (endPage < totalPages - 1) {
            html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
        }
        html += `
            <li class="page-item">
                <a class="page-link" href="#" onclick="${onPageChange}(${totalPages}); return false;">${totalPages}</a>
            </li>
        `;
    }
    
    // Botón siguiente
    const nextDisabled = currentPage >= totalPages ? 'disabled' : '';
    html += `
        <li class="page-item ${nextDisabled}">
            <a class="page-link" href="#" onclick="${onPageChange}(${currentPage + 1}); return false;">
                <i class="fas fa-chevron-right"></i>
            </a>
        </li>
    `;
    
    container.innerHTML = html;
}

// Función para ir a página específica de grupos
function goToGroupsPage(page) {
    const totalPages = Math.ceil(groupsFilteredData.length / groupsPageSize);
    if (page < 1 || page > totalPages) return;
    
    groupsCurrentPage = page;
    renderGroupsTable();
}

// Función para ir a página específica de licencias
function goToLicensesPage(page) {
    const totalPages = Math.ceil(licensesFilteredData.length / licensesPageSize);
    if (page < 1 || page > totalPages) return;
    
    licensesCurrentPage = page;
    renderLicensesTable();
}

// Función para actualizar información de página
function updatePageInfo(infoElementId, currentPage, pageSize, totalItems) {
    const startItem = totalItems > 0 ? (currentPage - 1) * pageSize + 1 : 0;
    const endItem = Math.min(currentPage * pageSize, totalItems);
    
    const infoElement = document.getElementById(infoElementId);
    if (infoElement) {
        infoElement.textContent = `Mostrando  ${startItem} de ${totalItems} paginas`;
    }
}

// Renderizar tabla de grupos
function renderGroupsTable() {
    const tbody = document.getElementById('groupsTableBody');
    
    // Si no hay datos, mostrar estado vacío
    if (groupMembersData.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="4" class="text-center py-5 text-muted">
                    <div class="empty-state">
                        <div class="display-1">
                            <i class="fas fa-inbox text-primary"></i>
            </div>
                        <h3 class="text-primary">No hay datos disponibles</h3>
                        <p>No se encontraron grupos con miembros en el sistema.</p>
                        <button class="btn btn-outline-primary" onclick="loadGroupsAndMembers(true)">
                            <i class="fas fa-sync-alt me-2"></i>
                            Intentar de nuevo
                        </button>
                    </div>
                </td>
            </tr>
        `;
        
        // Limpiar controles de paginación
        document.getElementById('groupsPagination').innerHTML = '';
        updatePageInfo('groupsPageInfo', 0, 0, 0);
        updateFilterCounters(0, 0);
        return;
    }

    // Aplicar filtro actual
    applyGroupsFilter();
    
    // Calcular paginación
    const totalPages = Math.ceil(groupsFilteredData.length / groupsPageSize);
    const startIndex = (groupsCurrentPage - 1) * groupsPageSize;
    const endIndex = startIndex + groupsPageSize;
    const pageData = groupsFilteredData.slice(startIndex, endIndex);

    // Si no hay datos en la página actual, ir a la primera página
    if (pageData.length === 0 && groupsFilteredData.length > 0) {
        groupsCurrentPage = 1;
        renderGroupsTable();
        return;
    }
    
    // Si no hay datos filtrados, mostrar mensaje de sin resultados
    if (groupsFilteredData.length === 0) {
        const filterValue = document.getElementById('groupFilter').value.trim();
        tbody.innerHTML = `
            <tr>
                <td colspan="4" class="text-center py-4">
                    <i class="fas fa-search fa-2x text-muted mb-2"></i>
                    <div class="text-muted">
                        <strong>No se encontraron grupos</strong>
                    </div>
                    <small class="text-muted">
                        No hay grupos que coincidan con "${escapeHtml(filterValue)}"
                    </small>
                </td>
            </tr>
        `;
        
        // Limpiar controles de paginación
        document.getElementById('groupsPagination').innerHTML = '';
        updatePageInfo('groupsPageInfo', 0, 0, 0);
        updateFilterCounters(0, groupMembersData.length);
        return;
    }

    let html = '';
    let currentGroupId = null;
    
    pageData.forEach((row, index) => {
        const isNewGroup = row.groupId !== currentGroupId;
        currentGroupId = row.groupId;
        
        html += `
            <tr>
                <td class="group-id">${row.groupId}</td>
                <td>
                    ${isNewGroup ? `
                        <div class="group-name">
                            <i class="fas fa-layer-group me-2 text-primary"></i>
                            ${escapeHtml(row.groupName)}
                        </div>
                        ${row.groupDescription ? `<div class="group-description" title="${escapeHtml(row.groupDescription)}"><i class="fas fa-info-circle me-1"></i>${escapeHtml(row.groupDescription)}</div>` : ''}
                    ` : ''}
                </td>
                <td>
                    <div class="member-item">
                        <div>
                            <div class="member-name">
                                <i class="fas fa-user me-2 text-secondary"></i>
                                ${escapeHtml(row.memberName)}
                            </div>
                            ${row.memberEmail ? `<div class="member-email"><i class="fas fa-envelope me-1"></i>${escapeHtml(row.memberEmail)}</div>` : ''}
                        </div>
                    </div>
                </td>
                <td>
                    ${row.memberRole ? `
                        <span class="role-badge role-${row.memberRole}">
                            <i class="fas ${getRoleIcon(row.memberRole)} me-1"></i>
                            ${getRoleDisplayName(row.memberRole)}
                        </span>
                    ` : ''}
                </td>
            </tr>
        `;
    });
    
    tbody.innerHTML = html;
    
    // Actualizar controles de paginación
    createPaginationControls('groupsPagination', groupsCurrentPage, totalPages, 'goToGroupsPage');
    updatePageInfo('groupsPageInfo', groupsCurrentPage, groupsPageSize, groupsFilteredData.length);
    
    // Actualizar contadores del filtro
    updateFilterCounters(groupsFilteredData.length, groupMembersData.length);
}

// Obtener nombre de visualización del rol
function getRoleDisplayName(role, customRoleName = null) {
    // Si hay un nombre de rol personalizado, usarlo
    if (customRoleName) {
        return customRoleName;
    }
    
    // Mapeo de roles estándar
    const standardRoles = {
        'admin': 'Admin',
        'agent': 'Agente',
        'end-user': 'Usuario Final'
    };
    
    // Si es un rol estándar, devolverlo
    if (standardRoles[role]) {
        return standardRoles[role];
    }
    
    // Para roles personalizados sin nombre, aplicar formato
    if (role) {
        // Casos específicos conocidos
        if (role.toLowerCase().includes('light') && role.toLowerCase().includes('agent')) {
            return 'Agente Light';
        }
        
        if (role.includes('GA_CRM_INGRESADOR_CALLCENTER')) {
            return 'GA_CRM_INGRESADOR_CALLCENTER';
        }
        
        // Para otros roles personalizados, formatear el texto
        return role.split('_')
                  .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
                  .join(' ');
    }
    
    return 'Sin rol';
}

// Obtener icono del rol
function getRoleIcon(role) {
    const roleIcons = {
        'admin': 'fa-crown',
        'agent': 'fa-headset',
        'end-user': 'fa-user'
    };
    return roleIcons[role] || 'fa-user';
}

// Escapar HTML
function escapeHtml(text) {
    if (!text) return '';
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.toString().replace(/[&<>"']/g, m => map[m]);
}

// Función para exportar a Excel
function exportToExcel() {
    try {
        if (!groupMembersData || groupMembersData.length === 0) {
            showModal('errorModal', 'No hay datos para exportar. Por favor, carga los datos primero.');
            return;
        }
        
        // Usar los datos ya filtrados por el sistema de paginación
        applyGroupsFilter(); // Asegurar que el filtro está aplicado
        const dataToExport = groupsFilteredData;
        const isFilterActive = document.getElementById('groupFilter').value.trim() !== '';
        
        if (dataToExport.length === 0) {
            showModal('errorModal', 'No hay datos que coincidan con el filtro actual para exportar.');
            return;
        }
        
        // Preparar datos para Excel
        const excelData = [];
        
        dataToExport.forEach((row, index) => {
            // Crear fila para Excel - SIEMPRE incluir el nombre del grupo
            const excelRow = {
                'ID': row.groupId, // Usar ID del grupo en lugar de #
                'Grupo': row.groupName, // SIEMPRE mostrar el nombre del grupo en cada fila
                'Integrantes': row.memberName,
                'Rol': row.memberRole ? getRoleDisplayName(row.memberRole) : 'Sin rol'
            };
            
            excelData.push(excelRow);
        });
        
        // Crear libro de Excel
        const wb = XLSX.utils.book_new();
        const ws = XLSX.utils.json_to_sheet(excelData);
        
        // Ajustar ancho de columnas
        const colWidths = [
            { wch: 8 },  // ID
            { wch: 35 }, // Grupo
            { wch: 40 }, // Integrantes
            { wch: 12 }  // Rol
        ];
        ws['!cols'] = colWidths;
        
        // Aplicar estilos a las celdas (opcional, para mejor presentación)
        const range = XLSX.utils.decode_range(ws['!ref']);
        
        // Estilo para las celdas de grupo (solo cuando tienen contenido)
        for (let R = range.s.r + 1; R <= range.e.r; ++R) {
            const groupCell = ws[XLSX.utils.encode_cell({r: R, c: 1})]; // Columna Grupo
            if (groupCell && groupCell.v && groupCell.v.trim() !== '') {
                // Esta es una celda con nombre de grupo
                if (!ws['!merges']) ws['!merges'] = [];
                
                // Encontrar cuántas filas pertenecen a este grupo
                let groupRowCount = 1;
                for (let nextR = R + 1; nextR <= range.e.r; nextR++) {
                    const nextGroupCell = ws[XLSX.utils.encode_cell({r: nextR, c: 1})];
                    if (nextGroupCell && nextGroupCell.v && nextGroupCell.v.trim() !== '') {
                        break; // Nuevo grupo encontrado
                    }
                    groupRowCount++;
                }
                
                // Fusionar celdas del grupo si hay múltiples miembros
                if (groupRowCount > 1) {
                    ws['!merges'].push({
                        s: {r: R, c: 1}, // start
                        e: {r: R + groupRowCount - 1, c: 1} // end
                    });
                }
                
                // Saltar las filas ya procesadas
                R += groupRowCount - 1;
            }
        }
        
        XLSX.utils.book_append_sheet(wb, ws, 'Grupos y Miembros');
        
        // Generar nombre de archivo con fecha y hora
        const now = new Date();
        const dateString = now.toISOString().split('T')[0];
        const timeString = now.toTimeString().split(' ')[0].replace(/:/g, '-');
        
        // Obtener el valor del filtro
        const filterValue = document.getElementById('groupFilter').value.trim();
        
        // Agregar sufijo si hay filtro activo
        const filterSuffix = isFilterActive ? `_filtrado_${filterValue.replace(/\s+/g, '_')}` : '';
        const fileName = `grupos_miembros${filterSuffix}_${dateString}_${timeString}.xlsx`;
        
        // Descargar archivo
        XLSX.writeFile(wb, fileName);
        
        // Calcular estadísticas para el mensaje
        const uniqueGroups = [...new Set(dataToExport.map(row => row.groupId))].length;
        const totalMembers = dataToExport.filter(row => row.memberRole).length;
        
        // Mensaje personalizado según si hay filtro o no
        let successMessage = `Archivo Excel "${fileName}" exportado exitosamente.\n\n`;
        
        if (isFilterActive) {
            successMessage += `🔍 Exportación filtrada por: "${filterValue}"\n\n`;
        }
        
        successMessage += `Estadísticas:\n` +
            `• ${uniqueGroups} grupos únicos\n` +
            `• ${totalMembers} miembros totales\n` +
            `• ${excelData.length} filas en Excel\n\n` +
            `Formato: Cada fila con nombre de grupo (compatible con filtros de Excel)`;
        
        showModal('successModal', successMessage);
        
    } catch (error) {
        console.error('Error exporting to Excel:', error);
        showModal('errorModal', 'Error al exportar a Excel: ' + error.message);
    }
}

// Mostrar modal
function showModal(modalId, message) {
    const modal = document.getElementById(modalId);
    const messageElement = modal.querySelector(modalId === 'errorModal' ? '#errorMessage' : '#successMessage');
    
    messageElement.textContent = message;
    
    // Usar Bootstrap modal si está disponible, sino mostrar alerta
    if (typeof bootstrap !== 'undefined') {
        new bootstrap.Modal(modal).show();
        } else {
        alert(message);
    }
}

// Mostrar estado de carga
function showLoadingState() {
    const tbody = document.getElementById('groupsTableBody');
    tbody.innerHTML = `
        <tr>
            <td colspan="4" class="text-center py-5 text-muted">
                <div class="spinner-border" role="status">
                    <span class="visually-hidden">Cargando...</span>
                        </div>
                <div class="mt-2">Cargando datos de grupos...</div>
                </td>
            </tr>
        `;
    
    document.getElementById('recordsCount').textContent = 'Total de registros: Cargando...';
}

// Mostrar estado de error
function showErrorState(message) {
    const tbody = document.getElementById('groupsTableBody');
    tbody.innerHTML = `
        <tr>
            <td colspan="4" class="text-center py-5 text-muted">
                <div class="error-row">
                    <div class="display-1 text-danger">⚠️</div>
                    <h3 class="text-danger">Error al cargar datos</h3>
                    <p>${escapeHtml(message)}</p>
                    <button class="btn btn-outline-primary" onclick="loadGroupsAndMembers(true)">
                        Reintentar
                        </button>
                    </div>
                </td>
            </tr>
        `;
    
    updateLoadingStatus('Error al cargar datos');
    document.getElementById('recordsCount').textContent = 'Total de registros: Error';
}

// Actualizar estado de carga
function updateLoadingStatus(status) {
    document.getElementById('loadingStatus').innerHTML = `<small>${status}</small>`;
}

// Actualizar información de estado
function updateStatus(recordCount, loadTime) {
    const now = new Date();
    const timeString = now.toLocaleTimeString();
    
    document.getElementById('lastUpdate').textContent = timeString;
    document.getElementById('loadTime').textContent = `${loadTime}ms`;
    document.getElementById('recordsCount').textContent = `Total de registros: ${recordCount}`;
    
    updateLoadingStatus('Datos cargados exitosamente');
}

// Función para aplicar filtro a los datos de grupos
function applyGroupsFilter() {
    const filterValue = document.getElementById('groupFilter').value.toLowerCase().trim();
    
    if (filterValue === '') {
        groupsFilteredData = [...groupMembersData];
                } else {
        groupsFilteredData = groupMembersData.filter(row => {
            const groupName = row.groupName.toLowerCase();
            return groupName.includes(filterValue);
        });
    }
}

// Función para filtrar grupos (nueva versión con paginación)
function filterGroups() {
    groupsCurrentPage = 1; // Resetear a la primera página cuando se filtra
    renderGroupsTable();
}

// Función para limpiar el filtro
function clearFilter() {
    document.getElementById('groupFilter').value = '';
    filterGroups();
    document.getElementById('groupFilter').focus();
}

// Función para actualizar contadores del filtro
function updateFilterCounters(visible, total) {
    document.getElementById('visibleRows').textContent = visible;
    document.getElementById('totalRows').textContent = total;
    
    // Cambiar color del badge según el filtro
    const badge = document.getElementById('filteredCount');
    if (visible < total) {
        badge.className = 'badge bg-warning';
            } else {
        badge.className = 'badge bg-secondary';
    }
}

// Función para mostrar mensaje de sin resultados (ahora se integra en renderGroupsTable)
function showNoResultsMessage(visibleCount, filterValue) {
    // Esta función ahora se maneja directamente en renderGroupsTable
    // Se mantiene por compatibilidad pero no se usa
}

// ==========================================
// FUNCIONES PARA LICENCIAS
// ==========================================

// Cargar datos de licencias
async function loadLicensesData(forceRefresh = false) {
    try {
        showLicensesLoadingState();
        updateLicensesLoadingStatus('Cargando datos de licencias...');
        
        const startTime = Date.now();
        
        // Obtener datos en paralelo
        const [users, groups, groupMemberships, accountSettings, customRoles, licensing] = await Promise.all([
            getLicensesUsers(),
            getLicensesGroups(),
            getGroupMemberships(),
            getAccountSettings(),
            getCustomRoles(),
            getLicensingInformation()
        ]);
        
        licensesData = users;
        groupsData = groups;
        groupMembershipsData = groupMemberships;
        accountSettingsData = accountSettings;
        customRolesData = customRoles;
        licensingData = licensing;
        
        // Procesar datos para crear la estructura de la tabla de licencias
        processedLicensesData = processLicensesData(users, groups, groupMemberships, accountSettings, customRoles);
        
        const loadTime = Date.now() - startTime;
        
        // Renderizar el resumen de licencias
        renderLicensesOverview(users, licensing, customRoles);
        
        // Renderizar tabla
        renderLicensesTable();
        
        // Actualizar información de estado
        updateLicensesStatus(processedLicensesData.length, loadTime);
        
        console.log('Datos de licencias cargados exitosamente:', {
            usuarios: users.length,
            grupos: groups.length,
            membresías: groupMemberships.length,
            rolesPersonalizados: customRoles.length,
            registros: processedLicensesData.length,
            tiempoCarga: loadTime + 'ms'
        });
        
    } catch (error) {
        console.error('Error al cargar datos de licencias:', error);
        showLicensesErrorState(error.message);
    }
}

// Obtener usuarios para licencias (todos los roles)
async function getLicensesUsers() {
    try {
        console.log('Obteniendo usuarios para licencias...');
        
        // Obtener usuarios con más detalles incluyendo custom roles
        const response = await client.request('/api/v2/users.json?include=identities,organizations');
        let users = response.users || [];
        
        console.log(`Obtenidos ${users.length} usuarios`);
        
        // Si hay más páginas, obtenerlas también
        let nextPage = response.next_page;
        while (nextPage && users.length < 1000) { // Limitar para evitar demasiadas llamadas
            try {
                const nextResponse = await client.request(nextPage);
                if (nextResponse.users && nextResponse.users.length > 0) {
                    users = users.concat(nextResponse.users);
                    nextPage = nextResponse.next_page;
                } else {
                    break;
                }
            } catch (error) {
                console.warn('Error obteniendo página adicional de usuarios:', error);
                break;
            }
        }
        
        console.log(`Total de usuarios obtenidos: ${users.length}`);
        return users;
        
    } catch (error) {
        console.error('Error al obtener usuarios para licencias:', error);
        throw new Error('No se pudieron cargar los usuarios para licencias');
    }
}

// Obtener grupos para licencias
async function getLicensesGroups() {
    try {
        console.log('Obteniendo grupos para licencias...');
        const response = await client.request('/api/v2/groups.json');
        return response.groups || [];
    } catch (error) {
        console.error('Error al obtener grupos para licencias:', error);
        throw new Error('No se pudieron cargar los grupos para licencias');
    }
}

// Obtener membresías de grupos
async function getGroupMemberships() {
    try {
        console.log('Obteniendo membresías de grupos...');
        const response = await client.request('/api/v2/group_memberships.json');
        return response.group_memberships || [];
    } catch (error) {
        console.error('Error al obtener membresías de grupos:', error);
        throw new Error('No se pudieron cargar las membresías de grupos');
    }
}

// Obtener configuración de cuenta
async function getAccountSettings() {
    try {
        console.log('Obteniendo configuración de cuenta...');
        const response = await client.request('/api/v2/account/settings.json');
        return response.settings || {};
    } catch (error) {
        console.error('Error al obtener configuración de cuenta:', error);
        // No lanzar error ya que no es crítico
        return {};
    }
}

// Obtener roles personalizados
async function getCustomRoles() {
    try {
        console.log('Obteniendo roles personalizados...');
        const response = await client.request('/api/v2/custom_roles.json');
        return response.custom_roles || [];
    } catch (error) {
        console.warn('Error al obtener roles personalizados (puede no estar disponible):', error);
        return [];
    }
}

// Obtener información de licencias
async function getLicensingInformation() {
    try {
        console.log('Obteniendo información de licencias...');
        
        // Intentar obtener información de licencias desde diferentes endpoints
        let licensingInfo = {};
        
        try {
            // Endpoint principal de licencias (puede no estar disponible en todas las instancias)
            const response = await client.request('/api/v2/account/licensing.json');
            licensingInfo = response.licensing || {};
        } catch (error) {
            console.warn('Endpoint de licensing no disponible, usando datos alternativos');
            
            // Si no está disponible, usar información de la cuenta
            try {
                const accountResponse = await client.request('/api/v2/account.json');
                licensingInfo = {
                    account: accountResponse.account || {},
                    fallback: true
                };
            } catch (accountError) {
                console.warn('No se pudo obtener información de cuenta:', accountError);
            }
        }
        
        return licensingInfo;
        
    } catch (error) {
        console.warn('Error al obtener información de licencias:', error);
        return {};
    }
}

// Procesar datos de licencias
function processLicensesData(users, groups, groupMemberships, accountSettings, customRoles) {
    const processedData = [];
    
    // Crear un mapa de grupos para acceso rápido
    const groupsMap = {};
    groups.forEach(group => {
        groupsMap[group.id] = group;
    });
    
    // Crear mapa de roles personalizados
    const customRolesMap = {};
    customRoles.forEach(role => {
        customRolesMap[role.id] = role;
    });
    
    // Crear mapa de membresías por usuario
    const membershipsByUser = {};
    groupMemberships.forEach(membership => {
        if (!membershipsByUser[membership.user_id]) {
            membershipsByUser[membership.user_id] = [];
        }
        membershipsByUser[membership.user_id].push(membership);
    });
    
    users.forEach((user, index) => {
        // Obtener grupos del usuario
        const userMemberships = membershipsByUser[user.id] || [];
        const userGroups = userMemberships.map(membership => {
            const group = groupsMap[membership.group_id];
            return group ? group.name : 'Grupo desconocido';
        });
        
        // Si el usuario tiene un default_group_id pero no aparece en memberships, agregarlo
        if (user.default_group_id && !userGroups.length) {
            const defaultGroup = groupsMap[user.default_group_id];
            if (defaultGroup) {
                userGroups.push(defaultGroup.name);
            }
        }
        
        // Determinar el rol real del usuario
        let userRole = user.role || 'end-user';
        let customRoleName = null;
        
        // Verificar si es un rol personalizado basado en custom_role_id
        if (user.custom_role_id && user.custom_role_id !== null) {
            const customRole = customRolesMap[user.custom_role_id];
            if (customRole) {
                customRoleName = customRole.name;
                userRole = customRole.name;
            }
        }
        
        // Determinar acceso a productos basado en el rol y configuración
        const productAccess = getProductAccess(user, accountSettings, customRoleName);
        
        // Formatear último inicio de sesión
        const lastLogin = formatLastLogin(user.last_login_at);
        
        // Determinar estado de actividad
        const isActive = user.active !== false && user.suspended !== true;
        
        // Verificar si el email está verificado
        const isVerified = user.verified === true;
        
        processedData.push({
            rowNumber: index + 1,
            userId: user.id,
            userName: user.name || 'Sin nombre',
            userEmail: user.email || 'Sin email',
            userRole: userRole,
            customRoleName: customRoleName,
            groups: userGroups.length > 0 ? userGroups.join(', ') : 'Sin grupo',
            productAccess: productAccess,
            lastLogin: lastLogin,
            lastLoginRaw: user.last_login_at,
            isActive: isActive,
            verified: isVerified,
            suspended: user.suspended === true,
            customRoleId: user.custom_role_id,
            userTags: user.tags || [],
            userDetails: user.details || {}
        });
    });
    
    return processedData;
}

// Determinar acceso a productos
function getProductAccess(user, accountSettings, customRoleName = null) {
    const products = [];
    
    // Si es un rol personalizado, manejar casos específicos
    if (customRoleName) {
        // Para roles personalizados, determinar acceso basado en el nombre del rol
        if (customRoleName.toLowerCase().includes('agent') || customRoleName.toLowerCase().includes('agente')) {
            products.push('Support', 'Guide', 'Explore');
        } else if (customRoleName.toLowerCase().includes('admin')) {
            products.push('Support', 'Guide', 'Explore');
        } else {
            // Por defecto para roles personalizados
            products.push('Support');
        }
    } else {
        // Acceso básico basado en rol estándar
        if (user.role === 'admin') {
            products.push('Support', 'Guide', 'Explore');
            
            // Admins pueden tener acceso a productos adicionales
            if (accountSettings.chat && accountSettings.chat.enabled) {
                products.push('Chat');
            }
            if (accountSettings.talk && accountSettings.talk.enabled) {
                products.push('Talk');
            }
            if (accountSettings.sell && accountSettings.sell.enabled) {
                products.push('Sell');
            }
        } else if (user.role === 'agent') {
            // Todos los agentes tienen acceso a Support
            products.push('Support');
            
            // Verificar acceso específico basado en configuración del usuario
            if (user.details && user.details.guide_access) {
                products.push('Guide');
            }
            if (user.details && user.details.explore_access) {
                products.push('Explore');
            }
            
            // Si no hay configuración específica, dar acceso por defecto
            if (!user.details || (!user.details.guide_access && !user.details.explore_access)) {
                products.push('Guide', 'Explore');
            }
            
            // Acceso a productos adicionales para agentes
            if (accountSettings.chat && accountSettings.chat.enabled) {
                products.push('Chat');
            }
        } else if (user.role === 'end-user') {
            products.push('Guide');
        } else {
            // Para roles no reconocidos
            products.push('Support');
        }
    }
    
    // Eliminar duplicados y ordenar
    const uniqueProducts = [...new Set(products)].sort();
    return uniqueProducts.length > 0 ? uniqueProducts.join(', ') : 'Sin acceso';
}

// Formatear último inicio de sesión
function formatLastLogin(lastLoginAt) {
    if (!lastLoginAt) {
        return 'Nunca';
    }
    
    try {
        const loginDate = new Date(lastLoginAt);
        
        // Validar que la fecha es válida
        if (isNaN(loginDate.getTime())) {
            return 'Fecha inválida';
        }
        
        // Formatear como fecha simple: dd/mm/yyyy
        const day = loginDate.getDate().toString().padStart(2, '0');
        const month = (loginDate.getMonth() + 1).toString().padStart(2, '0');
        const year = loginDate.getFullYear();
        
        return `${day}/${month}/${year}`;
        
    } catch (error) {
        console.warn('Error formateando fecha de último login:', error);
        return 'Fecha inválida';
    }
}

// Renderizar el resumen de licencias
function renderLicensesOverview(users, licensing, customRoles) {
    const overviewContainer = document.getElementById('licensesOverview');
    
    try {
        // Calcular estadísticas de usuarios
        const userStats = calculateUserStatistics(users, customRoles);
        
        // Determinar licencias disponibles basado en datos reales o estimados
        const licenseInfo = calculateLicenseInformation(userStats, licensing);
        
        let html = '';
        
        // Renderizar cada tipo de licencia
        licenseInfo.forEach(license => {
            const usagePercentage = (license.used / license.total) * 100;
            const progressClass = usagePercentage > 90 ? 'danger' : usagePercentage > 75 ? 'warning' : '';
            
            html += `
                <div class="license-item">
                    <div class="license-badge ${license.type}">
                        <span>${license.name}</span>
                        <div class="license-usage">
                            <span class="available">${license.used}</span> de <span class="total">${license.total}</span>
                        </div>
                    </div>
                    <div class="license-progress">
                        <div class="license-progress-bar ${progressClass}" style="width: ${usagePercentage}%"></div>
                    </div>
                </div>
            `;
        });
        
        overviewContainer.innerHTML = html;
        
    } catch (error) {
        console.error('Error al renderizar resumen de licencias:', error);
        overviewContainer.innerHTML = `
            <div class="license-item">
                <div class="text-warning">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    No se pudo cargar la información de licencias
                </div>
            </div>
        `;
    }
}

// Calcular estadísticas de usuarios
function calculateUserStatistics(users, customRoles) {
    const stats = {
        total: users.length,
        admins: 0,
        agents: 0,
        lightAgents: 0,
        endUsers: 0,
        customRoles: {}
    };
    
    // Crear mapa de roles personalizados
    const customRolesMap = {};
    customRoles.forEach(role => {
        customRolesMap[role.id] = role;
        stats.customRoles[role.name] = 0;
    });
    
    users.forEach(user => {
        if (user.role === 'admin') {
            stats.admins++;
        } else if (user.role === 'agent') {
            stats.agents++;
        } else if (user.role === 'end-user') {
            stats.endUsers++;
        }
        
        // Verificar roles personalizados
        if (user.custom_role_id && customRolesMap[user.custom_role_id]) {
            const customRole = customRolesMap[user.custom_role_id];
            if (customRole.name.toLowerCase().includes('light')) {
                stats.lightAgents++;
            } else {
                stats.customRoles[customRole.name]++;
            }
        }
    });
    
    return stats;
}

// Calcular información de licencias
function calculateLicenseInformation(userStats, licensing) {
    const licenses = [];
    
    // Si tenemos datos reales de licensing, usarlos
    if (licensing && !licensing.fallback) {
        // Procesar datos reales de licensing si están disponibles
        if (licensing.suite) {
            licenses.push({
                name: 'Zendesk Suite',
                type: 'suite',
                used: licensing.suite.used || userStats.admins + userStats.agents,
                total: licensing.suite.total || 1000
            });
        }
        
        if (licensing.light) {
            licenses.push({
                name: 'Agentes Light',
                type: 'light',
                used: licensing.light.used || userStats.lightAgents,
                total: licensing.light.total || 5000
            });
        }
    } else {
        // Usar estimaciones basadas en los datos de usuarios
        // Zendesk Suite (admins + agentes regulares)
        const suiteUsers = userStats.admins + userStats.agents;
        licenses.push({
            name: 'Zendesk Suite',
            type: 'suite',
            used: suiteUsers,
            total: Math.max(suiteUsers + 50, 100) // Estimación conservadora
        });
        
        // Agentes Light
        if (userStats.lightAgents > 0) {
            licenses.push({
                name: 'Agentes Light',
                type: 'light',
                used: userStats.lightAgents,
                total: Math.max(userStats.lightAgents + 200, 500) // Estimación conservadora
            });
        }
        
        // Roles personalizados que podrían ser licencias
        Object.keys(userStats.customRoles).forEach(roleName => {
            const count = userStats.customRoles[roleName];
            if (count > 0 && roleName.toLowerCase().includes('agent')) {
                licenses.push({
                    name: roleName,
                    type: 'professional',
                    used: count,
                    total: Math.max(count + 20, 50)
                });
            }
        });
    }
    
    // Si no hay licencias específicas, mostrar al menos una entrada general
    if (licenses.length === 0) {
        licenses.push({
            name: 'Usuarios Activos',
            type: 'suite',
            used: userStats.admins + userStats.agents + userStats.lightAgents,
            total: userStats.total + 50
        });
    }
    
    return licenses;
}

// Función para aplicar filtro a los datos de licencias
function applyLicensesFilter() {
    const filterValue = document.getElementById('licensesFilter').value.toLowerCase().trim();
    
    if (filterValue === '') {
        licensesFilteredData = [...processedLicensesData];
    } else {
        licensesFilteredData = processedLicensesData.filter(row => {
            const supportRole = getRoleDisplayName(row.userRole, row.customRoleName).toLowerCase();
            const lastLogin = row.lastLogin.toLowerCase();
            
            return supportRole.includes(filterValue) || lastLogin.includes(filterValue);
        });
    }
}

// Renderizar tabla de licencias
function renderLicensesTable() {
    const tbody = document.getElementById('licensesTableBody');
    
    // Si no hay datos, mostrar estado vacío
    if (processedLicensesData.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="5" class="text-center py-5 text-muted">
                    <div class="empty-state">
                        <div class="display-1">
                            <i class="fas fa-inbox text-primary"></i>
                        </div>
                        <h3 class="text-primary">No hay datos disponibles</h3>
                        <p>No se encontraron usuarios en el sistema.</p>
                        <button class="btn btn-outline-primary" onclick="loadLicensesData(true)">
                            <i class="fas fa-sync-alt me-2"></i>
                            Intentar de nuevo
                        </button>
                    </div>
                </td>
            </tr>
        `;
        
        // Limpiar controles de paginación
        document.getElementById('licensesPagination').innerHTML = '';
        updatePageInfo('licensesPageInfo', 0, 0, 0);
        updateLicensesFilterCounters(0, 0);
        return;
    }

    // Aplicar filtro actual
    applyLicensesFilter();
    
    // Calcular paginación
    const totalPages = Math.ceil(licensesFilteredData.length / licensesPageSize);
    const startIndex = (licensesCurrentPage - 1) * licensesPageSize;
    const endIndex = startIndex + licensesPageSize;
    const pageData = licensesFilteredData.slice(startIndex, endIndex);

    // Si no hay datos en la página actual, ir a la primera página
    if (pageData.length === 0 && licensesFilteredData.length > 0) {
        licensesCurrentPage = 1;
        renderLicensesTable();
        return;
    }
    
    // Si no hay datos filtrados, mostrar mensaje de sin resultados
    if (licensesFilteredData.length === 0) {
        const filterValue = document.getElementById('licensesFilter').value.trim();
        tbody.innerHTML = `
            <tr>
                <td colspan="5" class="text-center py-4">
                    <i class="fas fa-filter fa-2x text-muted mb-2"></i>
                    <div class="text-muted">
                        <strong>No se encontraron resultados</strong>
                    </div>
                    <small class="text-muted">
                        No hay usuarios con rol o fecha que coincida con "${escapeHtml(filterValue)}"
                    </small>
                </td>
            </tr>
        `;
        
        // Limpiar controles de paginación
        document.getElementById('licensesPagination').innerHTML = '';
        updatePageInfo('licensesPageInfo', 0, 0, 0);
        updateLicensesFilterCounters(0, processedLicensesData.length);
        return;
    }

    let html = '';
    
    pageData.forEach((row, index) => {
        const statusClass = row.isActive ? '' : 'opacity-50';
        const verifiedIcon = row.verified ? '<i class="fas fa-check-circle text-success ms-1" title="Verificado"></i>' : '<i class="fas fa-exclamation-triangle text-warning ms-1" title="No verificado"></i>';
        
        html += `
            <tr class="${statusClass}">
                <td>
                    <div class="user-info">
                        <div class="user-name">
                            <i class="fas fa-user me-2 text-primary"></i>
                            ${escapeHtml(row.userName)}
                            ${verifiedIcon}
                        </div>
                        <div class="user-email">
                            <i class="fas fa-envelope me-1 text-secondary"></i>
                            ${escapeHtml(row.userEmail)}
                        </div>
                        ${!row.isActive ? '<small class="text-warning"><i class="fas fa-pause me-1"></i>Inactivo</small>' : ''}
                    </div>
                </td>
                <td>
                    <div class="groups-info">
                        <i class="fas fa-layer-group me-2 text-secondary"></i>
                        ${escapeHtml(row.groups)}
                    </div>
                </td>
                <td>
                    <div class="products-info">
                        <i class="fas fa-box me-2 text-info"></i>
                        ${escapeHtml(row.productAccess)}
                    </div>
                </td>
                <td>
                    <span class="role-badge role-${row.userRole}">
                        <i class="fas ${getRoleIcon(row.userRole)} me-1"></i>
                        ${getRoleDisplayName(row.userRole, row.customRoleName)}
                    </span>
                </td>
                <td>
                    <div class="login-info">
                        <i class="fas fa-clock me-2 text-muted"></i>
                        ${escapeHtml(row.lastLogin)}
                    </div>
                </td>
            </tr>
        `;
    });
    
    tbody.innerHTML = html;
    
    // Actualizar controles de paginación
    createPaginationControls('licensesPagination', licensesCurrentPage, totalPages, 'goToLicensesPage');
    updatePageInfo('licensesPageInfo', licensesCurrentPage, licensesPageSize, licensesFilteredData.length);
    
    // Actualizar contadores del filtro
    updateLicensesFilterCounters(licensesFilteredData.length, processedLicensesData.length);
}

// Mostrar estado de carga para licencias
function showLicensesLoadingState() {
    const tbody = document.getElementById('licensesTableBody');
    tbody.innerHTML = `
        <tr>
            <td colspan="5" class="text-center py-5 text-muted">
                <div class="spinner-border" role="status">
                    <span class="visually-hidden">Cargando...</span>
                </div>
                <div class="mt-2">Cargando datos de licencias...</div>
            </td>
        </tr>
    `;
    
    document.getElementById('licensesRecordsCount').textContent = 'Total de registros: Cargando...';
}

// Mostrar estado de error para licencias
function showLicensesErrorState(message) {
    const tbody = document.getElementById('licensesTableBody');
    tbody.innerHTML = `
        <tr>
            <td colspan="5" class="text-center py-5 text-muted">
                <div class="error-row">
                    <div class="display-1 text-danger">⚠️</div>
                    <h3 class="text-danger">Error al cargar datos</h3>
                    <p>${escapeHtml(message)}</p>
                    <button class="btn btn-outline-primary" onclick="loadLicensesData(true)">
                        Reintentar
                    </button>
                </div>
            </td>
        </tr>
    `;
    
    updateLicensesLoadingStatus('Error al cargar datos');
    document.getElementById('licensesRecordsCount').textContent = 'Total de registros: Error';
}

// Actualizar estado de carga para licencias
function updateLicensesLoadingStatus(status) {
    document.getElementById('licensesLoadingStatus').innerHTML = `<small>${status}</small>`;
}

// Actualizar información de estado para licencias
function updateLicensesStatus(recordCount, loadTime) {
    const now = new Date();
    const timeString = now.toLocaleTimeString();
    
    document.getElementById('licensesLastUpdate').textContent = timeString;
    document.getElementById('licensesLoadTime').textContent = `${loadTime}ms`;
    document.getElementById('licensesRecordsCount').textContent = `Total de registros: ${recordCount}`;
    
    updateLicensesLoadingStatus('Datos cargados exitosamente');
}

// Filtrar licencias (nueva versión con paginación)
function filterLicenses() {
    licensesCurrentPage = 1; // Resetear a la primera página cuando se filtra
    renderLicensesTable();
}

// Limpiar filtro de licencias
function clearLicensesFilter() {
    document.getElementById('licensesFilter').value = '';
    filterLicenses();
    document.getElementById('licensesFilter').focus();
}

// Actualizar contadores del filtro de licencias
function updateLicensesFilterCounters(visible, total) {
    document.getElementById('licensesVisibleRows').textContent = visible;
    document.getElementById('licensesTotalRows').textContent = total;
    
    // Cambiar color del badge según el filtro
    const badge = document.getElementById('licensesFilteredCount');
    if (visible < total) {
        badge.className = 'badge bg-warning';
    } else {
        badge.className = 'badge bg-secondary';
    }
}

// Mostrar mensaje de sin resultados para licencias (ahora se integra en renderLicensesTable)
function showLicensesNoResultsMessage(visibleCount, filterValue) {
    // Esta función ahora se maneja directamente en renderLicensesTable
    // Se mantiene por compatibilidad pero no se usa
}

// Exportar licencias a Excel
function exportLicensesToExcel() {
    try {
        if (!processedLicensesData || processedLicensesData.length === 0) {
            showModal('errorModal', 'No hay datos para exportar. Por favor, carga los datos primero.');
            return;
        }
        
        // Usar los datos ya filtrados por el sistema de paginación
        applyLicensesFilter(); // Asegurar que el filtro está aplicado
        const dataToExport = licensesFilteredData;
        
        if (dataToExport.length === 0) {
            showModal('errorModal', 'No hay datos para exportar con el filtro actual.');
            return;
        }
        
        // Procesar datos para Excel
        const filteredData = dataToExport.map((row, index) => ({
            '#': index + 1,
            'Integrante del equipo': row.userName,
            'Email': row.userEmail,
            'Grupo': row.groups,
            'Acceso a productos': row.productAccess,
            'Support rol': getRoleDisplayName(row.userRole, row.customRoleName),
            'Fecha último inicio': row.lastLogin,
            'Estado': row.isActive ? 'Activo' : 'Inactivo',
            'Verificado': row.verified ? 'Sí' : 'No'
        }));
        
        // Crear libro de Excel
        const wb = XLSX.utils.book_new();
        const ws = XLSX.utils.json_to_sheet(filteredData);
        
        // Ajustar ancho de columnas
        const colWidths = [
            { wch: 8 },  // #
            { wch: 25 }, // Integrante del equipo
            { wch: 30 }, // Email
            { wch: 20 }, // Grupo
            { wch: 25 }, // Acceso a productos
            { wch: 15 }, // Support rol
            { wch: 18 }, // Fecha último inicio
            { wch: 10 }, // Estado
            { wch: 12 }  // Verificado
        ];
        ws['!cols'] = colWidths;
        
        XLSX.utils.book_append_sheet(wb, ws, 'Licencias');
        
        // Generar nombre de archivo con fecha y hora
        const now = new Date();
        const dateString = now.toISOString().split('T')[0];
        const timeString = now.toTimeString().split(' ')[0].replace(/:/g, '-');
        
        // Determinar si hay filtro activo
        const filterValue = document.getElementById('licensesFilter').value.trim();
        const isFiltered = filterValue !== '';
        const suffix = isFiltered ? '_filtrado' : '';
        
        const fileName = `licencias_usuarios_${dateString}_${timeString}${suffix}.xlsx`;
        
        // Descargar archivo
        XLSX.writeFile(wb, fileName);
        
        // Calcular estadísticas de los datos filtrados
        const totalVisible = filteredData.length;
        const totalRecords = processedLicensesData.length;
        const activeUsers = filteredData.filter(row => row.Estado === 'Activo').length;
        const adminUsers = filteredData.filter(row => row['Support rol'].toLowerCase().includes('admin')).length;
        const agentUsers = filteredData.filter(row => row['Support rol'].toLowerCase().includes('agent')).length;
        
        showModal('successModal', 
            `Archivo Excel "${fileName}" exportado exitosamente.\n\n` +
            `📊 Estadísticas ${isFiltered ? '(datos filtrados)' : '(todos los datos)'}:\n` +
            `• ${totalVisible} usuarios exportados${isFiltered ? ` de ${totalRecords} totales` : ''}\n` +
            `• ${activeUsers} usuarios activos\n` +
            `• ${adminUsers} administradores\n` +
            `• ${agentUsers} agentes\n` +
            `${isFiltered ? `• Filtro aplicado: "${filterValue}"\n` : ''}` +
            `\n✅ Datos exportados correctamente`
        );
        
    } catch (error) {
        console.error('Error exporting licenses to Excel:', error);
        showModal('errorModal', 'Error al exportar a Excel: ' + error.message);
    }
}

// Inicializar cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', init);

// También inicializar cuando el cliente ZAF esté listo
client.on('app.registered', init); 
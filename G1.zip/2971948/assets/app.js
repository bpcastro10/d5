// Inicializar cliente de Zendesk
const client = ZAFClient.init();

// Variables globales
let groupsData = [];
let usersData = [];
let groupMembersData = [];

// Inicializar la aplicación
async function init() {
    console.log('Iniciando Dashboard de Grupos...');
    
    // Event listeners
    setupEventListeners();
    
    // Cargar datos inicialmente
    await loadGroupsAndMembers();
}

// Configurar event listeners
function setupEventListeners() {
    document.getElementById('refreshDataBtn').addEventListener('click', async () => {
        await loadGroupsAndMembers(true);
    });
    
    document.getElementById('exportExcelBtn').addEventListener('click', exportToExcel);
}

// Cargar grupos y miembros
async function loadGroupsAndMembers(forceRefresh = false) {
    try {
        showLoadingState();
        updateLoadingStatus('Cargando datos...');
        
        const startTime = Date.now();
        
        // Obtener grupos y usuarios en paralelo
        const [groups, users] = await Promise.all([
            getGroups(),
            getUsers()
        ]);
        
        groupsData = groups;
        usersData = users;
        
        // Procesar datos para crear la estructura de la tabla
        groupMembersData = processGroupsAndMembers(groups, users);
        
        const loadTime = Date.now() - startTime;
        
        // Renderizar tabla
        renderGroupsTable();
        
        // Actualizar información de estado
        updateStatus(groupMembersData.length, loadTime);
        
        console.log('Datos cargados exitosamente:', {
            grupos: groups.length,
            usuarios: users.length,
            registros: groupMembersData.length,
            tiempoCarga: loadTime + 'ms'
        });
        
    } catch (error) {
        console.error('Error al cargar datos:', error);
        showErrorState(error.message);
    }
}

// Obtener todos los grupos
async function getGroups() {
    try {
        console.log('Obteniendo grupos...');
        const response = await client.request('/api/v2/groups.json');
        return response.groups || [];
    } catch (error) {
        console.error('Error al obtener grupos:', error);
        throw new Error('No se pudieron cargar los grupos');
    }
}

// Obtener todos los usuarios (admin y agent)
async function getUsers() {
    try {
        console.log('Obteniendo usuarios...');
        const response = await client.request('/api/v2/users.json?role[]=admin&role[]=agent');
        return response.users || [];
    } catch (error) {
        console.error('Error al obtener usuarios:', error);
        throw new Error('No se pudieron cargar los usuarios');
    }
}

// Procesar grupos y miembros para crear la estructura de datos de la tabla
function processGroupsAndMembers(groups, users) {
    const processedData = [];
    
    groups.forEach((group, index) => {
        // Filtrar usuarios que pertenecen a este grupo
        const groupMembers = users.filter(user => 
            user.default_group_id === group.id
        );
        
        if (groupMembers.length > 0) {
            groupMembers.forEach((member, memberIndex) => {
                processedData.push({
                    rowNumber: processedData.length + 1,
                    groupId: group.id,
                    groupName: group.name,
                    groupDescription: group.description,
                    memberId: member.id,
                    memberName: member.name,
                    memberEmail: member.email,
                    memberRole: member.role,
                    isFirstMemberOfGroup: memberIndex === 0,
                    groupMemberCount: groupMembers.length
                });
            });
        } else {
            // Grupo sin miembros
            processedData.push({
                rowNumber: processedData.length + 1,
                groupId: group.id,
                groupName: group.name,
                groupDescription: group.description,
                memberId: null,
                memberName: 'Sin miembros',
                memberEmail: '',
                memberRole: '',
                isFirstMemberOfGroup: true,
                groupMemberCount: 0
            });
        }
    });
    
    return processedData;
}

// Renderizar tabla de grupos
function renderGroupsTable() {
    const tbody = document.getElementById('groupsTableBody');
    
    if (groupMembersData.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="4" class="text-center py-5 text-muted">
                    <div class="empty-state">
                        <div class="display-1">📋</div>
                        <h3>No hay datos disponibles</h3>
                        <p>No se encontraron grupos con miembros.</p>
                    </div>
                </td>
            </tr>
        `;
        return;
    }
    
    let html = '';
    let currentGroupId = null;
    
    groupMembersData.forEach((row, index) => {
        const isNewGroup = row.groupId !== currentGroupId;
        currentGroupId = row.groupId;
        
        html += `
            <tr>
                <td class="group-number">${row.rowNumber}</td>
                <td>
                    ${isNewGroup ? `
                        <div class="group-name">${escapeHtml(row.groupName)}</div>
                        ${row.groupDescription ? `<small class="text-muted">${escapeHtml(row.groupDescription)}</small>` : ''}
                    ` : ''}
                </td>
                <td>
                    <div class="member-item">
                        <div>
                            <div class="member-name">${escapeHtml(row.memberName)}</div>
                            ${row.memberEmail ? `<div class="member-email">${escapeHtml(row.memberEmail)}</div>` : ''}
                        </div>
                    </div>
                </td>
                <td>
                    ${row.memberRole ? `
                        <span class="role-badge role-${row.memberRole}">
                            ${getRoleDisplayName(row.memberRole)}
                        </span>
                    ` : ''}
                </td>
            </tr>
        `;
    });
    
    tbody.innerHTML = html;
}

// Obtener nombre de visualización del rol
function getRoleDisplayName(role) {
    const roleNames = {
        'admin': 'Admin',
        'agent': 'Agente',
        'end-user': 'Usuario Final'
    };
    return roleNames[role] || role;
}

// Escapar HTML
function escapeHtml(text) {
    if (!text) return '';
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.toString().replace(/[&<>"']/g, m => map[m]);
}

// Exportar a Excel
function exportToExcel() {
    try {
        if (groupMembersData.length === 0) {
            showModal('errorModal', 'No hay datos para exportar');
            return;
        }
        
        // Preparar datos para Excel
        const excelData = groupMembersData.map(row => ({
            '#': row.rowNumber,
            'Grupo': row.groupName,
            'Descripción del Grupo': row.groupDescription || '',
            'Integrante': row.memberName,
            'Email': row.memberEmail || '',
            'Rol': getRoleDisplayName(row.memberRole)
        }));
        
        // Crear libro de trabajo
        const wb = XLSX.utils.book_new();
        const ws = XLSX.utils.json_to_sheet(excelData);
        
        // Ajustar ancho de columnas
        const colWidths = [
            { wch: 5 },   // #
            { wch: 25 },  // Grupo
            { wch: 30 },  // Descripción
            { wch: 25 },  // Integrante
            { wch: 30 },  // Email
            { wch: 15 }   // Rol
        ];
        ws['!cols'] = colWidths;
        
        // Agregar hoja al libro
        XLSX.utils.book_append_sheet(wb, ws, "Grupos y Miembros");
        
        // Generar nombre de archivo con fecha
        const fecha = new Date().toISOString().split('T')[0];
        const nombreArchivo = `grupos_y_miembros_${fecha}.xlsx`;
        
        // Descargar archivo
        XLSX.writeFile(wb, nombreArchivo);
        
        showModal('successModal', `Archivo ${nombreArchivo} exportado exitosamente con ${excelData.length} registros.`);
        
        console.log('Exportación exitosa:', {
            archivo: nombreArchivo,
            registros: excelData.length
        });
        
    } catch (error) {
        console.error('Error al exportar:', error);
        showModal('errorModal', 'Error al exportar los datos: ' + error.message);
    }
}

// Mostrar modal
function showModal(modalId, message) {
    const modal = document.getElementById(modalId);
    const messageElement = modal.querySelector(modalId === 'errorModal' ? '#errorMessage' : '#successMessage');
    
    messageElement.textContent = message;
    
    // Usar Bootstrap modal si está disponible, sino mostrar alerta
    if (typeof bootstrap !== 'undefined') {
        new bootstrap.Modal(modal).show();
    } else {
        alert(message);
    }
}

// Mostrar estado de carga
function showLoadingState() {
    const tbody = document.getElementById('groupsTableBody');
    tbody.innerHTML = `
        <tr>
            <td colspan="4" class="text-center py-5 text-muted">
                <div class="spinner-border" role="status">
                    <span class="visually-hidden">Cargando...</span>
                </div>
                <div class="mt-2">Cargando datos de grupos...</div>
            </td>
        </tr>
    `;
    
    document.getElementById('recordsCount').textContent = 'Total de registros: Cargando...';
}

// Mostrar estado de error
function showErrorState(message) {
    const tbody = document.getElementById('groupsTableBody');
    tbody.innerHTML = `
        <tr>
            <td colspan="4" class="text-center py-5 text-muted">
                <div class="error-row">
                    <div class="display-1 text-danger">⚠️</div>
                    <h3 class="text-danger">Error al cargar datos</h3>
                    <p>${escapeHtml(message)}</p>
                    <button class="btn btn-outline-primary" onclick="loadGroupsAndMembers(true)">
                        Reintentar
                    </button>
                </div>
            </td>
        </tr>
    `;
    
    updateLoadingStatus('Error al cargar datos');
    document.getElementById('recordsCount').textContent = 'Total de registros: Error';
}

// Actualizar estado de carga
function updateLoadingStatus(status) {
    document.getElementById('loadingStatus').innerHTML = `<small>${status}</small>`;
}

// Actualizar información de estado
function updateStatus(recordCount, loadTime) {
    const now = new Date();
    const timeString = now.toLocaleTimeString();
    
    document.getElementById('lastUpdate').textContent = timeString;
    document.getElementById('loadTime').textContent = `${loadTime}ms`;
    document.getElementById('recordsCount').textContent = `Total de registros: ${recordCount}`;
    
    updateLoadingStatus('Datos cargados exitosamente');
}

// Inicializar cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', init);

// También inicializar cuando el cliente ZAF esté listo
client.on('app.registered', init); 
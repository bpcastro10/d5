const client = ZAFClient.init();
let ticketsPlot = null;
let dailyPlotDetailed = null;
let monthlyPlotDetailed = null;
let comparisonPlot1 = null;
let comparisonPlot2 = null;
let hourlyComparisonPlot = null;
let monthlyComparisonPlot = null;
let ticketsEvolutionPlot = null;
let updateIntervalId = null;

let ticketsCache = {
    data: [],
    lastFetch: null,
    cacheExpiry: 5 * 60 * 1000, // 5 minutos
    // Índices pre-calculados para búsquedas rápidas
    indices: {
        byDate: new Map(),      // Mapa fecha -> tickets
        byStatus: new Map(),    // Mapa status -> tickets
        byMonth: new Map(),     // Mapa mes -> tickets
        byYear: new Map(),      // Mapa año -> tickets
        byHour: new Map(),      // Mapa hora -> tickets
        byDay: new Map()        // Mapa día -> tickets
    },
    stats: {
        totalTickets: 0,
        dateRange: { min: null, max: null },
        statusDistribution: {},
        averagePerDay: 0,
        averagePerMonth: 0,
        lastCalculated: null
    }
};

// Flag para evitar múltiples llamadas simultáneas
let isFetchingTickets = false;

function setDefaultDates() {
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - 30);
    const dateInputs = ['startDate', 'endDate', 'startDate1', 'endDate1', 'startDate2', 'endDate2', 'startDateDetailed', 'endDateDetailed', 'startDateHourlyComp', 'endDateHourlyComp', 'startDateMonthlyComp', 'endDateMonthlyComp', 'startDateIndicators', 'endDateIndicators'];
    dateInputs.forEach(id => {
        const input = document.getElementById(id);
        if (input) {
            const dateValue = id.includes('start') ? startDate : endDate;
            input.value = dateValue.toISOString().split('T')[0];
        }
    });
}



function togglePeriodicUpdates() {
    const syncToggleButton = document.getElementById('syncToggle');
    if (updateIntervalId) {
        clearInterval(updateIntervalId);
        updateIntervalId = null;
        syncToggleButton.textContent = 'Iniciar Sincronización';
        console.log('Sincronización automática detenida.');
    } else {
        startPeriodicUpdates();
        syncToggleButton.textContent = 'Parar Sincronización';
        console.log('Sincronización automática iniciada.');
    }
}

function changePage(pageId) {
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
    });
    document.querySelector(`[data-page="${pageId}"]`).classList.add('active');

    document.getElementById('dashboard-page').classList.toggle('d-none', pageId !== 'dashboard');
    document.getElementById('detailed-page').classList.toggle('d-none', pageId !== 'detailed');
    document.getElementById('comparison-page').classList.toggle('d-none', pageId !== 'comparison');
    document.getElementById('indicators-page').classList.toggle('d-none', pageId !== 'indicators');

    if (pageId === 'comparison') {
        initComparisonPlots();
    } else if (pageId === 'detailed') {
        initDetailedPlots();
        updateDetailedAnalysis();
    } else if (pageId === 'indicators') {
        initIndicatorsPage();
        updateIndicators();
    }
}

// Crear versiones con debounce de las funciones de actualización
const debouncedUpdateTicketsData = debounce(updateTicketsData, 500);
const debouncedUpdateDashboard = debounce(updateDashboard, 500);
const debouncedUpdateDetailedAnalysis = debounce(updateDetailedAnalysis, 500);

async function init() {
    try {
        console.log('Iniciando aplicación...');
        setDefaultDates();


        // Event listeners para navegación
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                changePage(e.target.dataset.page);
            });
        });


        document.getElementById('syncToggle').addEventListener('click', togglePeriodicUpdates);
        
        document.getElementById('applyFilter').addEventListener('click', async () => {
            const startDate = document.getElementById('startDate').value;
            const endDate = document.getElementById('endDate').value;
            
            if (!startDate || !endDate || new Date(startDate) > new Date(endDate)) {
                document.getElementById('date-filter-alert').classList.remove('d-none');
                return;
            }
            
            document.getElementById('date-filter-alert').classList.add('d-none');
            await Promise.all([debouncedUpdateDashboard(), debouncedUpdateTicketsData()]);
        });

        document.getElementById('applyFilterDetailed').addEventListener('click', async () => {
            const startDate = document.getElementById('startDateDetailed').value;
            const endDate = document.getElementById('endDateDetailed').value;
            
            if (!startDate || !endDate || new Date(startDate) > new Date(endDate)) {
                document.getElementById('date-filter-alert-detailed').classList.remove('d-none');
                return;
            }
            
            document.getElementById('date-filter-alert-detailed').classList.add('d-none');
            await debouncedUpdateDetailedAnalysis();
        });

        // Event listeners para los botones de filtro de comparación (existentes y nuevos)
        document.querySelectorAll('.apply-filter').forEach(button => {
            button.addEventListener('click', async (e) => {
                const chartNum = e.target.dataset.chart;
                const type = e.target.dataset.type || 'daily'; // Por defecto es diario
                const startDate = document.getElementById(`startDate${chartNum}`).value;
                const endDate = document.getElementById(`endDate${chartNum}`).value;
                
                if (!startDate || !endDate || new Date(startDate) > new Date(endDate)) {
                    return;
                }
                
                const currentSyncState = getComparisonSyncKey() !== null;
                const scale = document.getElementById(`scale${chartNum}`)?.value || 'daily';
                if (chartNum === '1') {
                    await updateComparisonChart(1, startDate, endDate, scale);
                } else if (chartNum === '2') {
                    await updateComparisonChart(2, startDate, endDate, scale);
                }
                const newSyncState = getComparisonSyncKey() !== null;
                if (currentSyncState !== newSyncState) {
                    console.log('Estado de sincronización cambió, reinicializando gráficos...');
                    initComparisonPlots();
                }
            });
        });
        document.querySelectorAll('#scale1, #scale2').forEach(select => {
            select.addEventListener('change', async (e) => {
                console.log('Escala de comparación cambiada, actualizando gráficos...');
                
                const chartNum = e.target.id === 'scale1' ? 1 : 2;
                const scale = e.target.value;
                const startDate = document.getElementById(`startDate${chartNum}`).value;
                const endDate = document.getElementById(`endDate${chartNum}`).value;
                
                if (startDate && endDate) {
                    await updateComparisonChart(chartNum, startDate, endDate, scale);
                }
                const newSyncState = getComparisonSyncKey() !== null;
                console.log('Nuevo estado de sincronización:', newSyncState);
                initComparisonPlots();
            });
        });

        document.querySelectorAll('.apply-filter-comp').forEach(button => {
            button.addEventListener('click', async (e) => {
                const chartType = e.target.dataset.chartType;
                const startDate = document.getElementById(`startDate${chartType}Comp`).value;
                const endDate = document.getElementById(`endDate${chartType}Comp`).value;

                if (!startDate || !endDate || new Date(startDate) > new Date(endDate)) {
                    return;
                }

                let plotInstance;
                let label;
                if (chartType === 'hourly') {
                    plotInstance = hourlyComparisonPlot;
                    label = 'Tickets por hora';
                } else if (chartType === 'monthly') {
                    plotInstance = monthlyComparisonPlot;
                    label = 'Tickets por mes';
                }

                if (plotInstance) {
                    await updateComparisonChartData(plotInstance, startDate, endDate, chartType, label);
                }
            });
        });

        // Event listener para filtros de indicadores
        document.getElementById('applyFilterIndicators').addEventListener('click', async () => {
            const startDate = document.getElementById('startDateIndicators').value;
            const endDate = document.getElementById('endDateIndicators').value;
            
            if (!startDate || !endDate || new Date(startDate) > new Date(endDate)) {
                document.getElementById('date-filter-alert-indicators').classList.remove('d-none');
                return;
            }
            
            document.getElementById('date-filter-alert-indicators').classList.add('d-none');
            await updateIndicators();
        });

        console.log('Inicializando gráficos...');
        initTicketsPlot();
        console.log('Actualizando dashboard y datos iniciales...');
        await Promise.all([
            updateDashboard(),
            updateTicketsData()
        ]);
        
        console.log('Iniciando actualizaciones periódicas...');
        startPeriodicUpdates();
        document.getElementById('syncToggle').textContent = 'Parar Sincronización';
        console.log('Aplicación inicializada correctamente');
    } catch (error) {
        console.error('Error al inicializar la aplicación:', error);
    }
}

document.addEventListener('DOMContentLoaded', init);
function initTicketsPlot() {
    console.log('Iniciando inicialización de gráficos...');
    
    const container = document.getElementById('realtimeTrend');
    
    console.log('Contenedores encontrados (Dashboard):', {
        realtime: !!container
    });

    if (!container) {
        console.error('No se encontró el contenedor del gráfico principal');
        return;
    }

    const baseOpts = {
        width: container.offsetWidth,
        height: 300,
        cursor: {
            show: true,
            sync: {
                key: "ticketSync"
            }
        },
        scales: {
            x: {
                time: true,
            },
            y: {
                auto: true,
            }
        },
        axes: [
            {
                stroke: "#03363d",
                grid: { show: true, stroke: "#d8dcde" },
                ticks: { show: true, stroke: "#03363d" },
                font: "12px Arial",
                values: (self, splits) => splits.map(s => {
                    const date = new Date(s * 1000);
                    const scale = document.getElementById('scaleDashboard').value; // Obtener la escala seleccionada para el dashboard
                    switch(scale) {
                        case 'hourly':
                            return new Intl.DateTimeFormat('es-EC', {
                                hour: 'numeric',
                                minute: 'numeric',
                                timeZone: 'America/Guayaquil'
                            }).format(date);
                        case 'daily':
                            return new Intl.DateTimeFormat('es-EC', {
                                month: 'short',
                                day: 'numeric',
                                timeZone: 'America/Guayaquil'
                            }).format(date);
                        case 'monthly':
                            return new Intl.DateTimeFormat('es-EC', {
                                month: 'long',
                                year: 'numeric',
                                timeZone: 'America/Guayaquil'
                            }).format(date);
                        case 'yearly':
                            return new Intl.DateTimeFormat('es-EC', {
                                year: 'numeric',
                                timeZone: 'America/Guayaquil'
                            }).format(date);
                    }
                }),
            },
            {
                stroke: "#03363d",
                grid: { show: true, stroke: "#d8dcde" },
                ticks: { show: true, stroke: "#03363d" },
                font: "12px Arial",
            }
        ]
    };

    try {
        console.log('Creando gráfico de tiempo real...');
        const opts = {
            ...baseOpts,
            title: "Tickets por Hora",
            series: [
                {},
                {
                    stroke: "#03363d",
                    width: 2,
                    fill: "rgba(3, 54, 61, 0.1)",
                    label: "Tickets reales",
                },
                {
                    label: "Límite superior",
                    stroke: "gold",
                    width: 2,
                    dash: [1, 5],
                }
            ]
        };
        ticketsPlot = new uPlot(opts, [[], []], container);
        console.log('Gráfico de tiempo real creado');
        const emptyData = [[], []];
        ticketsPlot.setData(emptyData);

    } catch (error) {
        console.error('Error al crear los gráficos del dashboard:', error);
    }
}

function getComparisonSyncKey() {
    const scale1 = document.getElementById('scale1')?.value || 'daily';
    const scale2 = document.getElementById('scale2')?.value || 'daily';
    
    if (scale1 === scale2) {
        return "comparisonSync";
    } else {
        return null;
    }
}

function initComparisonPlots() {
    console.log('Iniciando inicialización de gráficos de comparación...');

    const container1 = document.getElementById('chart1');
    const container2 = document.getElementById('chart2');

    if (comparisonPlot1) {
        comparisonPlot1.destroy();
        comparisonPlot1 = null;
    }
    if (comparisonPlot2) {
        comparisonPlot2.destroy();
        comparisonPlot2 = null;
    }

    console.log('Contenedores encontrados (Comparación):', {
        chart1: !!container1,
        chart2: !!container2
    });

    if (!container1 || !container2) {
        console.error('No se encontraron todos los contenedores necesarios para gráficos de comparación.');
        return;
    }

    const getBarColor = (value, maxValue) => {
        if (!Number.isFinite(maxValue) || maxValue <= 0) {
            maxValue = 1;
        }
        const percentage = value / maxValue;
        if (percentage < 0.33) return "#2196F3";
        if (percentage < 0.66) return "#4CAF50";
        return "#F44336";
    };

    const syncKey = getComparisonSyncKey();
    const shouldSync = syncKey !== null;
    console.log('Sincronización de gráficos:', shouldSync ? 'Habilitada' : 'Deshabilitada');

    const createAxisFormatter = (chartNum) => {
        return (self, splits) => splits.map(s => {
            const date = new Date(s * 1000);
            const scale = document.getElementById(`scale${chartNum}`).value;
            switch(scale) {
                case 'hourly':
                    return new Intl.DateTimeFormat('es-EC', {
                        hour: 'numeric',
                        minute: 'numeric',
                        timeZone: 'America/Guayaquil'
                    }).format(date);
                case 'daily':
                    return new Intl.DateTimeFormat('es-EC', {
                        month: 'short',
                        day: 'numeric',
                        timeZone: 'America/Guayaquil'
                    }).format(date);
                case 'monthly':
                    return new Intl.DateTimeFormat('es-EC', {
                        month: 'long',
                        year: 'numeric',
                        timeZone: 'America/Guayaquil'
                    }).format(date);
                case 'yearly':
                    return new Intl.DateTimeFormat('es-EC', {
                        year: 'numeric',
                        timeZone: 'America/Guayaquil'
                    }).format(date);
            }
        });
    };

    const createBaseOpts = (chartNum) => ({
        width: container1.offsetWidth,
        height: 300,
        cursor: shouldSync ? {
            show: true,
            sync: {
                key: syncKey
            }
        } : {
            show: true
        },
        scales: {
            x: {
                time: true,
            },
            y: {
                auto: true,
            }
        },
        axes: [
            {
                stroke: "#03363d",
                grid: { show: true, stroke: "#d8dcde" },
                ticks: { show: true, stroke: "#03363d" },
                font: "12px Arial",
                values: createAxisFormatter(chartNum),
            },
            {
                stroke: "#03363d",
                grid: { show: true, stroke: "#d8dcde" },
                ticks: { show: true, stroke: "#03363d" },
                font: "12px Arial",
            }
        ],
        series: [
            {},
            {
                stroke: (u, seriesIdx, dataIdx) => {
                    const seriesData = (u && u.data && Array.isArray(u.data[seriesIdx])) ? u.data[seriesIdx] : [];
                    if (dataIdx < 0 || dataIdx >= seriesData.length) {
                        return "#CCCCCC";
                    }
                    const value = seriesData[dataIdx];
                    const maxValue = seriesData.length > 0 ? Math.max(...seriesData) : 1;
                    return getBarColor(value, maxValue);
                },
                width: 2,
                fill: (u, seriesIdx, dataIdx) => {
                    const seriesData = (u && u.data && Array.isArray(u.data[seriesIdx])) ? u.data[seriesIdx] : [];
                    if (dataIdx < 0 || dataIdx >= seriesData.length) {
                        return "#CCCCCC80";
                    }
                    const value = seriesData[dataIdx];
                    const maxValue = seriesData.length > 0 ? Math.max(...seriesData) : 1;
                    return getBarColor(value, maxValue) + "80";
                },
                points: { show: false },
            }
        ]
    });

    try {
        console.log('Creando gráfico de comparación 1...');
        const opts1 = createBaseOpts(1);
        comparisonPlot1 = new uPlot({
            ...opts1,
            title: "Gráfico 1",
            series: [{
                },
                {
                    ...opts1.series[1],
                    label: "Tickets",
                    paths: uPlot.paths.bars(),
                }]
        }, [[], []], container1);
        console.log('Gráfico de comparación 1 creado:', comparisonPlot1);

        console.log('Creando gráfico de comparación 2...');
        const opts2 = createBaseOpts(2);
        comparisonPlot2 = new uPlot({
            ...opts2,
            title: "Gráfico 2",
            series: [{
                },
                {
                    ...opts2.series[1],
                    label: "Tickets",
                    paths: uPlot.paths.bars(),
                }]
        }, [[], []], container2);
        console.log('Gráfico de comparación 2 creado:', comparisonPlot2);

        window.addEventListener('resize', () => {
            if (comparisonPlot1 && container1) {
                comparisonPlot1.setSize({ width: container1.offsetWidth, height: 300 });
            }
            if (comparisonPlot2 && container2) {
                comparisonPlot2.setSize({ width: container2.offsetWidth, height: 300 });
            }
        });

    } catch (error) {
        console.error('Error al crear los gráficos de comparación:', error);
    }

    const startDate1 = document.getElementById('startDate1').value;
    const endDate1 = document.getElementById('endDate1').value;
    const startDate2 = document.getElementById('startDate2').value;
    const endDate2 = document.getElementById('endDate2').value;
    const scale1 = document.getElementById('scale1')?.value || 'daily';
    const scale2 = document.getElementById('scale2')?.value || 'daily';

    console.log('Inicializando gráficos con fechas:', {
        chart1: { startDate1, endDate1, scale1 },
        chart2: { startDate2, endDate2, scale2 }
    });

    setTimeout(() => {
        if (startDate1 && endDate1) {
            updateComparisonChart(1, startDate1, endDate1, scale1);
        } else {
            console.log('Gráfico 1: Fechas no disponibles, usando datos vacíos');
        }
        
        if (startDate2 && endDate2) {
            updateComparisonChart(2, startDate2, endDate2, scale2);
        } else {
            console.log('Gráfico 2: Fechas no disponibles, usando datos vacíos');
        }
    }, 100);
}

async function updateComparisonChart(chartNum, startDate, endDate, scale) {
    try {
        console.log(`Actualizando gráfico de comparación ${chartNum} con escala ${scale}...`);
        
        if (!startDate || !endDate) {
            console.warn(`Fechas no válidas para gráfico ${chartNum}`);
            return;
        }

        const tickets = await getTickets();
        
        const filteredTickets = tickets.filter(ticket => {
            const ticketDate = new Date(ticket.created_at);
            const start = new Date(startDate);
            const end = new Date(endDate + 'T23:59:59');
            return ticketDate >= start && ticketDate <= end;
        });

        console.log(`Tickets filtrados para gráfico ${chartNum}:`, filteredTickets.length);

        const aggregatedData = aggregateDataByScale(filteredTickets, scale, startDate, endDate);
        const timestamps = Object.keys(aggregatedData).sort().map(key => {
            const date = parseKeyToDate(key, scale);
            return date.getTime() / 1000;
        });
        
        const values = Object.keys(aggregatedData).sort().map(key => aggregatedData[key]);

        console.log(`Datos para gráfico ${chartNum}:`, { 
            timestamps: timestamps.length, 
            values: values.length,
            totalTickets: values.reduce((a, b) => a + b, 0),
            dataRange: values.length > 0 ? `${Math.min(...values)} - ${Math.max(...values)}` : 'Sin datos'
        });

        if (timestamps.length === 0 || values.length === 0) {
            console.warn(`Gráfico ${chartNum}: No hay datos para mostrar en el rango de fechas seleccionado`);
            timestamps.push(Date.now() / 1000);
            values.push(0);
        }

        if (chartNum === 1 && comparisonPlot1) {
            console.log('Actualizando comparisonPlot1...');
            try {
                comparisonPlot1.setData([timestamps, values]);
                window.chart1Data = values; // Guardar para análisis
                console.log('comparisonPlot1 actualizado exitosamente');
            } catch (error) {
                console.error('Error al actualizar comparisonPlot1:', error);
            }
        } else if (chartNum === 2 && comparisonPlot2) {
            console.log('Actualizando comparisonPlot2...');
            try {
                comparisonPlot2.setData([timestamps, values]);
                window.chart2Data = values; // Guardar para análisis
                console.log('comparisonPlot2 actualizado exitosamente');
            } catch (error) {
                console.error('Error al actualizar comparisonPlot2:', error);
            }
        } else {
            console.error(`Gráfico ${chartNum} no está inicializado o número inválido`);
            console.log('Estado de gráficos:', { comparisonPlot1: !!comparisonPlot1, comparisonPlot2: !!comparisonPlot2 });
            return;
        }

        if (window.chart1Data && window.chart2Data && window.chart1Data.length > 0 && window.chart2Data.length > 0) {
            console.log('Actualizando análisis de diferencias...');
            const analysis = analyzeDifferences(window.chart1Data, window.chart2Data);
            updateComparisonAnalysis(analysis);
        }

        console.log(`Gráfico ${chartNum} actualizado exitosamente`);
        
    } catch (error) {
        console.error(`Error al actualizar gráfico de comparación ${chartNum}:`, error);
    }
}

function aggregateDataByScale(tickets, scale, startDate, endDate) {
    const aggregatedData = {};
    const startDateObj = new Date(startDate);
    const endDateObj = new Date(endDate + 'T23:59:59');
    const keys = generateDateKeys(startDateObj, endDateObj, scale);
    keys.forEach(key => {
        aggregatedData[key] = 0;
    });
    
    tickets.forEach(ticket => {
        const date = new Date(ticket.created_at);
        let key;
        
        switch(scale) {
            case 'hourly':
                key = date.toISOString().slice(0, 13);
                break;
            case 'daily':
                key = date.toISOString().split('T')[0];
                break;
            case 'monthly':
                key = date.toISOString().slice(0, 7);
                break;
            case 'yearly':
                key = date.getFullYear().toString();
                break;
            default:
                key = date.toISOString().split('T')[0];
        }
        
        if (aggregatedData.hasOwnProperty(key)) {
            aggregatedData[key]++;
        }
    });
    
    return aggregatedData;
}

// Actualizar gráfico de comparación (generalizado)
async function updateComparisonChartData(plotInstance, startDate, endDate, type, label) {
    try {
        console.log(`Actualizando gráfico de comparación (${type})...`);
        const tickets = await getTickets();
        const filteredTickets = tickets.filter(ticket => {
            const ticketDate = new Date(ticket.created_at);
            return ticketDate >= new Date(startDate) && ticketDate <= new Date(endDate + 'T23:59:59');
        });

        let data = {};
        let timestamps = [];
        let values = [];
        let start = new Date(startDate);
        let end = new Date(endDate + 'T23:59:59');

        if (type === 'daily') {
            filteredTickets.forEach(ticket => {
                const date = new Date(ticket.created_at);
                const dayKey = date.toISOString().split('T')[0];
                data[dayKey] = (data[dayKey] || 0) + 1;
            });

            for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
                const dayKey = d.toISOString().split('T')[0];
                timestamps.push(d.getTime() / 1000);
                values.push(data[dayKey] || 0);
            }
        } else if (type === 'hourly') {
            filteredTickets.forEach(ticket => {
                const date = new Date(ticket.created_at);
                const hourKey = date.toISOString().slice(0, 13);
                data[hourKey] = (data[hourKey] || 0) + 1;
            });
            for (let d = new Date(start); d <= end; d.setHours(d.getHours() + 1)) {
                const hourKey = d.toISOString().slice(0, 13);
                timestamps.push(d.getTime() / 1000);
                values.push(data[hourKey] || 0);
            }
        } else if (type === 'monthly') {
            filteredTickets.forEach(ticket => {
                const date = new Date(ticket.created_at);
                const monthKey = date.toISOString().slice(0, 7);
                data[monthKey] = (data[monthKey] || 0) + 1;
            });
            let currentMonth = new Date(start.getFullYear(), start.getMonth(), 1);
            while (currentMonth <= end) {
                const monthKey = currentMonth.toISOString().slice(0, 7);
                timestamps.push(currentMonth.getTime() / 1000);
                values.push(data[monthKey] || 0);
                currentMonth.setMonth(currentMonth.getMonth() + 1);
            }
        }

        if (plotInstance) {
            plotInstance.setData([timestamps, values]);
            // Actualizar la etiqueta de la serie si es necesario (para los gráficos de línea)
            if (type === 'hourly') {
                plotInstance.series[1].label = label;
            }
        } else {
            console.error(`La instancia del gráfico para ${type} no está inicializada.`);
        }

    } catch (error) {
        console.error(`Error al actualizar gráfico de comparación (${type}):`, error);
    }
}

// Función para analizar las diferencias entre dos conjuntos de datos (mejorada)
function analyzeDifferences(data1, data2) {
    if (data1.length === 0 || data2.length === 0) {
        return {
            error: 'Uno o ambos conjuntos de datos están vacíos',
            differences: {},
            analysis: {},
            interpretation: ['No se puede realizar el análisis con datos vacíos.']
        };
    }

    // Estadísticas básicas
    const stats1 = calculateAdvancedStats(data1);
    const stats2 = calculateAdvancedStats(data2);

    // Diferencias absolutas y relativas
    const differences = {
        dataset1: stats1,
        dataset2: stats2,
        totalDifference: stats1.total - stats2.total,
        averageDifference: stats1.mean - stats2.mean,
        medianDifference: stats1.median - stats2.median,
        maxDifference: stats1.max - stats2.max,
        minDifference: stats1.min - stats2.min,
        varianceDifference: stats1.variance - stats2.variance,
        stdDevDifference: stats1.stdDev - stats2.stdDev
    };

    // Análisis avanzado
    const analysis = {
        // Cambios porcentuales
        totalPercentageChange: stats2.total !== 0 ? 
            ((stats1.total - stats2.total) / stats2.total * 100) : 0,
        averagePercentageChange: stats2.mean !== 0 ? 
            ((stats1.mean - stats2.mean) / stats2.mean * 100) : 0,
        
        // Análisis de volatilidad
        volatilityChange: {
            dataset1: calculateVolatility(data1),
            dataset2: calculateVolatility(data2),
            difference: calculateVolatility(data1) - calculateVolatility(data2)
        },
        
        // Correlación entre datasets (si tienen la misma longitud)
        correlation: data1.length === data2.length ? calculateCorrelation(data1, data2) : null,
        
        // Análisis de tendencias individuales
        trend1: calculateTrendAnalysis(data1),
        trend2: calculateTrendAnalysis(data2),
        
        // Análisis de distribución
        distribution: compareDistributions(data1, data2),
        
        // Prueba estadística de diferencia significativa
        significanceTest: performSignificanceTest(data1, data2),
        
        // Análisis de estacionalidad/patrones
        patterns: comparePatterns(data1, data2),
        
        // Métricas de consistencia
        consistency: {
            dataset1: calculateConsistency(data1),
            dataset2: calculateConsistency(data2)
        }
    };

    return {
        differences,
        analysis,
        interpretation: generateAdvancedInterpretation(differences, analysis),
        recommendations: generateComparisonRecommendations(differences, analysis)
    };
}

// Calcular estadísticas avanzadas para un dataset
function calculateAdvancedStats(data) {
    const sorted = [...data].sort((a, b) => a - b);
    const n = data.length;
    const total = data.reduce((a, b) => a + b, 0);
    const mean = total / n;
    
    return {
        total,
        mean,
        median: n % 2 === 0 ? 
            (sorted[n/2 - 1] + sorted[n/2]) / 2 : 
            sorted[Math.floor(n/2)],
        mode: calculateMode(data),
        min: Math.min(...data),
        max: Math.max(...data),
        range: Math.max(...data) - Math.min(...data),
        variance: data.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / n,
        stdDev: Math.sqrt(data.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / n),
        q1: sorted[Math.floor(n * 0.25)],
        q3: sorted[Math.floor(n * 0.75)],
        skewness: calculateSkewness(data, mean),
        kurtosis: calculateKurtosis(data, mean)
    };
}

// Calcular la moda (valor más frecuente)
function calculateMode(data) {
    const frequency = {};
    let maxFreq = 0;
    let mode = null;
    
    data.forEach(val => {
        frequency[val] = (frequency[val] || 0) + 1;
        if (frequency[val] > maxFreq) {
            maxFreq = frequency[val];
            mode = val;
        }
    });
    
    return mode;
}

// Calcular asimetría (skewness)
function calculateSkewness(data, mean) {
    const n = data.length;
    const variance = data.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / n;
    const stdDev = Math.sqrt(variance);
    
    if (stdDev === 0) return 0;
    
    const skewness = data.reduce((sum, val) => sum + Math.pow((val - mean) / stdDev, 3), 0) / n;
    return skewness;
}

// Calcular curtosis
function calculateKurtosis(data, mean) {
    const n = data.length;
    const variance = data.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / n;
    const stdDev = Math.sqrt(variance);
    
    if (stdDev === 0) return 0;
    
    const kurtosis = data.reduce((sum, val) => sum + Math.pow((val - mean) / stdDev, 4), 0) / n - 3;
    return kurtosis;
}

// Calcular correlación de Pearson
function calculateCorrelation(data1, data2) {
    const n = data1.length;
    if (n !== data2.length || n === 0) return null;
    
    const mean1 = data1.reduce((a, b) => a + b, 0) / n;
    const mean2 = data2.reduce((a, b) => a + b, 0) / n;
    
    let num = 0, den1 = 0, den2 = 0;
    
    for (let i = 0; i < n; i++) {
        const diff1 = data1[i] - mean1;
        const diff2 = data2[i] - mean2;
        num += diff1 * diff2;
        den1 += diff1 * diff1;
        den2 += diff2 * diff2;
    }
    
    const denominator = Math.sqrt(den1 * den2);
    return denominator === 0 ? 0 : num / denominator;
}

// Análisis de tendencias para un dataset
function calculateTrendAnalysis(data) {
    if (data.length < 2) return { trend: 'insufficient_data' };
    
    const trend = calculateLinearTrend(data);
    const movingAvg = calculateMovingAverage(data, Math.min(7, Math.floor(data.length / 3)));
    
    return {
        slope: trend.slope,
        correlation: trend.correlation,
        direction: trend.slope > 0.1 ? 'increasing' : trend.slope < -0.1 ? 'decreasing' : 'stable',
        strength: Math.abs(trend.correlation),
        movingAverage: movingAvg,
        changePoints: detectChangePoints(data)
    };
}

// Detectar puntos de cambio en una serie temporal
function detectChangePoints(data) {
    if (data.length < 6) return [];
    
    const changePoints = [];
    const windowSize = Math.max(3, Math.floor(data.length / 10));
    
    for (let i = windowSize; i < data.length - windowSize; i++) {
        const before = data.slice(i - windowSize, i);
        const after = data.slice(i, i + windowSize);
        
        const meanBefore = before.reduce((a, b) => a + b, 0) / before.length;
        const meanAfter = after.reduce((a, b) => a + b, 0) / after.length;
        
        const percentChange = Math.abs((meanAfter - meanBefore) / meanBefore * 100);
        
        if (percentChange > 30) { // Cambio significativo del 30%
            changePoints.push({
                index: i,
                beforeMean: meanBefore,
                afterMean: meanAfter,
                percentChange: percentChange,
                type: meanAfter > meanBefore ? 'increase' : 'decrease'
            });
        }
    }
    
    return changePoints;
}

// Comparar distribuciones
function compareDistributions(data1, data2) {
    const stats1 = calculateAdvancedStats(data1);
    const stats2 = calculateAdvancedStats(data2);
    
    return {
        centralTendency: {
            meanDifference: stats1.mean - stats2.mean,
            medianDifference: stats1.median - stats2.median,
            interpretation: Math.abs(stats1.mean - stats1.median) < Math.abs(stats2.mean - stats2.median) ? 
                'Dataset 1 más simétrico' : 'Dataset 2 más simétrico'
        },
        spread: {
            rangeDifference: stats1.range - stats2.range,
            varianceDifference: stats1.variance - stats2.variance,
            interpretation: stats1.variance < stats2.variance ? 
                'Dataset 1 más consistente' : 'Dataset 2 más consistente'
        },
        shape: {
            skewnessDifference: stats1.skewness - stats2.skewness,
            kurtosisDifference: stats1.kurtosis - stats2.kurtosis,
            interpretation: generateDistributionShapeInterpretation(stats1, stats2)
        }
    };
}

// Interpretar la forma de la distribución
function generateDistributionShapeInterpretation(stats1, stats2) {
    const interpretations = [];
    
    // Análisis de asimetría
    if (Math.abs(stats1.skewness) < 0.5 && Math.abs(stats2.skewness) > 1) {
        interpretations.push('Dataset 1 tiene distribución más simétrica');
    } else if (Math.abs(stats2.skewness) < 0.5 && Math.abs(stats1.skewness) > 1) {
        interpretations.push('Dataset 2 tiene distribución más simétrica');
    }
    
    // Análisis de curtosis
    if (stats1.kurtosis > 0 && stats2.kurtosis < 0) {
        interpretations.push('Dataset 1 tiene más valores extremos (leptocúrtica)');
    } else if (stats2.kurtosis > 0 && stats1.kurtosis < 0) {
        interpretations.push('Dataset 2 tiene más valores extremos (leptocúrtica)');
    }
    
    return interpretations.length > 0 ? interpretations.join('. ') : 'Distribuciones similares';
}

// Prueba de significancia estadística (t-test simplificado)
function performSignificanceTest(data1, data2) {
    const stats1 = calculateAdvancedStats(data1);
    const stats2 = calculateAdvancedStats(data2);
    const n1 = data1.length;
    const n2 = data2.length;
    
    // Calcular error estándar de la diferencia
    const se = Math.sqrt((stats1.variance / n1) + (stats2.variance / n2));
    
    if (se === 0) {
        return { significant: false, tStat: 0, interpretation: 'No hay variabilidad para evaluar' };
    }
    
    // Estadístico t
    const tStat = (stats1.mean - stats2.mean) / se;
    
    // Interpretación simplificada (sin tabla de t)
    const significant = Math.abs(tStat) > 2; // Aproximadamente p < 0.05
    
    return {
        significant,
        tStat,
        confidenceLevel: significant ? 'alta' : 'baja',
        interpretation: significant ? 
            'La diferencia es estadísticamente significativa' : 
            'La diferencia no es estadísticamente significativa'
    };
}

// Comparar patrones entre datasets
function comparePatterns(data1, data2) {
    return {
        volatility1: calculateVolatility(data1),
        volatility2: calculateVolatility(data2),
        peaks1: findPeaks(data1),
        peaks2: findPeaks(data2),
        cycles1: detectCycles(data1),
        cycles2: detectCycles(data2),
        interpretation: generatePatternInterpretation(data1, data2)
    };
}

// Encontrar picos en una serie
function findPeaks(data) {
    const peaks = [];
    for (let i = 1; i < data.length - 1; i++) {
        if (data[i] > data[i-1] && data[i] > data[i+1]) {
            peaks.push({ index: i, value: data[i] });
        }
    }
    return peaks;
}

// Generar interpretación de patrones
function generatePatternInterpretation(data1, data2) {
    const vol1 = calculateVolatility(data1);
    const vol2 = calculateVolatility(data2);
    const peaks1 = findPeaks(data1);
    const peaks2 = findPeaks(data2);
    
    const interpretations = [];
    
    if (vol1 > vol2 * 1.2) {
        interpretations.push('Dataset 1 muestra mayor volatilidad');
    } else if (vol2 > vol1 * 1.2) {
        interpretations.push('Dataset 2 muestra mayor volatilidad');
    } else {
        interpretations.push('Ambos datasets tienen volatilidad similar');
    }
    
    if (peaks1.length > peaks2.length * 1.5) {
        interpretations.push('Dataset 1 tiene más picos de actividad');
    } else if (peaks2.length > peaks1.length * 1.5) {
        interpretations.push('Dataset 2 tiene más picos de actividad');
    }
    
    return interpretations.join('. ');
}

// Calcular consistencia de un dataset
function calculateConsistency(data) {
    const mean = data.reduce((a, b) => a + b, 0) / data.length;
    const coefficientOfVariation = mean !== 0 ? 
        (Math.sqrt(data.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / data.length) / mean) : 0;
    
    return {
        coefficientOfVariation,
        interpretation: coefficientOfVariation < 0.3 ? 'alta' : 
                       coefficientOfVariation < 0.6 ? 'media' : 'baja'
    };
}

// Generar interpretación avanzada de las diferencias
function generateAdvancedInterpretation(differences, analysis) {
    const interpretations = [];
    
    // Análisis de cambio total
    if (Math.abs(analysis.totalPercentageChange) > 10) {
        const direction = analysis.totalPercentageChange > 0 ? 'incremento' : 'reducción';
        interpretations.push(`Se observa un ${direction} significativo del ${Math.abs(analysis.totalPercentageChange).toFixed(1)}% en el volumen total de tickets.`);
    } else {
        interpretations.push('El volumen total de tickets se mantiene relativamente estable entre períodos.');
    }
    
    // Análisis de volatilidad
    const volDiff = analysis.volatilityChange.difference;
    if (Math.abs(volDiff) > 0.1) {
        const period = volDiff > 0 ? 'primer' : 'segundo';
        interpretations.push(`El ${period} período muestra mayor volatilidad (${Math.abs(volDiff * 100).toFixed(1)}% más variable).`);
    }
    
    // Análisis de correlación
    if (analysis.correlation !== null) {
        if (Math.abs(analysis.correlation) > 0.7) {
            interpretations.push(`Existe una correlación ${analysis.correlation > 0 ? 'positiva' : 'negativa'} fuerte (${(analysis.correlation * 100).toFixed(1)}%) entre ambos períodos.`);
        } else if (Math.abs(analysis.correlation) > 0.3) {
            interpretations.push(`Se detecta una correlación moderada entre ambos períodos.`);
        } else {
            interpretations.push('Los patrones entre períodos muestran poca correlación.');
        }
    }
    
    // Análisis de tendencias
    const trend1 = analysis.trend1;
    const trend2 = analysis.trend2;
    if (trend1.direction !== trend2.direction) {
        interpretations.push(`Los períodos muestran tendencias opuestas: Período 1 ${trend1.direction === 'increasing' ? 'creciente' : trend1.direction === 'decreasing' ? 'decreciente' : 'estable'}, Período 2 ${trend2.direction === 'increasing' ? 'creciente' : trend2.direction === 'decreasing' ? 'decreciente' : 'estable'}.`);
    }
    
    // Análisis de significancia estadística
    if (analysis.significanceTest.significant) {
        interpretations.push(`La diferencia entre períodos es estadísticamente significativa (t = ${analysis.significanceTest.tStat.toFixed(2)}).`);
    } else {
        interpretations.push('Las diferencias observadas no son estadísticamente significativas y podrían deberse a variación natural.');
    }
    
    // Análisis de distribución
    const distrib = analysis.distribution;
    interpretations.push(distrib.centralTendency.interpretation);
    interpretations.push(distrib.spread.interpretation);
    
    // Análisis de patrones
    interpretations.push(analysis.patterns.interpretation);
    
    return interpretations;
}

// Generar recomendaciones basadas en la comparación
function generateComparisonRecommendations(differences, analysis) {
    const recommendations = [];
    
    // Recomendaciones basadas en cambio de volumen
    if (analysis.totalPercentageChange > 20) {
        recommendations.push('💡 Incremento significativo detectado: Considere aumentar la capacidad del equipo de soporte y revisar los procesos de escalamiento.');
    } else if (analysis.totalPercentageChange < -20) {
        recommendations.push('📉 Reducción significativa: Evalúe si es resultado de mejoras en el proceso o si indica problemas subyacentes.');
    }
    
    // Recomendaciones basadas en volatilidad
    if (analysis.volatilityChange.difference > 0.2) {
        recommendations.push('⚡ Alta volatilidad en el primer período: Implemente estrategias de gestión de carga variable y sistemas de alerta temprana.');
    } else if (analysis.volatilityChange.difference < -0.2) {
        recommendations.push('📊 Mayor estabilidad en el primer período: Identifique y replique las mejores prácticas implementadas.');
    }
    
    // Recomendaciones basadas en correlación
    if (analysis.correlation !== null && Math.abs(analysis.correlation) < 0.3) {
        recommendations.push('🔄 Baja correlación entre períodos: Investigue cambios operacionales o externos que puedan explicar patrones diferentes.');
    }
    
    // Recomendaciones basadas en tendencias
    const trend1 = analysis.trend1;
    const trend2 = analysis.trend2;
    if (trend1.direction === 'increasing' && trend2.direction === 'increasing') {
        recommendations.push('📈 Tendencia creciente sostenida: Planifique expansión de recursos y optimización de procesos a largo plazo.');
    } else if (trend1.direction === 'decreasing' && trend2.direction === 'increasing') {
        recommendations.push('🔄 Cambio de tendencia: Analice qué factores causaron la reversión para mantener la mejora.');
    }
    
    // Recomendaciones basadas en consistencia
    const consist1 = analysis.consistency.dataset1;
    const consist2 = analysis.consistency.dataset2;
    if (consist1.interpretation === 'baja' && consist2.interpretation === 'alta') {
        recommendations.push('🎯 Mejora en consistencia: Documente y estandarice las prácticas que llevaron a mayor estabilidad.');
    } else if (consist1.interpretation === 'alta' && consist2.interpretation === 'baja') {
        recommendations.push('⚠️ Pérdida de consistencia: Revise cambios en procesos o personal que puedan estar afectando la estabilidad.');
    }
    
    // Recomendaciones basadas en picos
    const peaks1 = analysis.patterns.peaks1.length;
    const peaks2 = analysis.patterns.peaks2.length;
    if (peaks2 > peaks1 * 1.5) {
        recommendations.push('🏔️ Aumento en picos de actividad: Desarrolle protocolos específicos para gestión de cargas máximas.');
    }
    
    if (recommendations.length === 0) {
        recommendations.push('✅ Los períodos muestran patrones similares. Continúe monitoreando para detectar cambios tempranos.');
    }
    
    return recommendations;
}

// Función para actualizar el análisis de diferencias en la interfaz (mejorada)
function updateComparisonAnalysis(analysis) {
    const analysisContainer = document.getElementById('comparison-analysis');
    if (!analysisContainer) {
        console.error('No se encontró el contenedor de análisis de comparación');
        return;
    }

    // Verificar si hay error en el análisis
    if (analysis.error) {
        analysisContainer.innerHTML = `
            <div class="alert alert-warning mt-4">
                <h5>⚠️ Análisis no disponible</h5>
                <p>${analysis.error}</p>
            </div>
        `;
        return;
    }

    // Crear contenido HTML detallado
    let analysisHTML = `
        <div class="card mt-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">📊 Análisis Comparativo Avanzado</h5>
                <small class="text-muted">Sincronización: ${getComparisonSyncKey() ? 'Activa' : 'Independiente'}</small>
            </div>
            <div class="card-body">
    `;

    // Sección de estadísticas básicas
    if (analysis.differences && analysis.differences.dataset1 && analysis.differences.dataset2) {
        const stats1 = analysis.differences.dataset1;
        const stats2 = analysis.differences.dataset2;
        
        analysisHTML += `
            <div class="row mb-4">
                <div class="col-md-6">
                    <div class="card border-primary">
                        <div class="card-header bg-primary text-white">
                            <h6 class="mb-0">📈 Período 1</h6>
                        </div>
                        <div class="card-body">
                            <div class="row text-center">
                                <div class="col-6"><strong>Total:</strong><br>${stats1.total}</div>
                                <div class="col-6"><strong>Promedio:</strong><br>${stats1.mean.toFixed(1)}</div>
                                <div class="col-6"><strong>Mediana:</strong><br>${stats1.median.toFixed(1)}</div>
                                <div class="col-6"><strong>Rango:</strong><br>${stats1.min}-${stats1.max}</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card border-success">
                        <div class="card-header bg-success text-white">
                            <h6 class="mb-0">📉 Período 2</h6>
                        </div>
                        <div class="card-body">
                            <div class="row text-center">
                                <div class="col-6"><strong>Total:</strong><br>${stats2.total}</div>
                                <div class="col-6"><strong>Promedio:</strong><br>${stats2.mean.toFixed(1)}</div>
                                <div class="col-6"><strong>Mediana:</strong><br>${stats2.median.toFixed(1)}</div>
                                <div class="col-6"><strong>Rango:</strong><br>${stats2.min}-${stats2.max}</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    // Sección de interpretaciones principales
    if (analysis.interpretation && analysis.interpretation.length > 0) {
        analysisHTML += `
            <div class="mb-4">
                <h6 class="text-primary">🔍 Interpretación</h6>
                <ul class="list-group list-group-flush">
                    ${analysis.interpretation.map(interpretation => 
                        `<li class="list-group-item border-0 px-0">${interpretation}</li>`
                    ).join('')}
                </ul>
            </div>
        `;
    }

    // Sección de análisis avanzado
    if (analysis.analysis) {
        const adv = analysis.analysis;
        
        // Correlación
        if (adv.correlation !== null) {
            const corrStrength = Math.abs(adv.correlation) > 0.7 ? 'Fuerte' : 
                                Math.abs(adv.correlation) > 0.4 ? 'Moderada' : 'Débil';
            const corrDirection = adv.correlation > 0 ? 'Positiva' : 'Negativa';
            
            analysisHTML += `
                <div class="row mb-3">
                    <div class="col-md-4">
                        <div class="card border-info">
                            <div class="card-body text-center">
                                <h6 class="card-title">🔗 Correlación</h6>
                                <h4 class="text-info">${(adv.correlation * 100).toFixed(1)}%</h4>
                                <small>${corrDirection} - ${corrStrength}</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card border-warning">
                            <div class="card-body text-center">
                                <h6 class="card-title">📊 Cambio Total</h6>
                                <h4 class="text-warning">${adv.totalPercentageChange > 0 ? '+' : ''}${adv.totalPercentageChange.toFixed(1)}%</h4>
                                <small>${Math.abs(adv.totalPercentageChange) > 10 ? 'Significativo' : 'Moderado'}</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card border-secondary">
                            <div class="card-body text-center">
                                <h6 class="card-title">⚡ Volatilidad</h6>
                                <h4 class="text-secondary">${(Math.abs(adv.volatilityChange.difference) * 100).toFixed(1)}%</h4>
                                <small>Diferencia de variabilidad</small>
                            </div>
                        </div>
                    </div>
                </div>
            `;
        }

        // Análisis de tendencias
        if (adv.trend1 && adv.trend2) {
            const getTrendIcon = (direction) => {
                switch(direction) {
                    case 'increasing': return '📈';
                    case 'decreasing': return '📉';
                    default: return '➡️';
                }
            };

            analysisHTML += `
                <div class="mb-3">
                    <h6 class="text-primary">📈 Análisis de Tendencias</h6>
                    <div class="row">
                        <div class="col-md-6">
                            <small><strong>Período 1:</strong> ${getTrendIcon(adv.trend1.direction)} ${adv.trend1.direction === 'increasing' ? 'Creciente' : adv.trend1.direction === 'decreasing' ? 'Decreciente' : 'Estable'} (${(adv.trend1.strength * 100).toFixed(1)}% confianza)</small>
                        </div>
                        <div class="col-md-6">
                            <small><strong>Período 2:</strong> ${getTrendIcon(adv.trend2.direction)} ${adv.trend2.direction === 'increasing' ? 'Creciente' : adv.trend2.direction === 'decreasing' ? 'Decreciente' : 'Estable'} (${(adv.trend2.strength * 100).toFixed(1)}% confianza)</small>
                        </div>
                    </div>
                </div>
            `;
        }

        // Prueba de significancia estadística
        if (adv.significanceTest) {
            const test = adv.significanceTest;
            analysisHTML += `
                <div class="mb-3">
                    <h6 class="text-primary">🧮 Significancia Estadística</h6>
                    <div class="alert ${test.significant ? 'alert-success' : 'alert-secondary'} py-2">
                        <small>
                            <strong>T-estadístico:</strong> ${test.tStat.toFixed(3)} | 
                            <strong>Confianza:</strong> ${test.confidenceLevel} | 
                            <strong>Resultado:</strong> ${test.interpretation}
                        </small>
                    </div>
                </div>
            `;
        }

        // Análisis de consistencia
        if (adv.consistency) {
            const consist1 = adv.consistency.dataset1;
            const consist2 = adv.consistency.dataset2;
            
            analysisHTML += `
                <div class="mb-3">
                    <h6 class="text-primary">🎯 Consistencia</h6>
                    <div class="row">
                        <div class="col-md-6">
                            <small><strong>Período 1:</strong> ${consist1.interpretation} (CV: ${(consist1.coefficientOfVariation * 100).toFixed(1)}%)</small>
                        </div>
                        <div class="col-md-6">
                            <small><strong>Período 2:</strong> ${consist2.interpretation} (CV: ${(consist2.coefficientOfVariation * 100).toFixed(1)}%)</small>
                        </div>
                    </div>
                </div>
            `;
        }
    }

    // Sección de recomendaciones
    if (analysis.recommendations && analysis.recommendations.length > 0) {
        analysisHTML += `
            <div class="mb-3">
                <h6 class="text-success">💡 Recomendaciones</h6>
                <div class="list-group list-group-flush">
                    ${analysis.recommendations.map(rec => 
                        `<div class="list-group-item border-0 px-0 py-2">
                            <small>${rec}</small>
                        </div>`
                    ).join('')}
                </div>
            </div>
        `;
    }

    analysisHTML += `
            </div>
        </div>
    `;

    analysisContainer.innerHTML = analysisHTML;
}

// Funciones para mostrar/ocultar indicador de carga
function showLoadingIndicator() {
    const indicator = document.getElementById('loading-indicator');
    if (indicator) {
        indicator.classList.remove('d-none');
        indicator.style.display = 'flex';
    }
}

function hideLoadingIndicator() {
    const indicator = document.getElementById('loading-indicator');
    if (indicator) {
        indicator.classList.add('d-none');
        indicator.style.display = 'none';
    }
}

// Obtener tickets de Zendesk con paginación y cacheo
async function getTickets(forceRefresh = false) {
    try {
        // Verificar cache si no es un refresh forzado
        if (!forceRefresh && ticketsCache.data.length > 0 && ticketsCache.lastFetch) {
            const cacheAge = Date.now() - ticketsCache.lastFetch;
            if (cacheAge < ticketsCache.cacheExpiry) {
                console.log('Usando tickets del cache:', ticketsCache.data.length);
                return ticketsCache.data;
            }
        }

        // Evitar múltiples llamadas simultáneas
        if (isFetchingTickets) {
            console.log('Ya se están obteniendo tickets, esperando...');
            return ticketsCache.data; // Retornar cache mientras se actualiza
        }

        isFetchingTickets = true;
        
        // Mostrar indicador de carga solo en la primera carga o refresh forzado
        if (ticketsCache.data.length === 0 || forceRefresh) {
            showLoadingIndicator();
        }
        
        console.log('Obteniendo tickets de Zendesk...');

        let allTickets = [];
        let nextPage = '/api/v2/tickets.json?per_page=100'; // Comenzar con página 1
        let pageCount = 0;
        const maxPages = 100; // Límite de seguridad para evitar bucles infinitos

        while (nextPage && pageCount < maxPages) {
            try {
                console.log(`Obteniendo página ${pageCount + 1}...`);
                
                const response = await client.request({
                    url: nextPage,
                    type: 'GET',
                    contentType: 'application/json',
                    headers: {
                        'Accept': 'application/json'
                    }
                });

                if (response.tickets && Array.isArray(response.tickets)) {
                    allTickets = allTickets.concat(response.tickets);
                    console.log(`Página ${pageCount + 1}: ${response.tickets.length} tickets. Total: ${allTickets.length}`);
                }

                // Verificar si hay más páginas
                nextPage = response.next_page || null;
                pageCount++;

                // Pequeña pausa para no sobrecargar la API
                if (nextPage) {
                    await new Promise(resolve => setTimeout(resolve, 100));
                }

            } catch (pageError) {
                console.error(`Error en página ${pageCount + 1}:`, pageError);
                break; // Salir del bucle si hay error en una página
            }
        }

        console.log(`Total de tickets obtenidos: ${allTickets.length}`);

        // Actualizar cache y construir índices optimizados
        ticketsCache.data = allTickets;
        ticketsCache.lastFetch = Date.now();
        
        // Construir índices para búsquedas rápidas
        buildOptimizedIndices(allTickets);

        return allTickets;

    } catch (error) {
        console.error('Error al obtener tickets:', error);
        // En caso de error, retornar cache si existe
        return ticketsCache.data || [];
    } finally {
        isFetchingTickets = false;
        hideLoadingIndicator();
    }
}

// Función de debounce para evitar múltiples llamadas rápidas
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Procesar tickets en lotes para evitar bloquear la UI
function processTicketsInBatches(tickets, processorFunction, batchSize = 1000) {
    return new Promise((resolve) => {
        const results = [];
        let currentIndex = 0;

        function processBatch() {
            const batch = tickets.slice(currentIndex, currentIndex + batchSize);
            
            if (batch.length === 0) {
                resolve(results);
                return;
            }

            // Procesar lote actual
            const batchResults = processorFunction(batch);
            results.push(...batchResults);

            currentIndex += batchSize;

            // Usar setTimeout para no bloquear la UI
            setTimeout(processBatch, 0);
        }

        processBatch();
    });
}

// Actualizar datos del gráfico principal - optimizado
async function updateTicketsData() {
    try {
        console.log('Iniciando actualización de datos optimizada...');
        const startTime = performance.now();
        
        const startDate = document.getElementById('startDate').value;
        const endDate = document.getElementById('endDate').value;
        const scale = document.getElementById('scaleDashboard').value;
        
        // Mostrar indicador de carga
        const chartContainer = document.getElementById('realtimeTrend');
        if (chartContainer) {
            chartContainer.style.opacity = '0.5';
        }
        
        const tickets = await getTickets();
        console.log('Tickets obtenidos:', tickets.length);
        
        // Usar filtrado optimizado con índices
        const currentTickets = getFilteredTicketsOptimized(startDate, endDate);
        console.log('Tickets filtrados:', currentTickets.length);
        
        // Usar índices pre-calculados para agregación rápida
        const aggregatedData = getAggregatedDataOptimized(currentTickets, scale, startDate, endDate);

        const timestamps = Object.keys(aggregatedData).sort().map(key => {
            const date = parseKeyToDate(key, scale);
            return date.getTime() / 1000;
        });
        
        const values = Object.keys(aggregatedData).sort().map(key => aggregatedData[key]);
        const superiorLimitValues = new Array(values.length).fill(12);

        if (ticketsPlot) {
            const updateStart = performance.now();
            console.log(`Actualizando gráfico con ${values.length} puntos de datos...`);
            ticketsPlot.setData([timestamps, values, superiorLimitValues]);
            
            // Actualizar el título del gráfico
            let title = "";
            switch(scale) {
                case 'hourly': title = "Tickets por Hora"; break;
                case 'daily': title = "Tickets por Día"; break;
                case 'monthly': title = "Tickets por Mes"; break;
                case 'yearly': title = "Tickets por Año"; break;
            }
            if (ticketsPlot.setTitle) {
                ticketsPlot.setTitle(title);
            }
            
            const updateEnd = performance.now();
            console.log(`Gráfico actualizado en ${(updateEnd - updateStart).toFixed(2)}ms`);
        }

        // Restaurar opacidad
        if (chartContainer) {
            chartContainer.style.opacity = '1';
        }

        const endTime = performance.now();
        console.log(`Actualización completa en ${(endTime - startTime).toFixed(2)}ms`);
        
    } catch (error) {
        console.error('Error al actualizar datos del gráfico:', error);
        // Restaurar opacidad en caso de error
        const chartContainer = document.getElementById('realtimeTrend');
        if (chartContainer) {
            chartContainer.style.opacity = '1';
        }
    }
}

// Función optimizada para agregación de datos usando índices
function getAggregatedDataOptimized(tickets, scale, startDate, endDate) {
    const aggregatedData = {};
    const startDateObj = new Date(startDate);
    const endDateObj = new Date(endDate + 'T23:59:59');
    
    // Usar el índice apropiado según la escala
    let relevantIndex;
    switch(scale) {
        case 'hourly':
            relevantIndex = ticketsCache.indices.byHour;
            break;
        case 'daily':
            relevantIndex = ticketsCache.indices.byDate;
            break;
        case 'monthly':
            relevantIndex = ticketsCache.indices.byMonth;
            break;
        case 'yearly':
            relevantIndex = ticketsCache.indices.byYear;
            break;
        default:
            // Fallback al método tradicional
            return getAggregatedDataTraditional(tickets, scale);
    }
    
    // Generar todas las claves posibles en el rango de fechas
    const keys = generateDateKeys(startDateObj, endDateObj, scale);
    
    keys.forEach(key => {
        const ticketsForKey = relevantIndex.get(key);
        if (ticketsForKey) {
            // Filtrar por rango de fechas específico si es necesario
            const filteredTickets = ticketsForKey.filter(ticket => {
                const ticketDate = new Date(ticket.created_at);
                return ticketDate >= startDateObj && ticketDate <= endDateObj;
            });
            aggregatedData[key] = filteredTickets.length;
        } else {
            aggregatedData[key] = 0;
        }
    });
    
    return aggregatedData;
}

// Generar claves de fecha para un rango específico
function generateDateKeys(startDate, endDate, scale) {
    const keys = [];
    const current = new Date(startDate);
    
    switch(scale) {
        case 'hourly':
            while (current <= endDate) {
                keys.push(current.toISOString().slice(0, 13));
                current.setHours(current.getHours() + 1);
            }
            break;
        case 'daily':
            while (current <= endDate) {
                keys.push(current.toISOString().split('T')[0]);
                current.setDate(current.getDate() + 1);
            }
            break;
        case 'monthly':
            current.setDate(1); // Primer día del mes
            while (current <= endDate) {
                keys.push(current.toISOString().slice(0, 7));
                current.setMonth(current.getMonth() + 1);
            }
            break;
        case 'yearly':
            while (current.getFullYear() <= endDate.getFullYear()) {
                keys.push(current.getFullYear().toString());
                current.setFullYear(current.getFullYear() + 1);
            }
            break;
    }
    
    return keys;
}

// Convertir clave de fecha a objeto Date
function parseKeyToDate(key, scale) {
    switch(scale) {
        case 'hourly':
            return new Date(key + ':00:00');
        case 'daily':
            return new Date(key + 'T00:00:00');
        case 'monthly':
            return new Date(key + '-01T00:00:00');
        case 'yearly':
            return new Date(key + '-01-01T00:00:00');
        default:
            return new Date(key);
    }
}

// Método tradicional como fallback
function getAggregatedDataTraditional(tickets, scale) {
    const aggregatedData = {};
    
    tickets.forEach(ticket => {
        const date = new Date(ticket.created_at);
        let key;
        
        switch(scale) {
            case 'hourly':
                key = date.toISOString().slice(0, 13);
                break;
            case 'daily':
                key = date.toISOString().split('T')[0];
                break;
            case 'monthly':
                key = date.toISOString().slice(0, 7);
                break;
            case 'yearly':
                key = date.getFullYear().toString();
                break;
        }
        
        aggregatedData[key] = (aggregatedData[key] || 0) + 1;
    });
    
    return aggregatedData;
}

// Iniciar actualizaciones periódicas optimizadas
function startPeriodicUpdates() {
    // Actualizar inmediatamente con datos del cache si existen
    if (ticketsCache.data.length > 0) {
        debouncedUpdateTicketsData();
    } else {
        updateTicketsData(); // Primera carga completa
    }
    
    if (updateIntervalId) {
        clearInterval(updateIntervalId);
    }
    
    // Aumentar el intervalo a 10 minutos para reducir carga
    updateIntervalId = setInterval(() => {
        // Solo actualizar si la página está visible
        if (!document.hidden) {
            // Forzar refresh cada 10 minutos para obtener datos frescos
            getTickets(true).then(() => {
                debouncedUpdateTicketsData();
            });
        }
    }, 600000); // 10 minutos
}

// Optimizar la función de análisis de tickets
function analyzeTickets(tickets) {
    // Si hay muchos tickets, usar una muestra para métricas básicas
    const sampleSize = Math.min(tickets.length, 5000);
    const sample = tickets.length > sampleSize ? 
        tickets.slice(0, sampleSize) : tickets;
    
    const today = new Date().toISOString().split('T')[0];
    const totalTickets = tickets.length; // Usar el total real
    
    // Usar muestra para cálculos más complejos
    const ticketsToday = sample.filter(t => t.created_at.startsWith(today)).length;
    const pendingTickets = sample.filter(t => t.status === 'pending').length;
    const resolvedTickets = sample.filter(t => t.status === 'solved').length;
    
    // Extrapolar los resultados si se usó una muestra
    const scaleFactor = tickets.length / sample.length;
    const adjustedTicketsToday = Math.round(ticketsToday * scaleFactor);
    const adjustedPendingTickets = Math.round(pendingTickets * scaleFactor);
    const adjustedResolvedTickets = Math.round(resolvedTickets * scaleFactor);
    
    const resolutionRate = totalTickets > 0 ? 
        (adjustedResolvedTickets / totalTickets * 100).toFixed(1) : 0;

    return {
        totalTickets,
        ticketsToday: adjustedTicketsToday,
        pendingTickets: adjustedPendingTickets,
        resolutionRate
    };
}

// Actualizar el dashboard
async function updateDashboard() {
    try {
        const startDate = document.getElementById('startDate').value;
        const endDate = document.getElementById('endDate').value;
        
        const tickets = await getTickets();
        const filteredTickets = tickets.filter(ticket => {
            const ticketDate = new Date(ticket.created_at);
            return ticketDate >= new Date(startDate) && ticketDate <= new Date(endDate + 'T23:59:59');
        });
        
        const data = analyzeTickets(filteredTickets);
        updateMetrics(data);
    } catch (error) {
        console.error('Error al actualizar el dashboard:', error);
    }
}

// Actualizar métricas
function updateMetrics(data) {
    document.getElementById('total-tickets').textContent = data.totalTickets;
    document.getElementById('tickets-hoy').textContent = data.ticketsToday;
    document.getElementById('tickets-pendientes').textContent = data.pendingTickets;
    document.getElementById('tasa-resolucion').textContent = `${data.resolutionRate}%`;
}

// Inicializar gráficos de la página detallada
function initDetailedPlots() {
    console.log('Iniciando inicialización de gráficos detallados...');
    const dailyContainer = document.getElementById('dailyTrendDetailed');
    const monthlyContainer = document.getElementById('monthlyTrendDetailed');

    // Destruir instancias de gráficos existentes si las hay
    if (dailyPlotDetailed) {
        dailyPlotDetailed.destroy();
        dailyPlotDetailed = null;
    }
    if (monthlyPlotDetailed) {
        monthlyPlotDetailed.destroy();
        monthlyPlotDetailed = null;
    }

    console.log('Contenedores encontrados (Detallado):', {
        daily: !!dailyContainer,
        monthly: !!monthlyContainer
    });

    if (!dailyContainer || !monthlyContainer) {
        console.error('No se encontraron todos los contenedores necesarios para gráficos detallados.');
        return;
    }

    console.log('dailyContainer offsetWidth:', dailyContainer.offsetWidth);
    console.log('monthlyContainer offsetWidth:', monthlyContainer.offsetWidth);

    const getBarColor = (value, maxValue) => {
        // Asegurarse de que maxValue sea un número positivo finito para evitar divisiones por cero o NaN
        if (!Number.isFinite(maxValue) || maxValue <= 0) {
            maxValue = 1; // Usar 1 como valor por defecto si maxValue no es válido
        }

        const percentage = value / maxValue;
        if (percentage < 0.33) return "#2196F3"; // Azul para valores bajos (0-33%)
        if (percentage < 0.66) return "#4CAF50"; // Verde para valores medios (33-66%)
        return "#F44336"; // Rojo para valores altos (66-100%)
    };

    const baseOpts = {
        width: dailyContainer.offsetWidth, // Usar ancho del dailyContainer
        height: 300,
        cursor: {
            show: true,
            sync: {
                key: "detailedSync"
            }
        },
        scales: {
            x: {
                time: true,
            },
            y: {
                auto: true,
            }
        },
        axes: [
            {
                stroke: "#03363d",
                grid: { show: true, stroke: "#d8dcde" },
                ticks: { show: true, stroke: "#03363d" },
                font: "12px Arial",
                values: (self, splits) => splits.map(s => {
                    const date = new Date(s * 1000);
                    return new Intl.DateTimeFormat('es-EC', {
                        month: 'short',
                        day: 'numeric',
                        timeZone: 'America/Guayaquil'
                    }).format(date);
                }),
            },
            {
                stroke: "#03363d",
                grid: { show: true, stroke: "#d8dcde" },
                ticks: { show: true, stroke: "#03363d" },
                font: "12px Arial",
            }
        ]
    };

    try {
        console.log('Creando gráfico diario detallado...');
        const dailyOpts = {
            ...baseOpts,
            title: "Tickets por Día (Detallado)",
            series: [
                {},
                {
                    stroke: (u, seriesIdx, dataIdx) => {
                        // Comprobación robusta para asegurar que u y u.data existan y que seriesData sea un array
                        if (!u || !u.data || !Array.isArray(u.data[seriesIdx])) {
                            return "#CCCCCC"; // Color por defecto si los datos no son válidos
                        }
                        const seriesData = u.data[seriesIdx];
                        if (dataIdx < 0 || dataIdx >= seriesData.length) {
                            return "#CCCCCC"; 
                        }
                        const value = seriesData[dataIdx];
                        const maxValue = seriesData.length > 0 ? Math.max(...seriesData) : 1; 
                        return getBarColor(value, maxValue);
                    },
                    width: 2,
                    fill: (u, seriesIdx, dataIdx) => {
                        // Comprobación robusta para asegurar que u y u.data existan y que seriesData sea un array
                        if (!u || !u.data || !Array.isArray(u.data[seriesIdx])) {
                            return "#CCCCCC80"; // Color por defecto si los datos no son válidos
                        }
                        const seriesData = u.data[seriesIdx];
                        if (dataIdx < 0 || dataIdx >= seriesData.length) {
                            return "#CCCCCC80";
                        }
                        const value = seriesData[dataIdx];
                        const maxValue = seriesData.length > 0 ? Math.max(...seriesData) : 1; 
                        return getBarColor(value, maxValue) + "80";
                    },
                    label: "Tickets por día",
                    paths: uPlot.paths.bars(),
                    points: { show: false },
                }
            ]
        };
        dailyPlotDetailed = new uPlot(dailyOpts, [[0, 1], [0, 0]], dailyContainer); // Modificado para incluir dos puntos dummy
        console.log('Gráfico diario detallado creado:', dailyPlotDetailed);

        console.log('Creando gráfico mensual detallado...');
        const monthlyOpts = {
            ...baseOpts,
            title: "Tickets por Mes (Detallado)",
            series: [
                {},
                {
                    stroke: (u, seriesIdx, dataIdx) => {
                        // Comprobación robusta para asegurar que u y u.data existan y que seriesData sea un array
                        if (!u || !u.data || !Array.isArray(u.data[seriesIdx])) {
                            return "#CCCCCC"; // Color por defecto si los datos no son válidos
                        }
                        const seriesData = u.data[seriesIdx];
                        if (dataIdx < 0 || dataIdx >= seriesData.length) {
                            return "#CCCCCC"; 
                        }
                        const value = seriesData[dataIdx];
                        const maxValue = seriesData.length > 0 ? Math.max(...seriesData) : 1; 
                        return getBarColor(value, maxValue);
                    },
                    width: 2,
                    fill: (u, seriesIdx, dataIdx) => {
                        // Comprobación robusta para asegurar que u y u.data existan y que seriesData sea un array
                        if (!u || !u.data || !Array.isArray(u.data[seriesIdx])) {
                            return "#CCCCCC80"; // Color por defecto si los datos no son válidos
                        }
                        const seriesData = u.data[seriesIdx];
                        if (dataIdx < 0 || dataIdx >= seriesData.length) {
                            return "#CCCCCC80"; 
                        }
                        const value = seriesData[dataIdx];
                        const maxValue = seriesData.length > 0 ? Math.max(...seriesData) : 1; 
                        return getBarColor(value, maxValue) + "80";
                    },
                    label: "Tickets por mes",
                    paths: uPlot.paths.bars(),
                    points: { show: false },
                }
            ]
        };
        monthlyPlotDetailed = new uPlot(monthlyOpts, [[0, 1], [0, 0]], monthlyContainer); // Modificado para incluir dos puntos dummy
        console.log('Gráfico mensual detallado creado:', monthlyPlotDetailed);

        // Añadir listener de redimensionamiento para ambos gráficos detallados
        window.addEventListener('resize', () => {
            if (dailyPlotDetailed && dailyContainer) {
                dailyPlotDetailed.setSize({ width: dailyContainer.offsetWidth, height: 300 });
            }
            if (monthlyPlotDetailed && monthlyContainer) {
                monthlyPlotDetailed.setSize({ width: monthlyContainer.offsetWidth, height: 300 });
            }
        });

    } catch (error) {
        console.error('Error al crear los gráficos detallados:', error);
    }
}

// Actualizar análisis detallado
async function updateDetailedAnalysis() {
    try {
        console.log('Iniciando actualización de análisis detallado avanzado...');
        const startTime = performance.now();
        
        const startDate = document.getElementById('startDateDetailed').value;
        const endDate = document.getElementById('endDateDetailed').value;
        console.log('Fechas de filtro detallado:', { startDate, endDate });
        
        const tickets = await getTickets();
        console.log('Tickets obtenidos para análisis detallado:', tickets.length);
        
        // Usar filtrado optimizado
        const currentTickets = getFilteredTicketsOptimized(startDate, endDate);
        console.log('Tickets filtrados para análisis detallado:', currentTickets.length);

        // Realizar análisis avanzado
        const advancedAnalysis = performAdvancedAnalysis(currentTickets);
        console.log('Análisis avanzado completado:', advancedAnalysis);

        // Actualizar gráficos con datos optimizados
        await updateDetailedChartsOptimized(currentTickets, startDate, endDate);

        // Actualizar métricas básicas (optimizado)
        updateBasicMetrics(currentTickets, advancedAnalysis);

        // Actualizar análisis predictivo avanzado
        updateAdvancedPredictiveAnalysis(advancedAnalysis);

        // Mostrar insights y recomendaciones mejoradas
        updateAdvancedInsights(advancedAnalysis);

        const endTime = performance.now();
        console.log(`Análisis detallado completado en ${(endTime - startTime).toFixed(2)}ms`);

    } catch (error) {
        console.error('Error al actualizar análisis detallado:', error);
    }
}

// Actualizar gráficos detallados de forma optimizada
async function updateDetailedChartsOptimized(tickets, startDate, endDate) {
    // Usar índices pre-calculados para generar datos de gráficos
    const dailyData = getAggregatedDataOptimized(tickets, 'daily', startDate, endDate);
    const monthlyData = getAggregatedDataOptimized(tickets, 'monthly', startDate, endDate);

    // Actualizar gráfico diario
    const dailyTimestamps = Object.keys(dailyData).sort().map(key => {
        const date = parseKeyToDate(key, 'daily');
        return date.getTime() / 1000;
    });
    const dailyValues = Object.keys(dailyData).sort().map(key => dailyData[key]);
    
    console.log('Datos diarios para gráfico detallado:', { dailyTimestamps, dailyValues });

    if (dailyPlotDetailed) {
        console.log('Actualizando dailyPlotDetailed...');
        dailyPlotDetailed.setData([dailyTimestamps, dailyValues]);
    } else {
        console.error('dailyPlotDetailed no está inicializado.');
    }

    // Actualizar gráfico mensual
    const monthlyTimestamps = Object.keys(monthlyData).sort().map(key => {
        const date = parseKeyToDate(key, 'monthly');
        return date.getTime() / 1000;
    });
    const monthlyValues = Object.keys(monthlyData).sort().map(key => monthlyData[key]);
    
    console.log('Datos mensuales para gráfico detallado:', { monthlyTimestamps, monthlyValues });

    if (monthlyPlotDetailed) {
        console.log('Actualizando monthlyPlotDetailed...');
        monthlyPlotDetailed.setData([monthlyTimestamps, monthlyValues]);
    } else {
        console.error('monthlyPlotDetailed no está inicializado.');
    }
}

// Actualizar métricas básicas optimizado
function updateBasicMetrics(tickets, analysis) {
    if (tickets.length === 0) {
        ['dailyAverage', 'peakDays', 'seasonality'].forEach(id => {
            const element = document.getElementById(id);
            if (element) element.textContent = 'Sin datos';
        });
        return;
    }

    // Usar estadísticas pre-calculadas cuando sea posible
    const dailyValues = Object.values(getAggregatedDataOptimized(tickets, 'daily', 
        tickets[0].created_at.split('T')[0], 
        tickets[tickets.length - 1].created_at.split('T')[0]));
    
    if (dailyValues.length > 0) {
        const average = dailyValues.reduce((a, b) => a + b, 0) / dailyValues.length;
        const maxValue = Math.max(...dailyValues);
        const minValue = Math.min(...dailyValues);
        
        // Usar análisis de tendencias del análisis avanzado
        const trend = analysis.trends.temporal || { slope: 0 };
        const trendPercentage = trend.slope || 0;

        // Actualizar métricas en la UI
        const dailyAvgElement = document.getElementById('dailyAverage');
        if (dailyAvgElement) {
            dailyAvgElement.textContent = `Promedio: ${average.toFixed(1)} tickets por día`;
        }

        const peakDaysElement = document.getElementById('peakDays');
        if (peakDaysElement) {
            peakDaysElement.textContent = `Máximo: ${maxValue} tickets, Mínimo: ${minValue} tickets`;
        }

        const seasonalityElement = document.getElementById('seasonality');
        if (seasonalityElement) {
            seasonalityElement.textContent = `Tendencia: ${trendPercentage > 0 ? '↑' : trendPercentage < 0 ? '↓' : '→'} ${Math.abs(trendPercentage).toFixed(1)}%`;
        }
    }
}

// Actualizar análisis predictivo avanzado
function updateAdvancedPredictiveAnalysis(analysis) {
    const trendElement = document.getElementById('trendAnalysis');
    const predictionElement = document.getElementById('nextMonthPrediction');
    const recommendationsElement = document.getElementById('recommendations');

    if (!trendElement || !predictionElement || !recommendationsElement) {
        console.warn('Elementos de análisis predictivo no encontrados');
        return;
    }

    // Análisis de tendencias mejorado
    if (analysis.trends.temporal && analysis.trends.temporal.trend !== 'insufficient_data') {
        const trend = analysis.trends.temporal;
        let trendText = '';
        
        switch(trend.trend) {
            case 'increasing':
                trendText = `Tendencia creciente detectada con ${(trend.correlation * 100).toFixed(1)}% de confianza. `;
                if (trend.volatility > 0.5) {
                    trendText += 'Alta variabilidad observada. ';
                }
                if (trend.cycles.length > 0) {
                    trendText += `Patrón cíclico detectado cada ${trend.cycles[0].period} días.`;
                }
                break;
            case 'decreasing':
                trendText = `Tendencia decreciente detectada con ${(trend.correlation * 100).toFixed(1)}% de confianza. `;
                break;
            case 'stable':
                trendText = 'Volumen de tickets estable. ';
                if (trend.volatility > 0.5) {
                    trendText += 'Se observan fluctuaciones significativas.';
                }
                break;
        }
        
        trendElement.textContent = trendText;
    } else {
        trendElement.textContent = 'Datos insuficientes para análisis de tendencias.';
    }

    // Predicciones mejoradas
    if (analysis.predictions && !analysis.predictions.error) {
        const pred = analysis.predictions;
        const confidenceText = pred.confidence > 0.7 ? 'alta' : pred.confidence > 0.4 ? 'media' : 'baja';
        
        predictionElement.textContent = 
            `Predicciones (confianza ${confidenceText}): ` +
            `7 días: ${pred.next7Days} tickets, ` +
            `30 días: ${pred.next30Days} tickets, ` +
            `90 días: ${pred.next90Days} tickets.`;
    } else {
        predictionElement.textContent = 'No se pueden generar predicciones con los datos actuales.';
    }

    // Recomendaciones avanzadas
    const recommendations = generateAdvancedRecommendations(analysis);
    recommendationsElement.textContent = recommendations.join(' ');
}

// Generar recomendaciones avanzadas basadas en el análisis
function generateAdvancedRecommendations(analysis) {
    const recommendations = [];
    
    // Recomendaciones basadas en patrones semanales
    if (analysis.patterns.weeklyPattern) {
        const wp = analysis.patterns.weeklyPattern;
        const maxDeviation = Math.max(...wp.pattern.map(p => Math.abs(parseFloat(p.deviation))));
        
        if (maxDeviation > 50) {
            recommendations.push(`Considere ajustar la dotación de personal: ${wp.busiestDay.day} requiere ${wp.busiestDay.percentage}% más recursos.`);
        }
    }

    // Recomendaciones basadas en patrones horarios
    if (analysis.patterns.hourlyPattern) {
        const hp = analysis.patterns.hourlyPattern;
        const afterHoursPercentage = (hp.afterHours.reduce((sum, h) => sum + h.count, 0) / 
            (hp.businessHours.reduce((sum, h) => sum + h.count, 0) + hp.afterHours.reduce((sum, h) => sum + h.count, 0))) * 100;
        
        if (afterHoursPercentage > 20) {
            recommendations.push(`${afterHoursPercentage.toFixed(1)}% de tickets fuera de horario laboral. Considere soporte 24/7.`);
        }
        
        if (hp.peakHour.hour >= 9 && hp.peakHour.hour <= 17) {
            recommendations.push(`Hora pico: ${hp.peakHour.hour}:00. Optimice recursos durante este período.`);
        }
    }

    // Recomendaciones basadas en tendencias
    if (analysis.trends.temporal && analysis.trends.temporal.trend !== 'insufficient_data') {
        const trend = analysis.trends.temporal;
        
        if (trend.trend === 'increasing' && trend.slope > 1) {
            recommendations.push('Tendencia creciente significativa. Planifique expansión del equipo de soporte.');
        }
        
        if (trend.volatility > 0.7) {
            recommendations.push('Alta variabilidad detectada. Implemente estrategias de gestión de demanda variable.');
        }
        
        if (trend.cycles.length > 0) {
            const mainCycle = trend.cycles[0];
            recommendations.push(`Patrón cíclico cada ${mainCycle.period} días. Use para planificación predictiva.`);
        }
    }

    // Recomendaciones basadas en anomalías
    if (analysis.anomalies.length > 0) {
        const highAnomalies = analysis.anomalies.filter(a => a.significance === 'high');
        if (highAnomalies.length > 0) {
            recommendations.push(`${highAnomalies.length} anomalías significativas detectadas. Investigue causas raíz.`);
        }
    }

    // Recomendaciones por defecto si no hay suficientes datos
    if (recommendations.length === 0) {
        recommendations.push('Continúe monitoreando las métricas para obtener más insights.');
    }

    return recommendations;
}

// Actualizar insights avanzados
function updateAdvancedInsights(analysis) {
    // Crear sección de insights si no existe
    let insightsContainer = document.getElementById('advanced-insights');
    if (!insightsContainer) {
        // Crear el contenedor después del análisis predictivo
        const recommendationsElement = document.getElementById('recommendations');
        if (recommendationsElement && recommendationsElement.parentNode) {
            insightsContainer = document.createElement('div');
            insightsContainer.id = 'advanced-insights';
            insightsContainer.className = 'mt-4';
            recommendationsElement.parentNode.insertBefore(insightsContainer, recommendationsElement.nextSibling);
        }
    }

    if (!insightsContainer) return;

    // Generar HTML para insights avanzados
    let insightsHTML = '<div class="card"><div class="card-header"><h6 class="mb-0">🔍 Insights Avanzados</h6></div><div class="card-body">';
    
    if (analysis.insights.length > 0) {
        insightsHTML += '<ul class="list-group list-group-flush">';
        analysis.insights.forEach(insight => {
            insightsHTML += `<li class="list-group-item">${insight}</li>`;
        });
        insightsHTML += '</ul>';
    } else {
        insightsHTML += '<p class="text-muted">No hay suficientes datos para generar insights avanzados.</p>';
    }

    // Agregar sección de anomalías si existen
    if (analysis.anomalies.length > 0) {
        insightsHTML += '<div class="mt-3"><h6>⚠️ Anomalías Detectadas</h6><ul class="list-group list-group-flush">';
        analysis.anomalies.slice(0, 3).forEach(anomaly => {
            const typeIcon = anomaly.type === 'spike' ? '📈' : '📉';
            insightsHTML += `<li class="list-group-item">${typeIcon} ${anomaly.date}: ${anomaly.count} tickets (Z-score: ${anomaly.zScore})</li>`;
        });
        insightsHTML += '</ul></div>';
    }

    insightsHTML += '</div></div>';
    insightsContainer.innerHTML = insightsHTML;
}

// Calcular tendencia
function calculateTrend(values) {
    if (values.length < 2) return 0;
    const xMean = (values.length - 1) / 2;
    const yMean = values.reduce((a, b) => a + b, 0) / values.length;
    
    let numerator = 0;
    let denominator = 0;
    
    values.forEach((y, x) => {
        numerator += (x - xMean) * (y - yMean);
        denominator += Math.pow(x - xMean, 2);
    });
    
    const slope = numerator / denominator;
    return (slope / yMean) * 100;
}

// Predecir próximo mes
function predictNextMonth(values, trend) {
    const lastValue = values[values.length - 1];
    return lastValue * (1 + trend / 100);
}

// Generar recomendaciones
function generateRecommendations(trend, average, maxValue) {
    const recommendations = [];
    
    if (trend > 5) {
        recommendations.push("Considerar aumentar el personal de soporte.");
    } else if (trend < -5) {
        recommendations.push("Evaluar la eficiencia del equipo actual.");
    }
    
    if (maxValue > average * 2) {
        recommendations.push("Implementar estrategias para manejar picos de demanda.");
    }
    
    if (average > 50) {
        recommendations.push("Revisar procesos para optimizar tiempos de respuesta.");
    }
    
    return recommendations.length > 0 ? recommendations.join(" ") : "No se requieren cambios inmediatos.";
}

// Función para construir índices optimizados
function buildOptimizedIndices(tickets) {
    console.log('Construyendo índices optimizados...');
    const start = performance.now();
    
    // Limpiar índices existentes
    Object.values(ticketsCache.indices).forEach(map => map.clear());
    
    // Construir índices en una sola pasada
    tickets.forEach(ticket => {
        const date = new Date(ticket.created_at);
        const dateKey = date.toISOString().split('T')[0];
        const monthKey = date.toISOString().slice(0, 7);
        const yearKey = date.getFullYear().toString();
        const hourKey = date.toISOString().slice(0, 13);
        const dayOfWeek = date.getDay();
        
        // Índice por fecha
        if (!ticketsCache.indices.byDate.has(dateKey)) {
            ticketsCache.indices.byDate.set(dateKey, []);
        }
        ticketsCache.indices.byDate.get(dateKey).push(ticket);
        
        // Índice por status
        if (!ticketsCache.indices.byStatus.has(ticket.status)) {
            ticketsCache.indices.byStatus.set(ticket.status, []);
        }
        ticketsCache.indices.byStatus.get(ticket.status).push(ticket);
        
        // Índice por mes
        if (!ticketsCache.indices.byMonth.has(monthKey)) {
            ticketsCache.indices.byMonth.set(monthKey, []);
        }
        ticketsCache.indices.byMonth.get(monthKey).push(ticket);
        
        // Índice por año
        if (!ticketsCache.indices.byYear.has(yearKey)) {
            ticketsCache.indices.byYear.set(yearKey, []);
        }
        ticketsCache.indices.byYear.get(yearKey).push(ticket);
        
        // Índice por hora
        if (!ticketsCache.indices.byHour.has(hourKey)) {
            ticketsCache.indices.byHour.set(hourKey, []);
        }
        ticketsCache.indices.byHour.get(hourKey).push(ticket);
        
        // Índice por día de la semana
        if (!ticketsCache.indices.byDay.has(dayOfWeek)) {
            ticketsCache.indices.byDay.set(dayOfWeek, []);
        }
        ticketsCache.indices.byDay.get(dayOfWeek).push(ticket);
    });
    
    // Calcular estadísticas básicas
    calculateBasicStats(tickets);
    
    const end = performance.now();
    console.log(`Índices construidos en ${(end - start).toFixed(2)}ms`);
}

// Función para calcular estadísticas básicas
function calculateBasicStats(tickets) {
    if (tickets.length === 0) return;
    
    const dates = tickets.map(t => new Date(t.created_at)).sort();
    const statusCounts = {};
    
    tickets.forEach(ticket => {
        statusCounts[ticket.status] = (statusCounts[ticket.status] || 0) + 1;
    });
    
    ticketsCache.stats = {
        totalTickets: tickets.length,
        dateRange: {
            min: dates[0],
            max: dates[dates.length - 1]
        },
        statusDistribution: statusCounts,
        averagePerDay: tickets.length / Math.max(1, (dates[dates.length - 1] - dates[0]) / (1000 * 60 * 60 * 24)),
        averagePerMonth: tickets.length / Math.max(1, (dates[dates.length - 1] - dates[0]) / (1000 * 60 * 60 * 24 * 30)),
        lastCalculated: Date.now()
    };
}

// Función de filtrado optimizado usando índices
function getFilteredTicketsOptimized(startDate, endDate, additionalFilters = {}) {
    const start = performance.now();
    
    if (ticketsCache.indices.byDate.size === 0) {
        console.warn('Índices no construidos, usando filtrado tradicional');
        return ticketsCache.data.filter(ticket => {
            const ticketDate = new Date(ticket.created_at);
            return ticketDate >= new Date(startDate) && ticketDate <= new Date(endDate + 'T23:59:59');
        });
    }
    
    const startDateObj = new Date(startDate);
    const endDateObj = new Date(endDate + 'T23:59:59');
    const filteredTickets = [];
    
    // Iterar solo sobre las fechas en el rango
    for (let d = new Date(startDateObj); d <= endDateObj; d.setDate(d.getDate() + 1)) {
        const dateKey = d.toISOString().split('T')[0];
        const dayTickets = ticketsCache.indices.byDate.get(dateKey);
        
        if (dayTickets) {
            if (additionalFilters.status) {
                filteredTickets.push(...dayTickets.filter(t => t.status === additionalFilters.status));
            } else {
                filteredTickets.push(...dayTickets);
            }
        }
    }
    
    const end = performance.now();
    console.log(`Filtrado optimizado completado en ${(end - start).toFixed(2)}ms. Tickets: ${filteredTickets.length}`);
    
    return filteredTickets;
}

// Análisis avanzado de patrones y tendencias
function performAdvancedAnalysis(tickets) {
    const analysis = {
        patterns: {},
        trends: {},
        predictions: {},
        anomalies: [],
        insights: []
    };
    
    if (tickets.length === 0) return analysis;
    
    // 1. Análisis de patrones por día de la semana
    analysis.patterns.weeklyPattern = analyzeWeeklyPattern(tickets);
    
    // 2. Análisis de patrones por hora del día
    analysis.patterns.hourlyPattern = analyzeHourlyPattern(tickets);
    
    // 3. Análisis de tendencias temporales
    analysis.trends.temporal = analyzeTemporal(tickets);
    
    // 4. Detección de anomalías
    analysis.anomalies = detectAnomalies(tickets);
    
    // 5. Predicciones basadas en tendencias
    analysis.predictions = generatePredictions(tickets);
    
    // 6. Insights automáticos
    analysis.insights = generateInsights(analysis);
    
    return analysis;
}

// Análisis de patrones semanales
function analyzeWeeklyPattern(tickets) {
    const dayNames = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
    const dayCounts = new Array(7).fill(0);
    
    tickets.forEach(ticket => {
        const dayOfWeek = new Date(ticket.created_at).getDay();
        dayCounts[dayOfWeek]++;
    });
    
    const total = dayCounts.reduce((a, b) => a + b, 0);
    const averagePerDay = total / 7;
    
    const pattern = dayCounts.map((count, index) => ({
        day: dayNames[index],
        count,
        percentage: ((count / total) * 100).toFixed(1),
        deviation: ((count - averagePerDay) / averagePerDay * 100).toFixed(1)
    }));
    
    const busiestDay = pattern.reduce((max, day) => day.count > max.count ? day : max);
    const quietestDay = pattern.reduce((min, day) => day.count < min.count ? day : min);
    
    return {
        pattern,
        busiestDay,
        quietestDay,
        variance: calculateVariance(dayCounts)
    };
}

// Análisis de patrones por hora
function analyzeHourlyPattern(tickets) {
    const hourCounts = new Array(24).fill(0);
    
    tickets.forEach(ticket => {
        const hour = new Date(ticket.created_at).getHours();
        hourCounts[hour]++;
    });
    
    const total = hourCounts.reduce((a, b) => a + b, 0);
    const pattern = hourCounts.map((count, hour) => ({
        hour,
        count,
        percentage: ((count / total) * 100).toFixed(1)
    }));
    
    const peakHour = pattern.reduce((max, hour) => hour.count > max.count ? hour : max);
    const quietestHour = pattern.reduce((min, hour) => hour.count < min.count ? hour : min);
    
    return {
        pattern,
        peakHour,
        quietestHour,
        businessHours: pattern.filter(h => h.hour >= 9 && h.hour <= 17),
        afterHours: pattern.filter(h => h.hour < 9 || h.hour > 17)
    };
}

// Análisis temporal de tendencias
function analyzeTemporal(tickets) {
    if (tickets.length < 7) return { trend: 'insufficient_data' };
    
    // Agrupar por días
    const dailyData = {};
    tickets.forEach(ticket => {
        const date = new Date(ticket.created_at).toISOString().split('T')[0];
        dailyData[date] = (dailyData[date] || 0) + 1;
    });
    
    const sortedDates = Object.keys(dailyData).sort();
    const values = sortedDates.map(date => dailyData[date]);
    
    // Calcular tendencia usando regresión lineal simple
    const trend = calculateLinearTrend(values);
    
    // Calcular volatilidad
    const volatility = calculateVolatility(values);
    
    // Detectar ciclos
    const cycles = detectCycles(values);
    
    return {
        trend: trend.slope > 0.1 ? 'increasing' : trend.slope < -0.1 ? 'decreasing' : 'stable',
        slope: trend.slope,
        correlation: trend.correlation,
        volatility,
        cycles,
        movingAverage: calculateMovingAverage(values, 7)
    };
}

// Detección de anomalías
function detectAnomalies(tickets) {
    const dailyData = {};
    tickets.forEach(ticket => {
        const date = new Date(ticket.created_at).toISOString().split('T')[0];
        dailyData[date] = (dailyData[date] || 0) + 1;
    });
    
    const values = Object.values(dailyData);
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    const stdDev = Math.sqrt(values.reduce((sq, n) => sq + Math.pow(n - mean, 2), 0) / values.length);
    
    const anomalies = [];
    Object.entries(dailyData).forEach(([date, count]) => {
        const zScore = Math.abs((count - mean) / stdDev);
        if (zScore > 2) { // Más de 2 desviaciones estándar
            anomalies.push({
                date,
                count,
                zScore: zScore.toFixed(2),
                type: count > mean ? 'spike' : 'drop',
                significance: zScore > 3 ? 'high' : 'medium'
            });
        }
    });
    
    return anomalies.sort((a, b) => b.zScore - a.zScore);
}

// Generar predicciones
function generatePredictions(tickets) {
    const analysis = analyzeTemporal(tickets);
    
    if (analysis.trend === 'insufficient_data') {
        return { error: 'Datos insuficientes para predicciones' };
    }
    
    const lastValue = analysis.movingAverage[analysis.movingAverage.length - 1];
    const trendMultiplier = analysis.slope;
    
    // Predicciones para los próximos 7, 30 y 90 días
    const predictions = {
        next7Days: Math.max(0, Math.round(lastValue + (trendMultiplier * 7))),
        next30Days: Math.max(0, Math.round(lastValue + (trendMultiplier * 30))),
        next90Days: Math.max(0, Math.round(lastValue + (trendMultiplier * 90))),
        confidence: Math.max(0.1, Math.min(0.9, 1 - analysis.volatility))
    };
    
    return predictions;
}

// Generar insights automáticos
function generateInsights(analysis) {
    const insights = [];
    
    if (analysis.patterns.weeklyPattern) {
        const wp = analysis.patterns.weeklyPattern;
        insights.push(`El ${wp.busiestDay.day} es el día más ocupado con ${wp.busiestDay.count} tickets (${wp.busiestDay.percentage}% del total)`);
        insights.push(`El ${wp.quietestDay.day} es el día más tranquilo con ${wp.quietestDay.count} tickets`);
    }
    
    if (analysis.patterns.hourlyPattern) {
        const hp = analysis.patterns.hourlyPattern;
        insights.push(`La hora pico es ${hp.peakHour.hour}:00 con ${hp.peakHour.count} tickets`);
        
        const businessHoursTotal = hp.businessHours.reduce((sum, h) => sum + h.count, 0);
        const afterHoursTotal = hp.afterHours.reduce((sum, h) => sum + h.count, 0);
        const businessHoursPercentage = ((businessHoursTotal / (businessHoursTotal + afterHoursTotal)) * 100).toFixed(1);
        
        insights.push(`${businessHoursPercentage}% de los tickets ocurren en horario laboral (9-17h)`);
    }
    
    if (analysis.trends.temporal && analysis.trends.temporal.trend !== 'insufficient_data') {
        const trend = analysis.trends.temporal;
        if (trend.trend === 'increasing') {
            insights.push(`Tendencia creciente detectada: aumento promedio de ${trend.slope.toFixed(1)} tickets por día`);
        } else if (trend.trend === 'decreasing') {
            insights.push(`Tendencia decreciente detectada: disminución promedio de ${Math.abs(trend.slope).toFixed(1)} tickets por día`);
        }
        
        if (trend.volatility > 0.5) {
            insights.push('Alta variabilidad en el volumen de tickets detectada');
        }
    }
    
    if (analysis.anomalies.length > 0) {
        const significantAnomalies = analysis.anomalies.filter(a => a.significance === 'high');
        if (significantAnomalies.length > 0) {
            insights.push(`${significantAnomalies.length} anomalías significativas detectadas en el período`);
        }
    }
    
    return insights;
}

// Funciones auxiliares para cálculos estadísticos
function calculateVariance(values) {
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    return values.reduce((sq, n) => sq + Math.pow(n - mean, 2), 0) / values.length;
}

function calculateLinearTrend(values) {
    const n = values.length;
    const x = Array.from({length: n}, (_, i) => i);
    const sumX = x.reduce((a, b) => a + b, 0);
    const sumY = values.reduce((a, b) => a + b, 0);
    const sumXY = x.reduce((sum, xi, i) => sum + xi * values[i], 0);
    const sumXX = x.reduce((sum, xi) => sum + xi * xi, 0);
    
    const slope = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);
    const intercept = (sumY - slope * sumX) / n;
    
    // Calcular correlación
    const meanX = sumX / n;
    const meanY = sumY / n;
    const num = x.reduce((sum, xi, i) => sum + (xi - meanX) * (values[i] - meanY), 0);
    const denX = Math.sqrt(x.reduce((sum, xi) => sum + Math.pow(xi - meanX, 2), 0));
    const denY = Math.sqrt(values.reduce((sum, yi) => sum + Math.pow(yi - meanY, 2), 0));
    const correlation = num / (denX * denY);
    
    return { slope, intercept, correlation };
}

function calculateVolatility(values) {
    if (values.length < 2) return 0;
    const returns = values.slice(1).map((val, i) => (val - values[i]) / Math.max(1, values[i]));
    const meanReturn = returns.reduce((a, b) => a + b, 0) / returns.length;
    const variance = returns.reduce((sq, r) => sq + Math.pow(r - meanReturn, 2), 0) / returns.length;
    return Math.sqrt(variance);
}

function detectCycles(values) {
    // Implementación simple de detección de ciclos usando autocorrelación
    const cycles = [];
    for (let lag = 1; lag <= Math.min(30, Math.floor(values.length / 2)); lag++) {
        const correlation = calculateAutocorrelation(values, lag);
        if (correlation > 0.3) {
            cycles.push({ period: lag, strength: correlation });
        }
    }
    return cycles.sort((a, b) => b.strength - a.strength);
}

function calculateAutocorrelation(values, lag) {
    const n = values.length - lag;
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    
    let num = 0, den = 0;
    for (let i = 0; i < n; i++) {
        num += (values[i] - mean) * (values[i + lag] - mean);
    }
    
    for (let i = 0; i < values.length; i++) {
        den += Math.pow(values[i] - mean, 2);
    }
    
    return den === 0 ? 0 : num / den;
}

function calculateMovingAverage(values, window) {
    const result = [];
    for (let i = window - 1; i < values.length; i++) {
        const avg = values.slice(i - window + 1, i + 1).reduce((a, b) => a + b, 0) / window;
        result.push(avg);
    }
    return result;
}

// ========== FUNCIONES PARA LA PÁGINA DE INDICADORES ==========

// Inicializar la página de indicadores
function initIndicatorsPage() {
    console.log('Inicializando página de indicadores...');
    initTicketsEvolutionChart();
    
    // Cargar datos automáticamente al abrir la página
    setTimeout(() => {
        const startDate = document.getElementById('startDateIndicators').value;
        const endDate = document.getElementById('endDateIndicators').value;
        
        if (startDate && endDate) {
            console.log('Cargando datos iniciales para indicadores...');
            updateIndicators();
        }
    }, 500);
}

// Inicializar el gráfico de evolución de tickets
function initTicketsEvolutionChart() {
    const container = document.getElementById('ticketsEvolutionChart');
    if (!container) return;

    // Limpiar contenedor
    container.innerHTML = '';

    // Asegurar que el contenedor tenga dimensiones
    const containerWidth = container.clientWidth || 800;
    const containerHeight = 350;

    const opts = {
        width: containerWidth,
        height: containerHeight,
        series: [
            {
                label: 'Fecha',
            },
            {
                label: 'Tickets Nuevos',
                stroke: '#007bff',
                fill: 'rgba(0, 123, 255, 0.1)',
                width: 3,
                points: {
                    show: true,
                    size: 6,
                    fill: '#007bff',
                }
            },
            {
                label: 'Tickets Resueltos',
                stroke: '#28a745',
                fill: 'rgba(40, 167, 69, 0.1)', 
                width: 3,
                points: {
                    show: true,
                    size: 6,
                    fill: '#28a745',
                }
            }
        ],
        axes: [
            {
                stroke: '#333',
                grid: {
                    show: true,
                    stroke: '#e9ecef',
                    width: 1,
                },
                ticks: {
                    show: true,
                    stroke: '#333',
                },
                font: '12px Arial',
                size: 50,
                space: 50,
                values: (u, vals) => vals.map(v => {
                    const date = new Date(v * 1000);
                    return date.toLocaleDateString('es-ES', { 
                        month: 'short', 
                        day: 'numeric' 
                    });
                })
            },
            {
                stroke: '#333',
                grid: {
                    show: true,
                    stroke: '#e9ecef',
                    width: 1,
                },
                ticks: {
                    show: true,
                    stroke: '#333',
                },
                font: '12px Arial',
                size: 60,
                space: 40,
                label: 'Cantidad de Tickets',
                labelSize: 14,
                labelFont: 'bold 14px Arial',
                side: 3,
            }
        ],
        cursor: {
            lock: true,
            focus: {
                prox: 16,
            },
            sync: {
                key: 'indicators',
            },
        },
        legend: {
            show: true,
            live: true,
            markers: {
                width: 2,
                dash: 'solid',
            },
        },
        padding: [16, 16, 16, 16],
    };

    // Crear datos iniciales vacíos
    const initialData = [
        [Date.now() / 1000], // timestamps
        [0], // tickets nuevos
        [0]  // tickets resueltos  
    ];

    ticketsEvolutionPlot = new uPlot(opts, initialData, container);
    
    // Redimensionar el gráfico cuando cambie el tamaño del contenedor
    window.addEventListener('resize', () => {
        if (ticketsEvolutionPlot && container) {
            const newWidth = container.clientWidth || 800;
            ticketsEvolutionPlot.setSize({ width: newWidth, height: containerHeight });
        }
    });
}

// Obtener datos de tickets nuevos y resueltos
async function getTicketsEvolutionData(startDate, endDate) {
    try {
        console.log('Obteniendo datos de evolución de tickets para período:', startDate, 'a', endDate);
        
        // Formatear fechas para la API de Zendesk (agregar tiempo)
        const formattedStartDate = startDate + 'T00:00:00Z';
        const formattedEndDate = endDate + 'T23:59:59Z';
        
        // Obtener tickets nuevos (creados)
        const newTicketsQuery = `type:ticket created>=${formattedStartDate} created<=${formattedEndDate}`;
        console.log('Query para tickets nuevos:', newTicketsQuery);
        
        const newTicketsResponse = await client.request({
            url: '/api/v2/search.json?query=' + encodeURIComponent(newTicketsQuery) + '&sort_by=created_at&sort_order=asc',
            type: 'GET'
        });

        // Obtener tickets resueltos
        const solvedTicketsQuery = `type:ticket status:solved updated>=${formattedStartDate} updated<=${formattedEndDate}`;
        console.log('Query para tickets resueltos:', solvedTicketsQuery);
        
        const solvedTicketsResponse = await client.request({
            url: '/api/v2/search.json?query=' + encodeURIComponent(solvedTicketsQuery) + '&sort_by=updated_at&sort_order=asc',
            type: 'GET'
        });

        console.log('Tickets nuevos encontrados:', newTicketsResponse.results?.length || 0);
        console.log('Tickets resueltos encontrados:', solvedTicketsResponse.results?.length || 0);

        return {
            newTickets: newTicketsResponse.results || [],
            solvedTickets: solvedTicketsResponse.results || []
        };
    } catch (error) {
        console.error('Error obteniendo datos de evolución:', error);
        console.error('Error details:', error);
        return { newTickets: [], solvedTickets: [] };
    }
}

// Obtener datos de satisfacción
async function getSatisfactionData(startDate, endDate) {
    try {
        console.log('Obteniendo datos de satisfacción para período:', startDate, 'a', endDate);
        
        // Obtener todos los ratings (últimos 1000 para tener un buen pool)
        const response = await client.request({
            url: '/api/v2/satisfaction_ratings.json?sort_by=created_at&sort_order=desc&per_page=1000',
            type: 'GET'
        });

        let ratings = response.satisfaction_ratings || [];
        console.log('Total de ratings obtenidos:', ratings.length);

        // Si se proporcionan fechas, filtrar por rango de fechas
        if (startDate && endDate) {
            const start = new Date(startDate + 'T00:00:00Z');
            const end = new Date(endDate + 'T23:59:59Z');
            
            ratings = ratings.filter(rating => {
                const ratingDate = new Date(rating.created_at);
                return ratingDate >= start && ratingDate <= end;
            });
            
            console.log('Ratings filtrados por fecha:', ratings.length);
        }

        // Tomar los últimos 100 ratings del período seleccionado
        const recentRatings = ratings.slice(0, 100);
        console.log('Ratings finales para cálculo:', recentRatings.length);
        
        return recentRatings;
    } catch (error) {
        console.error('Error obteniendo datos de satisfacción:', error);
        console.error('Error details:', error);
        return [];
    }
}

// Procesar datos de evolución para el gráfico
function processEvolutionData(newTickets, solvedTickets, startDate, endDate) {
    const dates = [];
    const newTicketsCounts = [];
    const solvedTicketsCounts = [];

    console.log('Procesando datos de evolución:', {
        newTicketsCount: newTickets.length,
        solvedTicketsCount: solvedTickets.length,
        startDate,
        endDate
    });

    // Generar todas las fechas en el rango
    const start = new Date(startDate);
    const end = new Date(endDate);
    const current = new Date(start);

    while (current <= end) {
        const dateStr = current.toISOString().split('T')[0];
        dates.push(current.getTime() / 1000); // uPlot usa timestamps en segundos
        
        // Contar tickets nuevos para esta fecha
        const newCount = newTickets.filter(ticket => {
            if (!ticket || !ticket.created_at) return false;
            const ticketDate = new Date(ticket.created_at).toISOString().split('T')[0];
            return ticketDate === dateStr;
        }).length;
        
        // Contar tickets resueltos para esta fecha
        const solvedCount = solvedTickets.filter(ticket => {
            if (!ticket || !ticket.updated_at) return false;
            const ticketDate = new Date(ticket.updated_at).toISOString().split('T')[0];
            return ticketDate === dateStr;
        }).length;

        newTicketsCounts.push(newCount);
        solvedTicketsCounts.push(solvedCount);

        current.setDate(current.getDate() + 1);
    }

    // Asegurar que tengamos al menos un punto de datos
    if (dates.length === 0) {
        const now = Date.now() / 1000;
        dates.push(now);
        newTicketsCounts.push(0);
        solvedTicketsCounts.push(0);
    }

    console.log('Datos procesados:', {
        fechas: dates.length,
        nuevos: newTicketsCounts,
        resueltos: solvedTicketsCounts
    });

    return [dates, newTicketsCounts, solvedTicketsCounts];
}

// Procesar datos de satisfacción
function processSatisfactionData(ratings) {
    if (!ratings || ratings.length === 0) {
        return {
            average: 0,
            count: 0,
            distribution: { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 }
        };
    }

    // Los ratings ya vienen filtrados por fecha y limitados a 100
    const scores = ratings
        .filter(rating => rating.score !== null && rating.score !== undefined)
        .map(rating => rating.score);

    if (scores.length === 0) {
        return {
            average: 0,
            count: 0,
            distribution: { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 }
        };
    }

    const average = scores.reduce((sum, score) => sum + score, 0) / scores.length;
    
    // Contar distribución de puntuaciones
    const distribution = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
    scores.forEach(score => {
        if (distribution[score] !== undefined) {
            distribution[score]++;
        }
    });

    return {
        average: average,
        count: scores.length,
        distribution: distribution
    };
}

// Actualizar el indicador de satisfacción
function updateSatisfactionDisplay(satisfactionData) {
    const scoreValue = document.querySelector('.score-value');
    const starsContainer = document.getElementById('satisfactionStars');
    const countElement = document.getElementById('satisfactionCount');
    const avgSatisfactionElement = document.getElementById('avgSatisfaction');

    console.log('Actualizando display de satisfacción con datos:', satisfactionData);

    const displayValue = satisfactionData.count > 0 ? satisfactionData.average.toFixed(1) : '--';
    const displayText = satisfactionData.count > 0 ? 
        `${satisfactionData.count} evaluaciones` : 
        'Sin evaluaciones en este período';

    if (scoreValue) {
        scoreValue.textContent = displayValue;
    }

    if (avgSatisfactionElement) {
        avgSatisfactionElement.textContent = displayValue;
    }

    if (countElement) {
        countElement.textContent = displayText;
    }

    // Actualizar estrellas
    if (starsContainer) {
        const stars = starsContainer.querySelectorAll('.star');
        
        if (satisfactionData.count === 0) {
            // Sin datos - mostrar estrellas vacías
            stars.forEach((star) => {
                star.textContent = '☆';
                star.classList.remove('filled');
                star.classList.add('empty');
            });
        } else {
            // Con datos - calcular estrellas llenas
            const fullStars = Math.floor(satisfactionData.average);
            const hasHalfStar = satisfactionData.average % 1 >= 0.5;

            stars.forEach((star, index) => {
                star.classList.remove('filled', 'empty');
                if (index < fullStars) {
                    star.textContent = '★';
                    star.classList.add('filled');
                } else if (index === fullStars && hasHalfStar) {
                    star.textContent = '★';
                    star.classList.add('filled');
                } else {
                    star.textContent = '☆';
                    star.classList.add('empty');
                }
            });
        }
    }
}

// Actualizar métricas de la página de indicadores
function updateIndicatorsMetrics(newTickets, solvedTickets, satisfactionData) {
    const totalNewElement = document.getElementById('totalNewTickets');
    const totalSolvedElement = document.getElementById('totalSolvedTickets');
    const resolutionRateElement = document.getElementById('resolutionRate');

    if (totalNewElement) {
        totalNewElement.textContent = newTickets.length.toLocaleString();
    }

    if (totalSolvedElement) {
        totalSolvedElement.textContent = solvedTickets.length.toLocaleString();
    }

    if (resolutionRateElement) {
        const rate = newTickets.length > 0 ? ((solvedTickets.length / newTickets.length) * 100) : 0;
        resolutionRateElement.textContent = rate.toFixed(1) + '%';
    }
}

// Función principal para actualizar todos los indicadores
async function updateIndicators() {
    try {
        showLoadingIndicator();
        
        const startDate = document.getElementById('startDateIndicators').value;
        const endDate = document.getElementById('endDateIndicators').value;

        if (!startDate || !endDate) {
            console.log('Fechas no válidas para indicadores');
            hideLoadingIndicator();
            return;
        }

        // Validar que la fecha de inicio no sea posterior a la fecha de fin
        if (new Date(startDate) > new Date(endDate)) {
            console.log('Fecha de inicio posterior a fecha de fin');
            document.getElementById('date-filter-alert-indicators').classList.remove('d-none');
            hideLoadingIndicator();
            return;
        }

        document.getElementById('date-filter-alert-indicators').classList.add('d-none');
        console.log('Actualizando indicadores para el período:', startDate, 'a', endDate);

        // Obtener datos en paralelo
        const [evolutionData, satisfactionRatings] = await Promise.all([
            getTicketsEvolutionData(startDate, endDate),
            getSatisfactionData(startDate, endDate)
        ]);

        console.log('Datos obtenidos - Nuevos:', evolutionData.newTickets.length, 'Resueltos:', evolutionData.solvedTickets.length, 'Ratings:', satisfactionRatings.length);

        // Procesar datos de evolución
        if (ticketsEvolutionPlot) {
            const chartData = processEvolutionData(
                evolutionData.newTickets, 
                evolutionData.solvedTickets, 
                startDate, 
                endDate
            );
            console.log('Datos del gráfico procesados - Fechas:', chartData[0].length, 'Nuevos:', chartData[1].length, 'Resueltos:', chartData[2].length);
            ticketsEvolutionPlot.setData(chartData);
        }

        // Procesar y mostrar datos de satisfacción
        const satisfactionData = processSatisfactionData(satisfactionRatings);
        console.log('Datos de satisfacción procesados:', satisfactionData);
        updateSatisfactionDisplay(satisfactionData);

        // Actualizar métricas
        updateIndicatorsMetrics(evolutionData.newTickets, evolutionData.solvedTickets, satisfactionData);

        console.log('Indicadores actualizados correctamente');
    } catch (error) {
        console.error('Error actualizando indicadores:', error);
        console.error('Stack trace:', error.stack);
    } finally {
        hideLoadingIndicator();
    }
}
const client = ZAFClient.init();
let ticketsPlot = null;
let dailyPlotDetailed = null;
let monthlyPlotDetailed = null;
let comparisonPlot1 = null;
let comparisonPlot2 = null;
let hourlyComparisonPlot = null;
let monthlyComparisonPlot = null;
let statusPieChart = null;
let updateIntervalId = null;
let systemLoadRefreshInterval = null;

// Variables globales para caché optimizado
let ticketsCache = {
    data: [],
    lastFetch: null,
    cacheExpiry: 2 * 60 * 1000, // 2 minutos para datos críticos
    indices: {}
};

let dataCache = {
    status: { data: null, lastFetch: null, expiry: 5 * 60 * 1000 }, // 5 minutos
    priority: { data: null, lastFetch: null, expiry: 5 * 60 * 1000 },
    unassigned: { data: null, lastFetch: null, expiry: 3 * 60 * 1000 }, // 3 minutos
    satisfaction: { data: null, lastFetch: null, expiry: 10 * 60 * 1000 }, // 10 minutos
    // evolution: eliminado (página de indicadores removida)
};

// Sistema de caché inteligente
function isCacheValid(cacheEntry) {
    if (!cacheEntry.data || !cacheEntry.lastFetch) return false;
    return (Date.now() - cacheEntry.lastFetch) < cacheEntry.expiry;
}

function updateCache(cacheKey, data) {
    if (dataCache[cacheKey]) {
        dataCache[cacheKey].data = data;
        dataCache[cacheKey].lastFetch = Date.now();
    }
}

function getFromCache(cacheKey) {
    const cache = dataCache[cacheKey];
    if (cache && isCacheValid(cache)) {
        console.log(`📋 Usando datos del caché: ${cacheKey}`);
        return cache.data;
    }
    return null;
}

// Sistema de carga progresiva
async function loadDataWithCache(loadFunction, cacheKey, fallbackData = null) {
    // Intentar obtener del caché primero
    const cachedData = getFromCache(cacheKey);
    if (cachedData !== null) {
        return cachedData;
    }
    
    try {
        console.log(`🔄 Cargando datos frescos: ${cacheKey}`);
        const data = await loadFunction();
        updateCache(cacheKey, data);
        return data;
    } catch (error) {
        console.error(`Error cargando ${cacheKey}:`, error);
        // Retornar datos del caché expirado si están disponibles, o fallback
        const expiredCache = dataCache[cacheKey];
        if (expiredCache && expiredCache.data) {
            console.log(`⚠️ Usando datos expirados del caché: ${cacheKey}`);
            return expiredCache.data;
        }
        return fallbackData;
    }
}

// Flag para evitar múltiples llamadas simultáneas
let isFetchingTickets = false;

function setDefaultDates() {
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - 30);
    const dateInputs = ['startDate', 'endDate', 'startDate1', 'endDate1', 'startDate2', 'endDate2', 'startDateDetailed', 'endDateDetailed', 'startDateHourlyComp', 'endDateHourlyComp', 'startDateMonthlyComp', 'endDateMonthlyComp', 'startDateSystemLoad', 'endDateSystemLoad'];
    dateInputs.forEach(id => {
        const input = document.getElementById(id);
        if (input) {
            const dateValue = id.includes('start') ? startDate : endDate;
            input.value = dateValue.toISOString().split('T')[0];
        }
    });
}



function togglePeriodicUpdates() {
    const syncToggleButton = document.getElementById('syncToggle');
    if (updateIntervalId) {
        clearInterval(updateIntervalId);
        updateIntervalId = null;
        syncToggleButton.textContent = 'Iniciar Sincronización';
        console.log('Sincronización automática detenida.');
    } else {
        startPeriodicUpdates();
        syncToggleButton.textContent = 'Parar Sincronización';
        console.log('Sincronización automática iniciada.');
    }
}

function changePage(pageId) {
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
    });
    document.querySelector(`[data-page="${pageId}"]`).classList.add('active');

    document.getElementById('dashboard-page').classList.toggle('d-none', pageId !== 'dashboard');
    document.getElementById('detailed-page').classList.toggle('d-none', pageId !== 'detailed');
    document.getElementById('comparison-page').classList.toggle('d-none', pageId !== 'comparison');
    // indicators-page eliminada
    document.getElementById('system-load-page').classList.toggle('d-none', pageId !== 'system-load');
    document.getElementById('triggers-page').classList.toggle('d-none', pageId !== 'triggers');
    document.getElementById('tickets-page').classList.toggle('d-none', pageId !== 'tickets');

    if (pageId === 'comparison') {
        initComparisonPlots();
    } else if (pageId === 'detailed') {
        initDetailedPlots();
        updateDetailedAnalysis();
    // indicators página eliminada
    } else if (pageId === 'system-load') {
        initSystemLoadPage();
        updateSystemLoad();
    } else if (pageId === 'triggers') {
        initTriggersPage();
        loadTriggers();
    } else if (pageId === 'tickets') {
        console.log('🎫 Cambiando a página de tickets');
        
        // Verificar que la página se muestra correctamente
        const ticketsPage = document.getElementById('tickets-page');
        console.log('📄 Estado de página tickets:', {
            exists: !!ticketsPage,
            visible: ticketsPage ? !ticketsPage.classList.contains('d-none') : false,
            classes: ticketsPage ? ticketsPage.classList.toString() : 'N/A'
        });
        
        initTicketsPage();
        loadTicketsData();
    }
}

// Crear versiones con debounce de las funciones de actualización
const debouncedUpdateTicketsData = debounce(updateTicketsData, 500);
const debouncedUpdateDashboard = debounce(updateDashboard, 500);
const debouncedUpdateDetailedAnalysis = debounce(updateDetailedAnalysis, 500);

async function init() {
    try {
        console.log('Iniciando aplicación...');
        setDefaultDates();


        // Event listeners para navegación
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                changePage(e.target.dataset.page);
            });
        });


        document.getElementById('syncToggle').addEventListener('click', togglePeriodicUpdates);
        
        document.getElementById('applyFilter').addEventListener('click', async () => {
            const startDate = document.getElementById('startDate').value;
            const endDate = document.getElementById('endDate').value;
            
            if (!startDate || !endDate || new Date(startDate) > new Date(endDate)) {
                document.getElementById('date-filter-alert').classList.remove('d-none');
                return;
            }
            
            document.getElementById('date-filter-alert').classList.add('d-none');
            await Promise.all([debouncedUpdateDashboard(), debouncedUpdateTicketsData()]);
        });

        document.getElementById('applyFilterDetailed').addEventListener('click', async () => {
            const startDate = document.getElementById('startDateDetailed').value;
            const endDate = document.getElementById('endDateDetailed').value;
            
            if (!startDate || !endDate || new Date(startDate) > new Date(endDate)) {
                document.getElementById('date-filter-alert-detailed').classList.remove('d-none');
                return;
            }
            
            document.getElementById('date-filter-alert-detailed').classList.add('d-none');
            await debouncedUpdateDetailedAnalysis();
        });

        // Event listeners para los botones de filtro de comparación (existentes y nuevos)
        document.querySelectorAll('.apply-filter').forEach(button => {
            button.addEventListener('click', async (e) => {
                const chartNum = e.target.dataset.chart;
                const type = e.target.dataset.type || 'daily'; // Por defecto es diario
                const startDate = document.getElementById(`startDate${chartNum}`).value;
                const endDate = document.getElementById(`endDate${chartNum}`).value;
                
                if (!startDate || !endDate || new Date(startDate) > new Date(endDate)) {
                    return;
                }
                
                const currentSyncState = getComparisonSyncKey() !== null;
                const scale = document.getElementById(`scale${chartNum}`)?.value || 'daily';
                if (chartNum === '1') {
                    await updateComparisonChart(1, startDate, endDate, scale);
                } else if (chartNum === '2') {
                    await updateComparisonChart(2, startDate, endDate, scale);
                }
                const newSyncState = getComparisonSyncKey() !== null;
                if (currentSyncState !== newSyncState) {
                    console.log('Estado de sincronización cambió, reinicializando gráficos...');
                    initComparisonPlots();
                }
            });
        });
        document.querySelectorAll('#scale1, #scale2').forEach(select => {
            select.addEventListener('change', async (e) => {
                console.log('Escala de comparación cambiada, actualizando gráficos...');
                
                const chartNum = e.target.id === 'scale1' ? 1 : 2;
                const scale = e.target.value;
                const startDate = document.getElementById(`startDate${chartNum}`).value;
                const endDate = document.getElementById(`endDate${chartNum}`).value;
                
                if (startDate && endDate) {
                    await updateComparisonChart(chartNum, startDate, endDate, scale);
                }
                const newSyncState = getComparisonSyncKey() !== null;
                console.log('Nuevo estado de sincronización:', newSyncState);
                initComparisonPlots();
            });
        });

        document.querySelectorAll('.apply-filter-comp').forEach(button => {
            button.addEventListener('click', async (e) => {
                const chartType = e.target.dataset.chartType;
                const startDate = document.getElementById(`startDate${chartType}Comp`).value;
                const endDate = document.getElementById(`endDate${chartType}Comp`).value;

                if (!startDate || !endDate || new Date(startDate) > new Date(endDate)) {
                    return;
                }

                let plotInstance;
                let label;
                if (chartType === 'hourly') {
                    plotInstance = hourlyComparisonPlot;
                    label = 'Tickets por hora';
                } else if (chartType === 'monthly') {
                    plotInstance = monthlyComparisonPlot;
                    label = 'Tickets por mes';
                }

                if (plotInstance) {
                    await updateComparisonChartData(plotInstance, startDate, endDate, chartType, label);
                }
            });
        });

        // Event listener de indicadores eliminado

        // Event listeners para la página de carga del sistema
        document.getElementById('applyFilterSystemLoad').addEventListener('click', async () => {
            const startDate = document.getElementById('startDateSystemLoad').value;
            const endDate = document.getElementById('endDateSystemLoad').value;
            
            if (!startDate || !endDate || new Date(startDate) > new Date(endDate)) {
                document.getElementById('date-filter-alert-system-load').classList.remove('d-none');
                return;
            }
            
            document.getElementById('date-filter-alert-system-load').classList.add('d-none');
            await updateSystemLoad();
        });

        document.getElementById('refreshSystemLoad').addEventListener('click', async () => {
            await updateSystemLoad();
        });

        // Auto-refresh para carga del sistema
        document.getElementById('refreshInterval').addEventListener('change', (e) => {
            const interval = parseInt(e.target.value);
            
            // Limpiar intervalo anterior
            if (systemLoadRefreshInterval) {
                clearInterval(systemLoadRefreshInterval);
                systemLoadRefreshInterval = null;
            }
            
            // Configurar nuevo intervalo si es necesario
            if (interval > 0) {
                systemLoadRefreshInterval = setInterval(async () => {
                    if (document.getElementById('system-load-page').classList.contains('d-none')) {
                        return; // No actualizar si la página no está visible
                    }
                    
                    const refreshBtn = document.getElementById('refreshSystemLoad');
                    refreshBtn.classList.add('auto-refresh-active');
                    await updateSystemLoad();
                    refreshBtn.classList.remove('auto-refresh-active');
                }, interval * 1000);
            }
        });

        // Event listeners para la tabla de tickets
        document.getElementById('ticketsPerPage').addEventListener('change', () => {
            updateActiveTicketsTable();
        });

        document.getElementById('ticketSearch').addEventListener('input', debounce(() => {
            updateActiveTicketsTable();
        }, 300));

        console.log('Inicializando gráficos...');
        initTicketsPlot();
        console.log('Actualizando dashboard y datos iniciales...');
        await Promise.all([
            updateDashboard(),
            updateTicketsData()
        ]);
        
        console.log('Iniciando actualizaciones periódicas...');
        startPeriodicUpdates();
        document.getElementById('syncToggle').textContent = 'Parar Sincronización';
        
        // Ejecutar validación del sistema después de la inicialización
        setTimeout(() => {
            const healthReport = runAutomaticValidation();
            console.log('Reporte de salud del sistema:', healthReport);
        }, 2000);
        
        console.log('Aplicación inicializada correctamente');
    } catch (error) {
        console.error('Error al inicializar la aplicación:', error);
    }
}

document.addEventListener('DOMContentLoaded', init);
function initTicketsPlot() {
    console.log('Iniciando inicialización de gráficos...');
    
    const container = document.getElementById('realtimeTrend');
    
    console.log('Contenedores encontrados (Dashboard):', {
        realtime: !!container
    });

    if (!container) {
        console.error('No se encontró el contenedor del gráfico principal');
        return;
    }

    const baseOpts = {
        width: container.offsetWidth,
        height: 300,
        cursor: {
            show: true,
            sync: {
                key: "ticketSync"
            }
        },
        scales: {
            x: {
                time: true,
            },
            y: {
                auto: true,
            }
        },
        axes: [
            {
                stroke: "#03363d",
                grid: { show: true, stroke: "#d8dcde" },
                ticks: { show: true, stroke: "#03363d" },
                font: "12px Arial",
                values: (self, splits) => splits.map(s => {
                    const date = new Date(s * 1000);
                    const scale = document.getElementById('scaleDashboard').value; // Obtener la escala seleccionada para el dashboard
                    switch(scale) {
                        case 'hourly':
                            return new Intl.DateTimeFormat('es-EC', {
                                hour: 'numeric',
                                minute: 'numeric',
                                timeZone: 'America/Guayaquil'
                            }).format(date);
                        case 'daily':
                            return new Intl.DateTimeFormat('es-EC', {
                                month: 'short',
                                day: 'numeric',
                                timeZone: 'America/Guayaquil'
                            }).format(date);
                        case 'monthly':
                            return new Intl.DateTimeFormat('es-EC', {
                                month: 'long',
                                year: 'numeric',
                                timeZone: 'America/Guayaquil'
                            }).format(date);
                        case 'yearly':
                            return new Intl.DateTimeFormat('es-EC', {
                                year: 'numeric',
                                timeZone: 'America/Guayaquil'
                            }).format(date);
                    }
                }),
            },
            {
                stroke: "#03363d",
                grid: { show: true, stroke: "#d8dcde" },
                ticks: { show: true, stroke: "#03363d" },
                font: "12px Arial",
            }
        ]
    };

    try {
        console.log('Creando gráfico de tiempo real...');
        const opts = {
            ...baseOpts,
            title: "Tickets por Hora",
            series: [
                {},
                {
                    stroke: "#03363d",
                    width: 2,
                    fill: "rgba(3, 54, 61, 0.1)",
                    label: "Tickets reales",
                },
                {
                    label: "Límite superior",
                    stroke: "gold",
                    width: 2,
                    dash: [1, 5],
                }
            ]
        };
        ticketsPlot = new uPlot(opts, [[], []], container);
        console.log('Gráfico de tiempo real creado');
        const emptyData = [[], []];
        ticketsPlot.setData(emptyData);

    } catch (error) {
        console.error('Error al crear los gráficos del dashboard:', error);
    }
}

function getComparisonSyncKey() {
    const scale1 = document.getElementById('scale1')?.value || 'daily';
    const scale2 = document.getElementById('scale2')?.value || 'daily';
    
    if (scale1 === scale2) {
        return "comparisonSync";
    } else {
        return null;
    }
}

function initComparisonPlots() {
    console.log('Iniciando inicialización de gráficos de comparación...');

    const container1 = document.getElementById('chart1');
    const container2 = document.getElementById('chart2');

    if (comparisonPlot1) {
        comparisonPlot1.destroy();
        comparisonPlot1 = null;
    }
    if (comparisonPlot2) {
        comparisonPlot2.destroy();
        comparisonPlot2 = null;
    }

    console.log('Contenedores encontrados (Comparación):', {
        chart1: !!container1,
        chart2: !!container2
    });

    if (!container1 || !container2) {
        console.error('No se encontraron todos los contenedores necesarios para gráficos de comparación.');
        return;
    }

    const getBarColor = (value, maxValue) => {
        if (!Number.isFinite(maxValue) || maxValue <= 0) {
            maxValue = 1;
        }
        const percentage = value / maxValue;
        if (percentage < 0.33) return "#2196F3";
        if (percentage < 0.66) return "#4CAF50";
        return "#F44336";
    };

    const syncKey = getComparisonSyncKey();
    const shouldSync = syncKey !== null;
    console.log('Sincronización de gráficos:', shouldSync ? 'Habilitada' : 'Deshabilitada');

    const createAxisFormatter = (chartNum) => {
        return (self, splits) => splits.map(s => {
            const date = new Date(s * 1000);
            const scale = document.getElementById(`scale${chartNum}`).value;
            switch(scale) {
                case 'hourly':
                    return new Intl.DateTimeFormat('es-EC', {
                        hour: 'numeric',
                        minute: 'numeric',
                        timeZone: 'America/Guayaquil'
                    }).format(date);
                case 'daily':
                    return new Intl.DateTimeFormat('es-EC', {
                        month: 'short',
                        day: 'numeric',
                        timeZone: 'America/Guayaquil'
                    }).format(date);
                case 'monthly':
                    return new Intl.DateTimeFormat('es-EC', {
                        month: 'long',
                        year: 'numeric',
                        timeZone: 'America/Guayaquil'
                    }).format(date);
                case 'yearly':
                    return new Intl.DateTimeFormat('es-EC', {
                        year: 'numeric',
                        timeZone: 'America/Guayaquil'
                    }).format(date);
            }
        });
    };

    const createBaseOpts = (chartNum) => ({
        width: container1.offsetWidth,
        height: 300,
        cursor: shouldSync ? {
            show: true,
            sync: {
                key: syncKey
            }
        } : {
            show: true
        },
        scales: {
            x: {
                time: true,
            },
            y: {
                auto: true,
            }
        },
        axes: [
            {
                stroke: "#03363d",
                grid: { show: true, stroke: "#d8dcde" },
                ticks: { show: true, stroke: "#03363d" },
                font: "12px Arial",
                values: createAxisFormatter(chartNum),
            },
            {
                stroke: "#03363d",
                grid: { show: true, stroke: "#d8dcde" },
                ticks: { show: true, stroke: "#03363d" },
                font: "12px Arial",
            }
        ],
        series: [
            {},
            {
                stroke: (u, seriesIdx, dataIdx) => {
                    const seriesData = (u && u.data && Array.isArray(u.data[seriesIdx])) ? u.data[seriesIdx] : [];
                    if (dataIdx < 0 || dataIdx >= seriesData.length) {
                        return "#CCCCCC";
                    }
                    const value = seriesData[dataIdx];
                    const maxValue = seriesData.length > 0 ? Math.max(...seriesData) : 1;
                    return getBarColor(value, maxValue);
                },
                width: 2,
                fill: (u, seriesIdx, dataIdx) => {
                    const seriesData = (u && u.data && Array.isArray(u.data[seriesIdx])) ? u.data[seriesIdx] : [];
                    if (dataIdx < 0 || dataIdx >= seriesData.length) {
                        return "#CCCCCC80";
                    }
                    const value = seriesData[dataIdx];
                    const maxValue = seriesData.length > 0 ? Math.max(...seriesData) : 1;
                    return getBarColor(value, maxValue) + "80";
                },
                points: { show: false },
            }
        ]
    });

    try {
        console.log('Creando gráfico de comparación 1...');
        const opts1 = createBaseOpts(1);
        comparisonPlot1 = new uPlot({
            ...opts1,
            title: "Gráfico 1",
            series: [{
                },
                {
                    ...opts1.series[1],
                    label: "Tickets",
                    paths: uPlot.paths.bars(),
                }]
        }, [[], []], container1);
        console.log('Gráfico de comparación 1 creado:', comparisonPlot1);

        console.log('Creando gráfico de comparación 2...');
        const opts2 = createBaseOpts(2);
        comparisonPlot2 = new uPlot({
            ...opts2,
            title: "Gráfico 2",
            series: [{
                },
                {
                    ...opts2.series[1],
                    label: "Tickets",
                    paths: uPlot.paths.bars(),
                }]
        }, [[], []], container2);
        console.log('Gráfico de comparación 2 creado:', comparisonPlot2);

        window.addEventListener('resize', () => {
            if (comparisonPlot1 && container1) {
                comparisonPlot1.setSize({ width: container1.offsetWidth, height: 300 });
            }
            if (comparisonPlot2 && container2) {
                comparisonPlot2.setSize({ width: container2.offsetWidth, height: 300 });
            }
        });

    } catch (error) {
        console.error('Error al crear los gráficos de comparación:', error);
    }

    const startDate1 = document.getElementById('startDate1').value;
    const endDate1 = document.getElementById('endDate1').value;
    const startDate2 = document.getElementById('startDate2').value;
    const endDate2 = document.getElementById('endDate2').value;
    const scale1 = document.getElementById('scale1')?.value || 'daily';
    const scale2 = document.getElementById('scale2')?.value || 'daily';

    console.log('Inicializando gráficos con fechas:', {
        chart1: { startDate1, endDate1, scale1 },
        chart2: { startDate2, endDate2, scale2 }
    });

    setTimeout(() => {
        if (startDate1 && endDate1) {
            updateComparisonChart(1, startDate1, endDate1, scale1);
        } else {
            console.log('Gráfico 1: Fechas no disponibles, usando datos vacíos');
        }
        
        if (startDate2 && endDate2) {
            updateComparisonChart(2, startDate2, endDate2, scale2);
        } else {
            console.log('Gráfico 2: Fechas no disponibles, usando datos vacíos');
        }
    }, 100);
}

async function updateComparisonChart(chartNum, startDate, endDate, scale) {
    try {
        console.log(`Actualizando gráfico de comparación ${chartNum} con escala ${scale}...`);
        
        if (!startDate || !endDate) {
            console.warn(`Fechas no válidas para gráfico ${chartNum}`);
            return;
        }

        const tickets = await getTickets();
        
        const filteredTickets = tickets.filter(ticket => {
            const ticketDate = new Date(ticket.created_at);
            const start = new Date(startDate);
            const end = new Date(endDate + 'T23:59:59');
            return ticketDate >= start && ticketDate <= end;
        });

        console.log(`Tickets filtrados para gráfico ${chartNum}:`, filteredTickets.length);

        const aggregatedData = aggregateDataByScale(filteredTickets, scale, startDate, endDate);
        const timestamps = Object.keys(aggregatedData).sort().map(key => {
            const date = parseKeyToDate(key, scale);
            return date.getTime() / 1000;
        });
        
        const values = Object.keys(aggregatedData).sort().map(key => aggregatedData[key]);

        console.log(`Datos para gráfico ${chartNum}:`, { 
            timestamps: timestamps.length, 
            values: values.length,
            totalTickets: values.reduce((a, b) => a + b, 0),
            dataRange: values.length > 0 ? `${Math.min(...values)} - ${Math.max(...values)}` : 'Sin datos'
        });

        if (timestamps.length === 0 || values.length === 0) {
            console.warn(`Gráfico ${chartNum}: No hay datos para mostrar en el rango de fechas seleccionado`);
            timestamps.push(Date.now() / 1000);
            values.push(0);
        }

        if (chartNum === 1 && comparisonPlot1) {
            console.log('Actualizando comparisonPlot1...');
            try {
                comparisonPlot1.setData([timestamps, values]);
                window.chart1Data = values; // Guardar para análisis
                console.log('comparisonPlot1 actualizado exitosamente');
            } catch (error) {
                console.error('Error al actualizar comparisonPlot1:', error);
            }
        } else if (chartNum === 2 && comparisonPlot2) {
            console.log('Actualizando comparisonPlot2...');
            try {
                comparisonPlot2.setData([timestamps, values]);
                window.chart2Data = values; // Guardar para análisis
                console.log('comparisonPlot2 actualizado exitosamente');
            } catch (error) {
                console.error('Error al actualizar comparisonPlot2:', error);
            }
        } else {
            console.error(`Gráfico ${chartNum} no está inicializado o número inválido`);
            console.log('Estado de gráficos:', { comparisonPlot1: !!comparisonPlot1, comparisonPlot2: !!comparisonPlot2 });
            return;
        }

        if (window.chart1Data && window.chart2Data && window.chart1Data.length > 0 && window.chart2Data.length > 0) {
            console.log('Actualizando análisis de diferencias...');
            const analysis = analyzeDifferences(window.chart1Data, window.chart2Data);
            updateComparisonAnalysis(analysis);
        }

        console.log(`Gráfico ${chartNum} actualizado exitosamente`);
        
    } catch (error) {
        console.error(`Error al actualizar gráfico de comparación ${chartNum}:`, error);
    }
}

function aggregateDataByScale(tickets, scale, startDate, endDate) {
    const aggregatedData = {};
    const startDateObj = new Date(startDate);
    const endDateObj = new Date(endDate + 'T23:59:59');
    const keys = generateDateKeys(startDateObj, endDateObj, scale);
    keys.forEach(key => {
        aggregatedData[key] = 0;
    });
    
    tickets.forEach(ticket => {
        const date = new Date(ticket.created_at);
        let key;
        
        switch(scale) {
            case 'hourly':
                key = date.toISOString().slice(0, 13);
                break;
            case 'daily':
                key = date.toISOString().split('T')[0];
                break;
            case 'monthly':
                key = date.toISOString().slice(0, 7);
                break;
            case 'yearly':
                key = date.getFullYear().toString();
                break;
            default:
                key = date.toISOString().split('T')[0];
        }
        
        if (aggregatedData.hasOwnProperty(key)) {
            aggregatedData[key]++;
        }
    });
    
    return aggregatedData;
}

// Actualizar gráfico de comparación (generalizado)
async function updateComparisonChartData(plotInstance, startDate, endDate, type, label) {
    try {
        console.log(`Actualizando gráfico de comparación (${type})...`);
        const tickets = await getTickets();
        const filteredTickets = tickets.filter(ticket => {
            const ticketDate = new Date(ticket.created_at);
            return ticketDate >= new Date(startDate) && ticketDate <= new Date(endDate + 'T23:59:59');
        });

        let data = {};
        let timestamps = [];
        let values = [];
        let start = new Date(startDate);
        let end = new Date(endDate + 'T23:59:59');

        if (type === 'daily') {
            filteredTickets.forEach(ticket => {
                const date = new Date(ticket.created_at);
                const dayKey = date.toISOString().split('T')[0];
                data[dayKey] = (data[dayKey] || 0) + 1;
            });

            for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
                const dayKey = d.toISOString().split('T')[0];
                timestamps.push(d.getTime() / 1000);
                values.push(data[dayKey] || 0);
            }
        } else if (type === 'hourly') {
            filteredTickets.forEach(ticket => {
                const date = new Date(ticket.created_at);
                const hourKey = date.toISOString().slice(0, 13);
                data[hourKey] = (data[hourKey] || 0) + 1;
            });
            for (let d = new Date(start); d <= end; d.setHours(d.getHours() + 1)) {
                const hourKey = d.toISOString().slice(0, 13);
                timestamps.push(d.getTime() / 1000);
                values.push(data[hourKey] || 0);
            }
        } else if (type === 'monthly') {
            filteredTickets.forEach(ticket => {
                const date = new Date(ticket.created_at);
                const monthKey = date.toISOString().slice(0, 7);
                data[monthKey] = (data[monthKey] || 0) + 1;
            });
            let currentMonth = new Date(start.getFullYear(), start.getMonth(), 1);
            while (currentMonth <= end) {
                const monthKey = currentMonth.toISOString().slice(0, 7);
                timestamps.push(currentMonth.getTime() / 1000);
                values.push(data[monthKey] || 0);
                currentMonth.setMonth(currentMonth.getMonth() + 1);
            }
        }

        if (plotInstance) {
            plotInstance.setData([timestamps, values]);
            // Actualizar la etiqueta de la serie si es necesario (para los gráficos de línea)
            if (type === 'hourly') {
                plotInstance.series[1].label = label;
            }
        } else {
            console.error(`La instancia del gráfico para ${type} no está inicializada.`);
        }

    } catch (error) {
        console.error(`Error al actualizar gráfico de comparación (${type}):`, error);
    }
}

// Función para analizar las diferencias entre dos conjuntos de datos (mejorada)
function analyzeDifferences(data1, data2) {
    if (data1.length === 0 || data2.length === 0) {
        return {
            error: 'Uno o ambos conjuntos de datos están vacíos',
            differences: {},
            analysis: {},
            interpretation: ['No se puede realizar el análisis con datos vacíos.']
        };
    }

    // Estadísticas básicas
    const stats1 = calculateAdvancedStats(data1);
    const stats2 = calculateAdvancedStats(data2);

    // Diferencias absolutas y relativas
    const differences = {
        dataset1: stats1,
        dataset2: stats2,
        totalDifference: stats1.total - stats2.total,
        averageDifference: stats1.mean - stats2.mean,
        medianDifference: stats1.median - stats2.median,
        maxDifference: stats1.max - stats2.max,
        minDifference: stats1.min - stats2.min,
        varianceDifference: stats1.variance - stats2.variance,
        stdDevDifference: stats1.stdDev - stats2.stdDev
    };

    // Análisis avanzado
    const analysis = {
        // Cambios porcentuales
        totalPercentageChange: stats2.total !== 0 ? 
            ((stats1.total - stats2.total) / stats2.total * 100) : 0,
        averagePercentageChange: stats2.mean !== 0 ? 
            ((stats1.mean - stats2.mean) / stats2.mean * 100) : 0,
        
        // Análisis de volatilidad
        volatilityChange: {
            dataset1: calculateVolatility(data1),
            dataset2: calculateVolatility(data2),
            difference: calculateVolatility(data1) - calculateVolatility(data2)
        },
        
        // Correlación entre datasets (si tienen la misma longitud)
        correlation: data1.length === data2.length ? calculateCorrelation(data1, data2) : null,
        
        // Análisis de tendencias individuales
        trend1: calculateTrendAnalysis(data1),
        trend2: calculateTrendAnalysis(data2),
        
        // Análisis de distribución
        distribution: compareDistributions(data1, data2),
        
        // Prueba estadística de diferencia significativa
        significanceTest: performSignificanceTest(data1, data2),
        
        // Análisis de estacionalidad/patrones
        patterns: comparePatterns(data1, data2),
        
        // Métricas de consistencia
        consistency: {
            dataset1: calculateConsistency(data1),
            dataset2: calculateConsistency(data2)
        }
    };

    return {
        differences,
        analysis,
        interpretation: generateAdvancedInterpretation(differences, analysis),
        recommendations: generateComparisonRecommendations(differences, analysis)
    };
}

// Calcular estadísticas avanzadas para un dataset
function calculateAdvancedStats(data) {
    const sorted = [...data].sort((a, b) => a - b);
    const n = data.length;
    const total = data.reduce((a, b) => a + b, 0);
    const mean = total / n;
    
    return {
        total,
        mean,
        median: n % 2 === 0 ? 
            (sorted[n/2 - 1] + sorted[n/2]) / 2 : 
            sorted[Math.floor(n/2)],
        mode: calculateMode(data),
        min: Math.min(...data),
        max: Math.max(...data),
        range: Math.max(...data) - Math.min(...data),
        variance: data.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / n,
        stdDev: Math.sqrt(data.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / n),
        q1: sorted[Math.floor(n * 0.25)],
        q3: sorted[Math.floor(n * 0.75)],
        skewness: calculateSkewness(data, mean),
        kurtosis: calculateKurtosis(data, mean)
    };
}

// Calcular la moda (valor más frecuente)
function calculateMode(data) {
    const frequency = {};
    let maxFreq = 0;
    let mode = null;
    
    data.forEach(val => {
        frequency[val] = (frequency[val] || 0) + 1;
        if (frequency[val] > maxFreq) {
            maxFreq = frequency[val];
            mode = val;
        }
    });
    
    return mode;
}

// Calcular asimetría (skewness)
function calculateSkewness(data, mean) {
    const n = data.length;
    const variance = data.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / n;
    const stdDev = Math.sqrt(variance);
    
    if (stdDev === 0) return 0;
    
    const skewness = data.reduce((sum, val) => sum + Math.pow((val - mean) / stdDev, 3), 0) / n;
    return skewness;
}

// Calcular curtosis
function calculateKurtosis(data, mean) {
    const n = data.length;
    const variance = data.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / n;
    const stdDev = Math.sqrt(variance);
    
    if (stdDev === 0) return 0;
    
    const kurtosis = data.reduce((sum, val) => sum + Math.pow((val - mean) / stdDev, 4), 0) / n - 3;
    return kurtosis;
}

// Calcular correlación de Pearson
function calculateCorrelation(data1, data2) {
    const n = data1.length;
    if (n !== data2.length || n === 0) return null;
    
    const mean1 = data1.reduce((a, b) => a + b, 0) / n;
    const mean2 = data2.reduce((a, b) => a + b, 0) / n;
    
    let num = 0, den1 = 0, den2 = 0;
    
    for (let i = 0; i < n; i++) {
        const diff1 = data1[i] - mean1;
        const diff2 = data2[i] - mean2;
        num += diff1 * diff2;
        den1 += diff1 * diff1;
        den2 += diff2 * diff2;
    }
    
    const denominator = Math.sqrt(den1 * den2);
    return denominator === 0 ? 0 : num / denominator;
}

// Análisis de tendencias para un dataset
function calculateTrendAnalysis(data) {
    if (data.length < 2) return { trend: 'insufficient_data' };
    
    const trend = calculateLinearTrend(data);
    const movingAvg = calculateMovingAverage(data, Math.min(7, Math.floor(data.length / 3)));
    
    return {
        slope: trend.slope,
        correlation: trend.correlation,
        direction: trend.slope > 0.1 ? 'increasing' : trend.slope < -0.1 ? 'decreasing' : 'stable',
        strength: Math.abs(trend.correlation),
        movingAverage: movingAvg,
        changePoints: detectChangePoints(data)
    };
}

// Detectar puntos de cambio en una serie temporal
function detectChangePoints(data) {
    if (data.length < 6) return [];
    
    const changePoints = [];
    const windowSize = Math.max(3, Math.floor(data.length / 10));
    
    for (let i = windowSize; i < data.length - windowSize; i++) {
        const before = data.slice(i - windowSize, i);
        const after = data.slice(i, i + windowSize);
        
        const meanBefore = before.reduce((a, b) => a + b, 0) / before.length;
        const meanAfter = after.reduce((a, b) => a + b, 0) / after.length;
        
        const percentChange = Math.abs((meanAfter - meanBefore) / meanBefore * 100);
        
        if (percentChange > 30) { // Cambio significativo del 30%
            changePoints.push({
                index: i,
                beforeMean: meanBefore,
                afterMean: meanAfter,
                percentChange: percentChange,
                type: meanAfter > meanBefore ? 'increase' : 'decrease'
            });
        }
    }
    
    return changePoints;
}

// Comparar distribuciones
function compareDistributions(data1, data2) {
    const stats1 = calculateAdvancedStats(data1);
    const stats2 = calculateAdvancedStats(data2);
    
    return {
        centralTendency: {
            meanDifference: stats1.mean - stats2.mean,
            medianDifference: stats1.median - stats2.median,
            interpretation: Math.abs(stats1.mean - stats1.median) < Math.abs(stats2.mean - stats2.median) ? 
                'Dataset 1 más simétrico' : 'Dataset 2 más simétrico'
        },
        spread: {
            rangeDifference: stats1.range - stats2.range,
            varianceDifference: stats1.variance - stats2.variance,
            interpretation: stats1.variance < stats2.variance ? 
                'Dataset 1 más consistente' : 'Dataset 2 más consistente'
        },
        shape: {
            skewnessDifference: stats1.skewness - stats2.skewness,
            kurtosisDifference: stats1.kurtosis - stats2.kurtosis,
            interpretation: generateDistributionShapeInterpretation(stats1, stats2)
        }
    };
}

// Interpretar la forma de la distribución
function generateDistributionShapeInterpretation(stats1, stats2) {
    const interpretations = [];
    
    // Análisis de asimetría
    if (Math.abs(stats1.skewness) < 0.5 && Math.abs(stats2.skewness) > 1) {
        interpretations.push('Dataset 1 tiene distribución más simétrica');
    } else if (Math.abs(stats2.skewness) < 0.5 && Math.abs(stats1.skewness) > 1) {
        interpretations.push('Dataset 2 tiene distribución más simétrica');
    }
    
    // Análisis de curtosis
    if (stats1.kurtosis > 0 && stats2.kurtosis < 0) {
        interpretations.push('Dataset 1 tiene más valores extremos (leptocúrtica)');
    } else if (stats2.kurtosis > 0 && stats1.kurtosis < 0) {
        interpretations.push('Dataset 2 tiene más valores extremos (leptocúrtica)');
    }
    
    return interpretations.length > 0 ? interpretations.join('. ') : 'Distribuciones similares';
}

// Prueba de significancia estadística (t-test simplificado)
function performSignificanceTest(data1, data2) {
    const stats1 = calculateAdvancedStats(data1);
    const stats2 = calculateAdvancedStats(data2);
    const n1 = data1.length;
    const n2 = data2.length;
    
    // Calcular error estándar de la diferencia
    const se = Math.sqrt((stats1.variance / n1) + (stats2.variance / n2));
    
    if (se === 0) {
        return { significant: false, tStat: 0, interpretation: 'No hay variabilidad para evaluar' };
    }
    
    // Estadístico t
    const tStat = (stats1.mean - stats2.mean) / se;
    
    // Interpretación simplificada (sin tabla de t)
    const significant = Math.abs(tStat) > 2; // Aproximadamente p < 0.05
    
    return {
        significant,
        tStat,
        confidenceLevel: significant ? 'alta' : 'baja',
        interpretation: significant ? 
            'La diferencia es estadísticamente significativa' : 
            'La diferencia no es estadísticamente significativa'
    };
}

// Comparar patrones entre datasets
function comparePatterns(data1, data2) {
    return {
        volatility1: calculateVolatility(data1),
        volatility2: calculateVolatility(data2),
        peaks1: findPeaks(data1),
        peaks2: findPeaks(data2),
        cycles1: detectCycles(data1),
        cycles2: detectCycles(data2),
        interpretation: generatePatternInterpretation(data1, data2)
    };
}

// Encontrar picos en una serie
function findPeaks(data) {
    const peaks = [];
    for (let i = 1; i < data.length - 1; i++) {
        if (data[i] > data[i-1] && data[i] > data[i+1]) {
            peaks.push({ index: i, value: data[i] });
        }
    }
    return peaks;
}

// Generar interpretación de patrones
function generatePatternInterpretation(data1, data2) {
    const vol1 = calculateVolatility(data1);
    const vol2 = calculateVolatility(data2);
    const peaks1 = findPeaks(data1);
    const peaks2 = findPeaks(data2);
    
    const interpretations = [];
    
    if (vol1 > vol2 * 1.2) {
        interpretations.push('Dataset 1 muestra mayor volatilidad');
    } else if (vol2 > vol1 * 1.2) {
        interpretations.push('Dataset 2 muestra mayor volatilidad');
    } else {
        interpretations.push('Ambos datasets tienen volatilidad similar');
    }
    
    if (peaks1.length > peaks2.length * 1.5) {
        interpretations.push('Dataset 1 tiene más picos de actividad');
    } else if (peaks2.length > peaks1.length * 1.5) {
        interpretations.push('Dataset 2 tiene más picos de actividad');
    }
    
    return interpretations.join('. ');
}

// Calcular consistencia de un dataset
function calculateConsistency(data) {
    const mean = data.reduce((a, b) => a + b, 0) / data.length;
    const coefficientOfVariation = mean !== 0 ? 
        (Math.sqrt(data.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / data.length) / mean) : 0;
    
    return {
        coefficientOfVariation,
        interpretation: coefficientOfVariation < 0.3 ? 'alta' : 
                       coefficientOfVariation < 0.6 ? 'media' : 'baja'
    };
}

// Generar interpretación avanzada de las diferencias
function generateAdvancedInterpretation(differences, analysis) {
    const interpretations = [];
    
    // Análisis de cambio total
    if (Math.abs(analysis.totalPercentageChange) > 10) {
        const direction = analysis.totalPercentageChange > 0 ? 'incremento' : 'reducción';
        interpretations.push(`Se observa un ${direction} significativo del ${Math.abs(analysis.totalPercentageChange).toFixed(1)}% en el volumen total de tickets.`);
    } else {
        interpretations.push('El volumen total de tickets se mantiene relativamente estable entre períodos.');
    }
    
    // Análisis de volatilidad
    const volDiff = analysis.volatilityChange.difference;
    if (Math.abs(volDiff) > 0.1) {
        const period = volDiff > 0 ? 'primer' : 'segundo';
        interpretations.push(`El ${period} período muestra mayor volatilidad (${Math.abs(volDiff * 100).toFixed(1)}% más variable).`);
    }
    
    // Análisis de correlación
    if (analysis.correlation !== null) {
        if (Math.abs(analysis.correlation) > 0.7) {
            interpretations.push(`Existe una correlación ${analysis.correlation > 0 ? 'positiva' : 'negativa'} fuerte (${(analysis.correlation * 100).toFixed(1)}%) entre ambos períodos.`);
        } else if (Math.abs(analysis.correlation) > 0.3) {
            interpretations.push(`Se detecta una correlación moderada entre ambos períodos.`);
        } else {
            interpretations.push('Los patrones entre períodos muestran poca correlación.');
        }
    }
    
    // Análisis de tendencias
    const trend1 = analysis.trend1;
    const trend2 = analysis.trend2;
    if (trend1.direction !== trend2.direction) {
        interpretations.push(`Los períodos muestran tendencias opuestas: Período 1 ${trend1.direction === 'increasing' ? 'creciente' : trend1.direction === 'decreasing' ? 'decreciente' : 'estable'}, Período 2 ${trend2.direction === 'increasing' ? 'creciente' : trend2.direction === 'decreasing' ? 'decreciente' : 'estable'}.`);
    }
    
    // Análisis de significancia estadística
    if (analysis.significanceTest.significant) {
        interpretations.push(`La diferencia entre períodos es estadísticamente significativa (t = ${analysis.significanceTest.tStat.toFixed(2)}).`);
    } else {
        interpretations.push('Las diferencias observadas no son estadísticamente significativas y podrían deberse a variación natural.');
    }
    
    // Análisis de distribución
    const distrib = analysis.distribution;
    interpretations.push(distrib.centralTendency.interpretation);
    interpretations.push(distrib.spread.interpretation);
    
    // Análisis de patrones
    interpretations.push(analysis.patterns.interpretation);
    
    return interpretations;
}

// Generar recomendaciones basadas en la comparación
function generateComparisonRecommendations(differences, analysis) {
    const recommendations = [];
    
    // Recomendaciones basadas en cambio de volumen
    if (analysis.totalPercentageChange > 20) {
        recommendations.push('💡 Incremento significativo detectado: Considere aumentar la capacidad del equipo de soporte y revisar los procesos de escalamiento.');
    } else if (analysis.totalPercentageChange < -20) {
        recommendations.push('📉 Reducción significativa: Evalúe si es resultado de mejoras en el proceso o si indica problemas subyacentes.');
    }
    
    // Recomendaciones basadas en volatilidad
    if (analysis.volatilityChange.difference > 0.2) {
        recommendations.push('⚡ Alta volatilidad en el primer período: Implemente estrategias de gestión de carga variable y sistemas de alerta temprana.');
    } else if (analysis.volatilityChange.difference < -0.2) {
        recommendations.push('📊 Mayor estabilidad en el primer período: Identifique y replique las mejores prácticas implementadas.');
    }
    
    // Recomendaciones basadas en correlación
    if (analysis.correlation !== null && Math.abs(analysis.correlation) < 0.3) {
        recommendations.push('🔄 Baja correlación entre períodos: Investigue cambios operacionales o externos que puedan explicar patrones diferentes.');
    }
    
    // Recomendaciones basadas en tendencias
    const trend1 = analysis.trend1;
    const trend2 = analysis.trend2;
    if (trend1.direction === 'increasing' && trend2.direction === 'increasing') {
        recommendations.push('📈 Tendencia creciente sostenida: Planifique expansión de recursos y optimización de procesos a largo plazo.');
    } else if (trend1.direction === 'decreasing' && trend2.direction === 'increasing') {
        recommendations.push('🔄 Cambio de tendencia: Analice qué factores causaron la reversión para mantener la mejora.');
    }
    
    // Recomendaciones basadas en consistencia
    const consist1 = analysis.consistency.dataset1;
    const consist2 = analysis.consistency.dataset2;
    if (consist1.interpretation === 'baja' && consist2.interpretation === 'alta') {
        recommendations.push('🎯 Mejora en consistencia: Documente y estandarice las prácticas que llevaron a mayor estabilidad.');
    } else if (consist1.interpretation === 'alta' && consist2.interpretation === 'baja') {
        recommendations.push('⚠️ Pérdida de consistencia: Revise cambios en procesos o personal que puedan estar afectando la estabilidad.');
    }
    
    // Recomendaciones basadas en picos
    const peaks1 = analysis.patterns.peaks1.length;
    const peaks2 = analysis.patterns.peaks2.length;
    if (peaks2 > peaks1 * 1.5) {
        recommendations.push('🏔️ Aumento en picos de actividad: Desarrolle protocolos específicos para gestión de cargas máximas.');
    }
    
    if (recommendations.length === 0) {
        recommendations.push('✅ Los períodos muestran patrones similares. Continúe monitoreando para detectar cambios tempranos.');
    }
    
    return recommendations;
}

// Función para actualizar el análisis de diferencias en la interfaz (mejorada)
function updateComparisonAnalysis(analysis) {
    const analysisContainer = document.getElementById('comparison-analysis');
    if (!analysisContainer) {
        console.error('No se encontró el contenedor de análisis de comparación');
        return;
    }

    // Verificar si hay error en el análisis
    if (analysis.error) {
        analysisContainer.innerHTML = `
            <div class="alert alert-warning mt-4">
                <h5>⚠️ Análisis no disponible</h5>
                <p>${analysis.error}</p>
            </div>
        `;
        return;
    }

    // Crear contenido HTML detallado
    let analysisHTML = `
        <div class="card mt-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">📊 Análisis Comparativo Avanzado</h5>
                <small class="text-muted">Sincronización: ${getComparisonSyncKey() ? 'Activa' : 'Independiente'}</small>
            </div>
            <div class="card-body">
    `;

    // Sección de estadísticas básicas
    if (analysis.differences && analysis.differences.dataset1 && analysis.differences.dataset2) {
        const stats1 = analysis.differences.dataset1;
        const stats2 = analysis.differences.dataset2;
        
        analysisHTML += `
            <div class="row mb-4">
                <div class="col-md-6">
                    <div class="card border-primary">
                        <div class="card-header bg-primary text-white">
                            <h6 class="mb-0">📈 Período 1</h6>
                        </div>
                        <div class="card-body">
                            <div class="row text-center">
                                <div class="col-6"><strong>Total:</strong><br>${stats1.total}</div>
                                <div class="col-6"><strong>Promedio:</strong><br>${stats1.mean.toFixed(1)}</div>
                                <div class="col-6"><strong>Mediana:</strong><br>${stats1.median.toFixed(1)}</div>
                                <div class="col-6"><strong>Rango:</strong><br>${stats1.min}-${stats1.max}</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card border-success">
                        <div class="card-header bg-success text-white">
                            <h6 class="mb-0">📉 Período 2</h6>
                        </div>
                        <div class="card-body">
                            <div class="row text-center">
                                <div class="col-6"><strong>Total:</strong><br>${stats2.total}</div>
                                <div class="col-6"><strong>Promedio:</strong><br>${stats2.mean.toFixed(1)}</div>
                                <div class="col-6"><strong>Mediana:</strong><br>${stats2.median.toFixed(1)}</div>
                                <div class="col-6"><strong>Rango:</strong><br>${stats2.min}-${stats2.max}</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    // Sección de interpretaciones principales
    if (analysis.interpretation && analysis.interpretation.length > 0) {
        analysisHTML += `
            <div class="mb-4">
                <h6 class="text-primary">🔍 Interpretación</h6>
                <ul class="list-group list-group-flush">
                    ${analysis.interpretation.map(interpretation => 
                        `<li class="list-group-item border-0 px-0">${interpretation}</li>`
                    ).join('')}
                </ul>
            </div>
        `;
    }

    // Sección de análisis avanzado
    if (analysis.analysis) {
        const adv = analysis.analysis;
        
        // Correlación
        if (adv.correlation !== null) {
            const corrStrength = Math.abs(adv.correlation) > 0.7 ? 'Fuerte' : 
                                Math.abs(adv.correlation) > 0.4 ? 'Moderada' : 'Débil';
            const corrDirection = adv.correlation > 0 ? 'Positiva' : 'Negativa';
            
            analysisHTML += `
                <div class="row mb-3">
                    <div class="col-md-4">
                        <div class="card border-info">
                            <div class="card-body text-center">
                                <h6 class="card-title">🔗 Correlación</h6>
                                <h4 class="text-info">${(adv.correlation * 100).toFixed(1)}%</h4>
                                <small>${corrDirection} - ${corrStrength}</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card border-warning">
                            <div class="card-body text-center">
                                <h6 class="card-title">📊 Cambio Total</h6>
                                <h4 class="text-warning">${adv.totalPercentageChange > 0 ? '+' : ''}${adv.totalPercentageChange.toFixed(1)}%</h4>
                                <small>${Math.abs(adv.totalPercentageChange) > 10 ? 'Significativo' : 'Moderado'}</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card border-secondary">
                            <div class="card-body text-center">
                                <h6 class="card-title">⚡ Volatilidad</h6>
                                <h4 class="text-secondary">${(Math.abs(adv.volatilityChange.difference) * 100).toFixed(1)}%</h4>
                                <small>Diferencia de variabilidad</small>
                            </div>
                        </div>
                    </div>
                </div>
            `;
        }

        // Análisis de tendencias
        if (adv.trend1 && adv.trend2) {
            const getTrendIcon = (direction) => {
                switch(direction) {
                    case 'increasing': return '📈';
                    case 'decreasing': return '📉';
                    default: return '➡️';
                }
            };

            analysisHTML += `
                <div class="mb-3">
                    <h6 class="text-primary">📈 Análisis de Tendencias</h6>
                    <div class="row">
                        <div class="col-md-6">
                            <small><strong>Período 1:</strong> ${getTrendIcon(adv.trend1.direction)} ${adv.trend1.direction === 'increasing' ? 'Creciente' : adv.trend1.direction === 'decreasing' ? 'Decreciente' : 'Estable'} (${(adv.trend1.strength * 100).toFixed(1)}% confianza)</small>
                        </div>
                        <div class="col-md-6">
                            <small><strong>Período 2:</strong> ${getTrendIcon(adv.trend2.direction)} ${adv.trend2.direction === 'increasing' ? 'Creciente' : adv.trend2.direction === 'decreasing' ? 'Decreciente' : 'Estable'} (${(adv.trend2.strength * 100).toFixed(1)}% confianza)</small>
                        </div>
                    </div>
                </div>
            `;
        }

        // Prueba de significancia estadística
        if (adv.significanceTest) {
            const test = adv.significanceTest;
            analysisHTML += `
                <div class="mb-3">
                    <h6 class="text-primary">🧮 Significancia Estadística</h6>
                    <div class="alert ${test.significant ? 'alert-success' : 'alert-secondary'} py-2">
                        <small>
                            <strong>T-estadístico:</strong> ${test.tStat.toFixed(3)} | 
                            <strong>Confianza:</strong> ${test.confidenceLevel} | 
                            <strong>Resultado:</strong> ${test.interpretation}
                        </small>
                    </div>
                </div>
            `;
        }

        // Análisis de consistencia
        if (adv.consistency) {
            const consist1 = adv.consistency.dataset1;
            const consist2 = adv.consistency.dataset2;
            
            analysisHTML += `
                <div class="mb-3">
                    <h6 class="text-primary">🎯 Consistencia</h6>
                    <div class="row">
                        <div class="col-md-6">
                            <small><strong>Período 1:</strong> ${consist1.interpretation} (CV: ${(consist1.coefficientOfVariation * 100).toFixed(1)}%)</small>
                        </div>
                        <div class="col-md-6">
                            <small><strong>Período 2:</strong> ${consist2.interpretation} (CV: ${(consist2.coefficientOfVariation * 100).toFixed(1)}%)</small>
                        </div>
                    </div>
                </div>
            `;
        }
    }

    // Sección de recomendaciones
    if (analysis.recommendations && analysis.recommendations.length > 0) {
        analysisHTML += `
            <div class="mb-3">
                <h6 class="text-success">💡 Recomendaciones</h6>
                <div class="list-group list-group-flush">
                    ${analysis.recommendations.map(rec => 
                        `<div class="list-group-item border-0 px-0 py-2">
                            <small>${rec}</small>
                        </div>`
                    ).join('')}
                </div>
            </div>
        `;
    }

    analysisHTML += `
            </div>
        </div>
    `;

    analysisContainer.innerHTML = analysisHTML;
}

// Funciones para mostrar/ocultar indicador de carga
function showLoadingIndicator() {
    const indicator = document.getElementById('loading-indicator');
    if (indicator) {
        indicator.classList.remove('d-none');
        indicator.style.display = 'flex';
    }
}

function hideLoadingIndicator() {
    const indicator = document.getElementById('loading-indicator');
    if (indicator) {
        indicator.classList.add('d-none');
        indicator.style.display = 'none';
    }
}

// Obtener tickets de Zendesk con paginación optimizada y cacheo
async function getTickets(forceRefresh = false) {
    try {
        // Verificar cache si no es un refresh forzado
        if (!forceRefresh && ticketsCache.data.length > 0 && ticketsCache.lastFetch) {
            const cacheAge = Date.now() - ticketsCache.lastFetch;
            if (cacheAge < ticketsCache.cacheExpiry) {
                console.log('Usando tickets del cache:', ticketsCache.data.length);
                return ticketsCache.data;
            }
        }

        // Evitar múltiples llamadas simultáneas
        if (isFetchingTickets) {
            console.log('Ya se están obteniendo tickets, esperando...');
            return ticketsCache.data; // Retornar cache mientras se actualiza
        }

        isFetchingTickets = true;
        
        // Mostrar indicador de carga solo en la primera carga o refresh forzado
        if (ticketsCache.data.length === 0 || forceRefresh) {
            showLoadingIndicator();
        }
        
        console.log('Obteniendo tickets de Zendesk con optimización de rendimiento...');

        let allTickets = [];
        const maxPages = 15; // Reducido para velocidad (15,000 tickets máximo)
        const perPage = 1000; // Usar máximo per_page permitido por Zendesk
        
        // Estrategia optimizada: paginación paralela
        console.log('Iniciando carga optimizada con paginación paralela...');
        
        // Fase 1: Cargar primeras páginas en paralelo (mucho más rápido)
        const initialPagesToLoad = Math.min(8, maxPages); // 8 páginas en paralelo = 8000 tickets
        const initialPromises = [];
        
        for (let page = 1; page <= initialPagesToLoad; page++) {
            initialPromises.push(
                client.request({
                    url: `/api/v2/tickets.json?per_page=${perPage}&page=${page}`,
                    type: 'GET',
                    contentType: 'application/json',
                    headers: {
                        'Accept': 'application/json'
                    }
                }).catch(error => {
                    console.warn(`Error en página paralela ${page}:`, error);
                    return { tickets: [] }; // Estructura vacía en caso de error
                })
            );
        }
        
        try {
            console.log(`Cargando páginas 1-${initialPagesToLoad} en paralelo (${initialPagesToLoad * perPage} tickets máximo)...`);
            const startTime = performance.now();
            
            const initialResponses = await Promise.all(initialPromises);
            
            const parallelTime = performance.now();
            console.log(`Carga paralela completada en ${(parallelTime - startTime).toFixed(2)}ms`);
            
            let hasMorePages = false;
            let pagesWithData = 0;
            
            initialResponses.forEach((response, index) => {
                if (response.tickets && Array.isArray(response.tickets) && response.tickets.length > 0) {
                    allTickets = allTickets.concat(response.tickets);
                    pagesWithData++;
                    console.log(`Página paralela ${index + 1}: ${response.tickets.length} tickets`);
                    
                    // Si esta página tiene el máximo de tickets, probablemente hay más páginas
                    if (response.tickets.length === perPage) {
                        hasMorePages = true;
                    }
                }
            });
            
            console.log(`Carga paralela: ${allTickets.length} tickets en ${pagesWithData} páginas`);
            
            // Fase 2: Solo cargar más si realmente necesitamos y hay indicios de más datos
            if (hasMorePages && allTickets.length >= (initialPagesToLoad * perPage * 0.8)) {
                console.log('Detectadas páginas adicionales, cargando secuencialmente...');
                let pageCount = initialPagesToLoad + 1;
                const maxAdditionalPages = 7; // Máximo 7 páginas adicionales
                
                while (pageCount <= maxPages && pageCount <= (initialPagesToLoad + maxAdditionalPages)) {
                    try {
                const response = await client.request({
                            url: `/api/v2/tickets.json?per_page=${perPage}&page=${pageCount}`,
                    type: 'GET',
                    contentType: 'application/json',
                    headers: {
                        'Accept': 'application/json'
                    }
                });

                        if (response.tickets && Array.isArray(response.tickets) && response.tickets.length > 0) {
                    allTickets = allTickets.concat(response.tickets);
                            console.log(`Página adicional ${pageCount}: ${response.tickets.length} tickets. Total: ${allTickets.length}`);
                            
                            // Si no está completa, no hay más páginas
                            if (response.tickets.length < perPage) {
                                console.log('Última página detectada');
                                break;
                            }
                        } else {
                            console.log('No hay más datos disponibles');
                            break;
                        }

                pageCount++;

                        // Pausa mínima para no sobrecargar la API
                        await new Promise(resolve => setTimeout(resolve, 30));

                    } catch (pageError) {
                        console.error(`Error en página adicional ${pageCount}:`, pageError);
                        break;
                    }
                }
            }
            
            const totalTime = performance.now();
            console.log(`Carga total optimizada completada en ${(totalTime - startTime).toFixed(2)}ms`);
            
        } catch (parallelError) {
            console.error('Error en carga paralela, usando fallback secuencial:', parallelError);
            
            // Fallback: carga secuencial más eficiente
            allTickets = []; // Limpiar tickets parciales
            let pageCount = 1;
            const fallbackMaxPages = 10; // Límite reducido para fallback
            
            while (pageCount <= fallbackMaxPages) {
                try {
                    console.log(`Fallback: cargando página ${pageCount}...`);
                    const response = await client.request({
                        url: `/api/v2/tickets.json?per_page=${perPage}&page=${pageCount}`,
                        type: 'GET'
                    });

                    if (response.tickets && Array.isArray(response.tickets)) {
                        allTickets = allTickets.concat(response.tickets);
                        console.log(`Página fallback ${pageCount}: ${response.tickets.length} tickets`);
                        
                        if (response.tickets.length < perPage) {
                            break; // Última página
                        }
                    } else {
                        break;
                    }

                    pageCount++;
                    await new Promise(resolve => setTimeout(resolve, 50));

            } catch (pageError) {
                    console.error(`Error en página fallback ${pageCount}:`, pageError);
                    break;
                }
            }
        }

        console.log(`🚀 Total de tickets obtenidos con optimización: ${allTickets.length}`);

        // Actualizar cache y construir índices optimizados
        ticketsCache.data = allTickets;
        ticketsCache.lastFetch = Date.now();
        
        // Construir índices para búsquedas rápidas
        buildOptimizedIndices(allTickets);

        return allTickets;

    } catch (error) {
        console.error('Error al obtener tickets:', error);
        // En caso de error, retornar cache si existe
        return ticketsCache.data || [];
    } finally {
        isFetchingTickets = false;
        hideLoadingIndicator();
    }
}

// Función de debounce para evitar múltiples llamadas rápidas
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Procesar tickets en lotes para evitar bloquear la UI
function processTicketsInBatches(tickets, processorFunction, batchSize = 1000) {
    return new Promise((resolve) => {
        const results = [];
        let currentIndex = 0;

        function processBatch() {
            const batch = tickets.slice(currentIndex, currentIndex + batchSize);
            
            if (batch.length === 0) {
                resolve(results);
                return;
            }

            // Procesar lote actual
            const batchResults = processorFunction(batch);
            results.push(...batchResults);

            currentIndex += batchSize;

            // Usar setTimeout para no bloquear la UI
            setTimeout(processBatch, 0);
        }

        processBatch();
    });
}

// Actualizar datos del gráfico principal - optimizado
async function updateTicketsData() {
    try {
        console.log('Iniciando actualización de datos optimizada...');
        const startTime = performance.now();
        
        const startDate = document.getElementById('startDate').value;
        const endDate = document.getElementById('endDate').value;
        const scale = document.getElementById('scaleDashboard').value;
        
        // Mostrar indicador de carga
        const chartContainer = document.getElementById('realtimeTrend');
        if (chartContainer) {
            chartContainer.style.opacity = '0.5';
        }
        
        const tickets = await getTickets();
        console.log('Tickets obtenidos:', tickets.length);
        
        // Usar filtrado optimizado con índices
        const currentTickets = getFilteredTicketsOptimized(startDate, endDate);
        console.log('Tickets filtrados:', currentTickets.length);
        
        // Usar índices pre-calculados para agregación rápida
        const aggregatedData = getAggregatedDataOptimized(currentTickets, scale, startDate, endDate);

        const timestamps = Object.keys(aggregatedData).sort().map(key => {
            const date = parseKeyToDate(key, scale);
            return date.getTime() / 1000;
        });
        
        const values = Object.keys(aggregatedData).sort().map(key => aggregatedData[key]);
        const superiorLimitValues = new Array(values.length).fill(12);

        if (ticketsPlot) {
            const updateStart = performance.now();
            console.log(`Actualizando gráfico con ${values.length} puntos de datos...`);
            ticketsPlot.setData([timestamps, values, superiorLimitValues]);
            
            // Actualizar el título del gráfico
            let title = "";
            switch(scale) {
                case 'hourly': title = "Tickets por Hora"; break;
                case 'daily': title = "Tickets por Día"; break;
                case 'monthly': title = "Tickets por Mes"; break;
                case 'yearly': title = "Tickets por Año"; break;
            }
            if (ticketsPlot.setTitle) {
                ticketsPlot.setTitle(title);
            }
            
            const updateEnd = performance.now();
            console.log(`Gráfico actualizado en ${(updateEnd - updateStart).toFixed(2)}ms`);
        }

        // Restaurar opacidad
        if (chartContainer) {
            chartContainer.style.opacity = '1';
        }

        const endTime = performance.now();
        console.log(`Actualización completa en ${(endTime - startTime).toFixed(2)}ms`);
        
    } catch (error) {
        console.error('Error al actualizar datos del gráfico:', error);
        // Restaurar opacidad en caso de error
        const chartContainer = document.getElementById('realtimeTrend');
        if (chartContainer) {
            chartContainer.style.opacity = '1';
        }
    }
}

// Función optimizada para agregación de datos usando índices
function getAggregatedDataOptimized(tickets, scale, startDate, endDate) {
    try {
    const aggregatedData = {};
    const startDateObj = new Date(startDate);
    const endDateObj = new Date(endDate + 'T23:59:59');
        
        // Verificar que los índices existan y estén inicializados
        if (!ticketsCache.indices || typeof ticketsCache.indices !== 'object') {
            console.warn('Índices no disponibles, usando método tradicional');
            return getAggregatedDataTraditional(tickets, scale);
        }
    
    // Usar el índice apropiado según la escala
    let relevantIndex;
    switch(scale) {
        case 'hourly':
            relevantIndex = ticketsCache.indices.byHour;
            break;
        case 'daily':
            relevantIndex = ticketsCache.indices.byDate;
            break;
        case 'monthly':
            relevantIndex = ticketsCache.indices.byMonth;
            break;
        case 'yearly':
            relevantIndex = ticketsCache.indices.byYear;
            break;
        default:
            // Fallback al método tradicional
                return getAggregatedDataTraditional(tickets, scale);
        }
        
        // Verificar que el índice específico existe
        if (!relevantIndex || typeof relevantIndex.get !== 'function') {
            console.warn(`Índice para escala '${scale}' no disponible, usando método tradicional`);
            return getAggregatedDataTraditional(tickets, scale);
    }
    
    // Generar todas las claves posibles en el rango de fechas
    const keys = generateDateKeys(startDateObj, endDateObj, scale);
    
    keys.forEach(key => {
            try {
        const ticketsForKey = relevantIndex.get(key);
                if (ticketsForKey && Array.isArray(ticketsForKey)) {
            // Filtrar por rango de fechas específico si es necesario
            const filteredTickets = ticketsForKey.filter(ticket => {
                        try {
                const ticketDate = new Date(ticket.created_at);
                return ticketDate >= startDateObj && ticketDate <= endDateObj;
                        } catch (dateError) {
                            console.warn('Error procesando fecha de ticket:', ticket);
                            return false;
                        }
            });
            aggregatedData[key] = filteredTickets.length;
        } else {
                    aggregatedData[key] = 0;
                }
            } catch (keyError) {
                console.warn(`Error procesando clave ${key}:`, keyError);
            aggregatedData[key] = 0;
        }
    });
    
    return aggregatedData;
        
    } catch (error) {
        console.error('Error en getAggregatedDataOptimized:', error);
        // Fallback completo al método tradicional
        return getAggregatedDataTraditional(tickets, scale);
    }
}

// Generar claves de fecha para un rango específico
function generateDateKeys(startDate, endDate, scale) {
    const keys = [];
    const current = new Date(startDate);
    
    switch(scale) {
        case 'hourly':
            while (current <= endDate) {
                keys.push(current.toISOString().slice(0, 13));
                current.setHours(current.getHours() + 1);
            }
            break;
        case 'daily':
            while (current <= endDate) {
                keys.push(current.toISOString().split('T')[0]);
                current.setDate(current.getDate() + 1);
            }
            break;
        case 'monthly':
            current.setDate(1); // Primer día del mes
            while (current <= endDate) {
                keys.push(current.toISOString().slice(0, 7));
                current.setMonth(current.getMonth() + 1);
            }
            break;
        case 'yearly':
            while (current.getFullYear() <= endDate.getFullYear()) {
                keys.push(current.getFullYear().toString());
                current.setFullYear(current.getFullYear() + 1);
            }
            break;
    }
    
    return keys;
}

// Convertir clave de fecha a objeto Date
function parseKeyToDate(key, scale) {
    switch(scale) {
        case 'hourly':
            return new Date(key + ':00:00');
        case 'daily':
            return new Date(key + 'T00:00:00');
        case 'monthly':
            return new Date(key + '-01T00:00:00');
        case 'yearly':
            return new Date(key + '-01-01T00:00:00');
        default:
            return new Date(key);
    }
}

// Método tradicional como fallback
function getAggregatedDataTraditional(tickets, scale) {
    try {
    const aggregatedData = {};
    
        // Validar entrada
        if (!Array.isArray(tickets)) {
            console.warn('Tickets no es un array en método tradicional');
            return {};
        }
        
        tickets.forEach((ticket, index) => {
            try {
                if (!ticket || !ticket.created_at) {
                    console.warn(`Ticket inválido en índice ${index}:`, ticket);
                    return;
                }
                
        const date = new Date(ticket.created_at);
                if (isNaN(date.getTime())) {
                    console.warn(`Fecha inválida en ticket ${ticket.id}:`, ticket.created_at);
                    return;
                }
                
        let key;
        
        switch(scale) {
            case 'hourly':
                key = date.toISOString().slice(0, 13);
                break;
            case 'daily':
                key = date.toISOString().split('T')[0];
                break;
            case 'monthly':
                key = date.toISOString().slice(0, 7);
                break;
            case 'yearly':
                key = date.getFullYear().toString();
                break;
                    default:
                        console.warn(`Escala desconocida: ${scale}`);
                        key = date.toISOString().split('T')[0]; // Default a daily
                        break;
        }
        
                if (key) {
        aggregatedData[key] = (aggregatedData[key] || 0) + 1;
                }
                
            } catch (ticketError) {
                console.error(`Error procesando ticket en método tradicional:`, ticketError, ticket);
            }
    });
    
    return aggregatedData;
        
    } catch (error) {
        console.error('Error en getAggregatedDataTraditional:', error);
        return {}; // Retornar objeto vacío en caso de error total
    }
}

// Iniciar actualizaciones periódicas optimizadas
function startPeriodicUpdates() {
    // Actualizar inmediatamente con datos del cache si existen
    if (ticketsCache.data.length > 0) {
        debouncedUpdateTicketsData();
    } else {
        updateTicketsData(); // Primera carga completa
    }
    
    if (updateIntervalId) {
        clearInterval(updateIntervalId);
    }
    
    // Aumentar el intervalo a 10 minutos para reducir carga
    updateIntervalId = setInterval(() => {
        // Solo actualizar si la página está visible
        if (!document.hidden) {
            // Forzar refresh cada 10 minutos para obtener datos frescos
            getTickets(true).then(() => {
                debouncedUpdateTicketsData();
            });
        }
    }, 600000); // 10 minutos
}

// Optimizar la función de análisis de tickets
function analyzeTickets(tickets) {
    // Si hay muchos tickets, usar una muestra para métricas básicas
    const sampleSize = Math.min(tickets.length, 5000);
    const sample = tickets.length > sampleSize ? 
        tickets.slice(0, sampleSize) : tickets;
    
    const today = new Date().toISOString().split('T')[0];
    const totalTickets = tickets.length; // Usar el total real
    
    // Usar muestra para cálculos más complejos
    const ticketsToday = sample.filter(t => t.created_at.startsWith(today)).length;
    const pendingTickets = sample.filter(t => t.status === 'pending').length;
    const resolvedTickets = sample.filter(t => t.status === 'solved').length;
    
    // Extrapolar los resultados si se usó una muestra
    const scaleFactor = tickets.length / sample.length;
    const adjustedTicketsToday = Math.round(ticketsToday * scaleFactor);
    const adjustedPendingTickets = Math.round(pendingTickets * scaleFactor);
    const adjustedResolvedTickets = Math.round(resolvedTickets * scaleFactor);
    
    const resolutionRate = totalTickets > 0 ? 
        (adjustedResolvedTickets / totalTickets * 100).toFixed(1) : 0;

    return {
        totalTickets,
        ticketsToday: adjustedTicketsToday,
        pendingTickets: adjustedPendingTickets,
        resolutionRate
    };
}

// Actualizar el dashboard
async function updateDashboard() {
    try {
        const startDate = document.getElementById('startDate').value;
        const endDate = document.getElementById('endDate').value;
        
        const tickets = await getTickets();
        const filteredTickets = tickets.filter(ticket => {
            const ticketDate = new Date(ticket.created_at);
            return ticketDate >= new Date(startDate) && ticketDate <= new Date(endDate + 'T23:59:59');
        });
        
        const data = analyzeTickets(filteredTickets);
        updateMetrics(data);
    } catch (error) {
        console.error('Error al actualizar el dashboard:', error);
    }
}

// Actualizar métricas
function updateMetrics(data) {
    document.getElementById('total-tickets').textContent = data.totalTickets;
    document.getElementById('tickets-hoy').textContent = data.ticketsToday;
    document.getElementById('tickets-pendientes').textContent = data.pendingTickets;
    document.getElementById('tasa-resolucion').textContent = `${data.resolutionRate}%`;
}

// Inicializar gráficos de la página detallada
function initDetailedPlots() {
    console.log('Iniciando inicialización de gráficos detallados...');
    const dailyContainer = document.getElementById('dailyTrendDetailed');
    const monthlyContainer = document.getElementById('monthlyTrendDetailed');

    // Destruir instancias de gráficos existentes si las hay
    if (dailyPlotDetailed) {
        dailyPlotDetailed.destroy();
        dailyPlotDetailed = null;
    }
    if (monthlyPlotDetailed) {
        monthlyPlotDetailed.destroy();
        monthlyPlotDetailed = null;
    }

    console.log('Contenedores encontrados (Detallado):', {
        daily: !!dailyContainer,
        monthly: !!monthlyContainer
    });

    if (!dailyContainer || !monthlyContainer) {
        console.error('No se encontraron todos los contenedores necesarios para gráficos detallados.');
        return;
    }

    console.log('dailyContainer offsetWidth:', dailyContainer.offsetWidth);
    console.log('monthlyContainer offsetWidth:', monthlyContainer.offsetWidth);

    const getBarColor = (value, maxValue) => {
        // Asegurarse de que maxValue sea un número positivo finito para evitar divisiones por cero o NaN
        if (!Number.isFinite(maxValue) || maxValue <= 0) {
            maxValue = 1; // Usar 1 como valor por defecto si maxValue no es válido
        }

        const percentage = value / maxValue;
        if (percentage < 0.33) return "#2196F3"; // Azul para valores bajos (0-33%)
        if (percentage < 0.66) return "#4CAF50"; // Verde para valores medios (33-66%)
        return "#F44336"; // Rojo para valores altos (66-100%)
    };

    const baseOpts = {
        width: dailyContainer.offsetWidth, // Usar ancho del dailyContainer
        height: 300,
        cursor: {
            show: true,
            sync: {
                key: "detailedSync"
            }
        },
        scales: {
            x: {
                time: true,
            },
            y: {
                auto: true,
            }
        },
        axes: [
            {
                stroke: "#03363d",
                grid: { show: true, stroke: "#d8dcde" },
                ticks: { show: true, stroke: "#03363d" },
                font: "12px Arial",
                values: (self, splits) => splits.map(s => {
                    const date = new Date(s * 1000);
                    return new Intl.DateTimeFormat('es-EC', {
                        month: 'short',
                        day: 'numeric',
                        timeZone: 'America/Guayaquil'
                    }).format(date);
                }),
            },
            {
                stroke: "#03363d",
                grid: { show: true, stroke: "#d8dcde" },
                ticks: { show: true, stroke: "#03363d" },
                font: "12px Arial",
            }
        ]
    };

    try {
        console.log('Creando gráfico diario detallado...');
        const dailyOpts = {
            ...baseOpts,
            title: "Tickets por Día (Detallado)",
            series: [
                {},
                {
                    stroke: (u, seriesIdx, dataIdx) => {
                        // Comprobación robusta para asegurar que u y u.data existan y que seriesData sea un array
                        if (!u || !u.data || !Array.isArray(u.data[seriesIdx])) {
                            return "#CCCCCC"; // Color por defecto si los datos no son válidos
                        }
                        const seriesData = u.data[seriesIdx];
                        if (dataIdx < 0 || dataIdx >= seriesData.length) {
                            return "#CCCCCC"; 
                        }
                        const value = seriesData[dataIdx];
                        const maxValue = seriesData.length > 0 ? Math.max(...seriesData) : 1; 
                        return getBarColor(value, maxValue);
                    },
                    width: 2,
                    fill: (u, seriesIdx, dataIdx) => {
                        // Comprobación robusta para asegurar que u y u.data existan y que seriesData sea un array
                        if (!u || !u.data || !Array.isArray(u.data[seriesIdx])) {
                            return "#CCCCCC80"; // Color por defecto si los datos no son válidos
                        }
                        const seriesData = u.data[seriesIdx];
                        if (dataIdx < 0 || dataIdx >= seriesData.length) {
                            return "#CCCCCC80";
                        }
                        const value = seriesData[dataIdx];
                        const maxValue = seriesData.length > 0 ? Math.max(...seriesData) : 1; 
                        return getBarColor(value, maxValue) + "80";
                    },
                    label: "Tickets por día",
                    paths: uPlot.paths.bars(),
                    points: { show: false },
                }
            ]
        };
        dailyPlotDetailed = new uPlot(dailyOpts, [[0, 1], [0, 0]], dailyContainer); // Modificado para incluir dos puntos dummy
        console.log('Gráfico diario detallado creado:', dailyPlotDetailed);

        console.log('Creando gráfico mensual detallado...');
        const monthlyOpts = {
            ...baseOpts,
            title: "Tickets por Mes (Detallado)",
            series: [
                {},
                {
                    stroke: (u, seriesIdx, dataIdx) => {
                        // Comprobación robusta para asegurar que u y u.data existan y que seriesData sea un array
                        if (!u || !u.data || !Array.isArray(u.data[seriesIdx])) {
                            return "#CCCCCC"; // Color por defecto si los datos no son válidos
                        }
                        const seriesData = u.data[seriesIdx];
                        if (dataIdx < 0 || dataIdx >= seriesData.length) {
                            return "#CCCCCC"; 
                        }
                        const value = seriesData[dataIdx];
                        const maxValue = seriesData.length > 0 ? Math.max(...seriesData) : 1; 
                        return getBarColor(value, maxValue);
                    },
                    width: 2,
                    fill: (u, seriesIdx, dataIdx) => {
                        // Comprobación robusta para asegurar que u y u.data existan y que seriesData sea un array
                        if (!u || !u.data || !Array.isArray(u.data[seriesIdx])) {
                            return "#CCCCCC80"; // Color por defecto si los datos no son válidos
                        }
                        const seriesData = u.data[seriesIdx];
                        if (dataIdx < 0 || dataIdx >= seriesData.length) {
                            return "#CCCCCC80"; 
                        }
                        const value = seriesData[dataIdx];
                        const maxValue = seriesData.length > 0 ? Math.max(...seriesData) : 1; 
                        return getBarColor(value, maxValue) + "80";
                    },
                    label: "Tickets por mes",
                    paths: uPlot.paths.bars(),
                    points: { show: false },
                }
            ]
        };
        monthlyPlotDetailed = new uPlot(monthlyOpts, [[0, 1], [0, 0]], monthlyContainer); // Modificado para incluir dos puntos dummy
        console.log('Gráfico mensual detallado creado:', monthlyPlotDetailed);

        // Añadir listener de redimensionamiento para ambos gráficos detallados
        window.addEventListener('resize', () => {
            if (dailyPlotDetailed && dailyContainer) {
                dailyPlotDetailed.setSize({ width: dailyContainer.offsetWidth, height: 300 });
            }
            if (monthlyPlotDetailed && monthlyContainer) {
                monthlyPlotDetailed.setSize({ width: monthlyContainer.offsetWidth, height: 300 });
            }
        });

    } catch (error) {
        console.error('Error al crear los gráficos detallados:', error);
    }
}

// Actualizar análisis detallado
async function updateDetailedAnalysis() {
    try {
        console.log('Iniciando actualización de análisis detallado avanzado...');
        const startTime = performance.now();
        
        const startDate = document.getElementById('startDateDetailed').value;
        const endDate = document.getElementById('endDateDetailed').value;
        console.log('Fechas de filtro detallado:', { startDate, endDate });
        
        const tickets = await getTickets();
        console.log('Tickets obtenidos para análisis detallado:', tickets.length);
        
        // Usar filtrado optimizado
        const currentTickets = getFilteredTicketsOptimized(startDate, endDate);
        console.log('Tickets filtrados para análisis detallado:', currentTickets.length);

        // Realizar análisis avanzado
        const advancedAnalysis = performAdvancedAnalysis(currentTickets);
        console.log('Análisis avanzado completado:', advancedAnalysis);

        // Actualizar gráficos con datos optimizados
        await updateDetailedChartsOptimized(currentTickets, startDate, endDate);

        // Actualizar métricas básicas (optimizado)
        updateBasicMetrics(currentTickets, advancedAnalysis);

        // Actualizar análisis predictivo avanzado
        updateAdvancedPredictiveAnalysis(advancedAnalysis);

        // Mostrar insights y recomendaciones mejoradas
        updateAdvancedInsights(advancedAnalysis);

        const endTime = performance.now();
        console.log(`Análisis detallado completado en ${(endTime - startTime).toFixed(2)}ms`);

    } catch (error) {
        console.error('Error al actualizar análisis detallado:', error);
    }
}

// Actualizar gráficos detallados de forma optimizada
async function updateDetailedChartsOptimized(tickets, startDate, endDate) {
    // Usar índices pre-calculados para generar datos de gráficos
    const dailyData = getAggregatedDataOptimized(tickets, 'daily', startDate, endDate);
    const monthlyData = getAggregatedDataOptimized(tickets, 'monthly', startDate, endDate);

    // Actualizar gráfico diario
    const dailyTimestamps = Object.keys(dailyData).sort().map(key => {
        const date = parseKeyToDate(key, 'daily');
        return date.getTime() / 1000;
    });
    const dailyValues = Object.keys(dailyData).sort().map(key => dailyData[key]);
    
    console.log('Datos diarios para gráfico detallado:', { dailyTimestamps, dailyValues });

    if (dailyPlotDetailed) {
        console.log('Actualizando dailyPlotDetailed...');
        dailyPlotDetailed.setData([dailyTimestamps, dailyValues]);
    } else {
        console.error('dailyPlotDetailed no está inicializado.');
    }

    // Actualizar gráfico mensual
    const monthlyTimestamps = Object.keys(monthlyData).sort().map(key => {
        const date = parseKeyToDate(key, 'monthly');
        return date.getTime() / 1000;
    });
    const monthlyValues = Object.keys(monthlyData).sort().map(key => monthlyData[key]);
    
    console.log('Datos mensuales para gráfico detallado:', { monthlyTimestamps, monthlyValues });

    if (monthlyPlotDetailed) {
        console.log('Actualizando monthlyPlotDetailed...');
        monthlyPlotDetailed.setData([monthlyTimestamps, monthlyValues]);
    } else {
        console.error('monthlyPlotDetailed no está inicializado.');
    }
}

// Actualizar métricas básicas optimizado
function updateBasicMetrics(tickets, analysis) {
    if (tickets.length === 0) {
        ['dailyAverage', 'peakDays', 'seasonality'].forEach(id => {
            const element = document.getElementById(id);
            if (element) element.textContent = 'Sin datos';
        });
        return;
    }

    // Usar estadísticas pre-calculadas cuando sea posible
    const dailyValues = Object.values(getAggregatedDataOptimized(tickets, 'daily', 
        tickets[0].created_at.split('T')[0], 
        tickets[tickets.length - 1].created_at.split('T')[0]));
    
    if (dailyValues.length > 0) {
        const average = dailyValues.reduce((a, b) => a + b, 0) / dailyValues.length;
        const maxValue = Math.max(...dailyValues);
        const minValue = Math.min(...dailyValues);
        
        // Usar análisis de tendencias del análisis avanzado
        const trend = analysis.trends.temporal || { slope: 0 };
        const trendPercentage = trend.slope || 0;

        // Actualizar métricas en la UI
        const dailyAvgElement = document.getElementById('dailyAverage');
        if (dailyAvgElement) {
            dailyAvgElement.textContent = `Promedio: ${average.toFixed(1)} tickets por día`;
        }

        const peakDaysElement = document.getElementById('peakDays');
        if (peakDaysElement) {
            peakDaysElement.textContent = `Máximo: ${maxValue} tickets, Mínimo: ${minValue} tickets`;
        }

        const seasonalityElement = document.getElementById('seasonality');
        if (seasonalityElement) {
            seasonalityElement.textContent = `Tendencia: ${trendPercentage > 0 ? '↑' : trendPercentage < 0 ? '↓' : '→'} ${Math.abs(trendPercentage).toFixed(1)}%`;
        }
    }
}

// Actualizar análisis predictivo avanzado
function updateAdvancedPredictiveAnalysis(analysis) {
    const trendElement = document.getElementById('trendAnalysis');
    const predictionElement = document.getElementById('nextMonthPrediction');
    const recommendationsElement = document.getElementById('recommendations');

    if (!trendElement || !predictionElement || !recommendationsElement) {
        console.warn('Elementos de análisis predictivo no encontrados');
        return;
    }

    // Análisis de tendencias mejorado
    if (analysis.trends.temporal && analysis.trends.temporal.trend !== 'insufficient_data') {
        const trend = analysis.trends.temporal;
        let trendText = '';
        
        switch(trend.trend) {
            case 'increasing':
                trendText = `Tendencia creciente detectada con ${(trend.correlation * 100).toFixed(1)}% de confianza. `;
                if (trend.volatility > 0.5) {
                    trendText += 'Alta variabilidad observada. ';
                }
                if (trend.cycles.length > 0) {
                    trendText += `Patrón cíclico detectado cada ${trend.cycles[0].period} días.`;
                }
                break;
            case 'decreasing':
                trendText = `Tendencia decreciente detectada con ${(trend.correlation * 100).toFixed(1)}% de confianza. `;
                break;
            case 'stable':
                trendText = 'Volumen de tickets estable. ';
                if (trend.volatility > 0.5) {
                    trendText += 'Se observan fluctuaciones significativas.';
                }
                break;
        }
        
        trendElement.textContent = trendText;
    } else {
        trendElement.textContent = 'Datos insuficientes para análisis de tendencias.';
    }

    // Predicciones mejoradas
    if (analysis.predictions && !analysis.predictions.error) {
        const pred = analysis.predictions;
        const confidenceText = pred.confidence > 0.7 ? 'alta' : pred.confidence > 0.4 ? 'media' : 'baja';
        
        predictionElement.textContent = 
            `Predicciones (confianza ${confidenceText}): ` +
            `7 días: ${pred.next7Days} tickets, ` +
            `30 días: ${pred.next30Days} tickets, ` +
            `90 días: ${pred.next90Days} tickets.`;
    } else {
        predictionElement.textContent = 'No se pueden generar predicciones con los datos actuales.';
    }

    // Recomendaciones avanzadas
    const recommendations = generateAdvancedRecommendations(analysis);
    recommendationsElement.textContent = recommendations.join(' ');
}

// Generar recomendaciones avanzadas basadas en el análisis
function generateAdvancedRecommendations(analysis) {
    const recommendations = [];
    
    // Recomendaciones basadas en patrones semanales
    if (analysis.patterns.weeklyPattern) {
        const wp = analysis.patterns.weeklyPattern;
        const maxDeviation = Math.max(...wp.pattern.map(p => Math.abs(parseFloat(p.deviation))));
        
        if (maxDeviation > 50) {
            recommendations.push(`Considere ajustar la dotación de personal: ${wp.busiestDay.day} requiere ${wp.busiestDay.percentage}% más recursos.`);
        }
    }

    // Recomendaciones basadas en patrones horarios
    if (analysis.patterns.hourlyPattern) {
        const hp = analysis.patterns.hourlyPattern;
        const afterHoursPercentage = (hp.afterHours.reduce((sum, h) => sum + h.count, 0) / 
            (hp.businessHours.reduce((sum, h) => sum + h.count, 0) + hp.afterHours.reduce((sum, h) => sum + h.count, 0))) * 100;
        
        if (afterHoursPercentage > 20) {
            recommendations.push(`${afterHoursPercentage.toFixed(1)}% de tickets fuera de horario laboral. Considere soporte 24/7.`);
        }
        
        if (hp.peakHour.hour >= 9 && hp.peakHour.hour <= 17) {
            recommendations.push(`Hora pico: ${hp.peakHour.hour}:00. Optimice recursos durante este período.`);
        }
    }

    // Recomendaciones basadas en tendencias
    if (analysis.trends.temporal && analysis.trends.temporal.trend !== 'insufficient_data') {
        const trend = analysis.trends.temporal;
        
        if (trend.trend === 'increasing' && trend.slope > 1) {
            recommendations.push('Tendencia creciente significativa. Planifique expansión del equipo de soporte.');
        }
        
        if (trend.volatility > 0.7) {
            recommendations.push('Alta variabilidad detectada. Implemente estrategias de gestión de demanda variable.');
        }
        
        if (trend.cycles.length > 0) {
            const mainCycle = trend.cycles[0];
            recommendations.push(`Patrón cíclico cada ${mainCycle.period} días. Use para planificación predictiva.`);
        }
    }

    // Recomendaciones basadas en anomalías
    if (analysis.anomalies.length > 0) {
        const highAnomalies = analysis.anomalies.filter(a => a.significance === 'high');
        if (highAnomalies.length > 0) {
            recommendations.push(`${highAnomalies.length} anomalías significativas detectadas. Investigue causas raíz.`);
        }
    }

    // Recomendaciones por defecto si no hay suficientes datos
    if (recommendations.length === 0) {
        recommendations.push('Continúe monitoreando las métricas para obtener más insights.');
    }

    return recommendations;
}

// Actualizar insights avanzados
function updateAdvancedInsights(analysis) {
    // Crear sección de insights si no existe
    let insightsContainer = document.getElementById('advanced-insights');
    if (!insightsContainer) {
        // Crear el contenedor después del análisis predictivo
        const recommendationsElement = document.getElementById('recommendations');
        if (recommendationsElement && recommendationsElement.parentNode) {
            insightsContainer = document.createElement('div');
            insightsContainer.id = 'advanced-insights';
            insightsContainer.className = 'mt-4';
            recommendationsElement.parentNode.insertBefore(insightsContainer, recommendationsElement.nextSibling);
        }
    }

    if (!insightsContainer) return;

    // Generar HTML para insights avanzados
    let insightsHTML = '<div class="card"><div class="card-header"><h6 class="mb-0">🔍 Insights Avanzados</h6></div><div class="card-body">';
    
    if (analysis.insights.length > 0) {
        insightsHTML += '<ul class="list-group list-group-flush">';
        analysis.insights.forEach(insight => {
            insightsHTML += `<li class="list-group-item">${insight}</li>`;
        });
        insightsHTML += '</ul>';
    } else {
        insightsHTML += '<p class="text-muted">No hay suficientes datos para generar insights avanzados.</p>';
    }

    // Agregar sección de anomalías si existen
    if (analysis.anomalies.length > 0) {
        insightsHTML += '<div class="mt-3"><h6>⚠️ Anomalías Detectadas</h6><ul class="list-group list-group-flush">';
        analysis.anomalies.slice(0, 3).forEach(anomaly => {
            const typeIcon = anomaly.type === 'spike' ? '📈' : '📉';
            insightsHTML += `<li class="list-group-item">${typeIcon} ${anomaly.date}: ${anomaly.count} tickets (Z-score: ${anomaly.zScore})</li>`;
        });
        insightsHTML += '</ul></div>';
    }

    insightsHTML += '</div></div>';
    insightsContainer.innerHTML = insightsHTML;
}

// Calcular tendencia
function calculateTrend(values) {
    if (values.length < 2) return 0;
    const xMean = (values.length - 1) / 2;
    const yMean = values.reduce((a, b) => a + b, 0) / values.length;
    
    let numerator = 0;
    let denominator = 0;
    
    values.forEach((y, x) => {
        numerator += (x - xMean) * (y - yMean);
        denominator += Math.pow(x - xMean, 2);
    });
    
    const slope = numerator / denominator;
    return (slope / yMean) * 100;
}

// Predecir próximo mes
function predictNextMonth(values, trend) {
    const lastValue = values[values.length - 1];
    return lastValue * (1 + trend / 100);
}

// Generar recomendaciones
function generateRecommendations(trend, average, maxValue) {
    const recommendations = [];
    
    if (trend > 5) {
        recommendations.push("Considerar aumentar el personal de soporte.");
    } else if (trend < -5) {
        recommendations.push("Evaluar la eficiencia del equipo actual.");
    }
    
    if (maxValue > average * 2) {
        recommendations.push("Implementar estrategias para manejar picos de demanda.");
    }
    
    if (average > 50) {
        recommendations.push("Revisar procesos para optimizar tiempos de respuesta.");
    }
    
    return recommendations.length > 0 ? recommendations.join(" ") : "No se requieren cambios inmediatos.";
}

// Función para construir índices optimizados
function buildOptimizedIndices(tickets) {
    try {
    console.log('Construyendo índices optimizados...');
    const start = performance.now();
        
        // Validar y limpiar tickets
        const validTickets = getValidatedTickets(tickets);
        console.log(`📊 Tickets válidos: ${validTickets.length} de ${Array.isArray(tickets) ? tickets.length : 0} total`);
        
        // Validar e inicializar índices
        validateIndices();
    
    // Limpiar índices existentes
        ticketsCache.indices.byDate.clear();
        ticketsCache.indices.byStatus.clear();
        ticketsCache.indices.byMonth.clear();
        ticketsCache.indices.byYear.clear();
        ticketsCache.indices.byHour.clear();
        ticketsCache.indices.byDay.clear();
    
    // Construir índices en una sola pasada
        validTickets.forEach((ticket, index) => {
            try {
                if (!ticket || !ticket.created_at) {
                    console.warn(`Ticket inválido en índice ${index}:`, ticket);
                    return;
                }
        
        const date = new Date(ticket.created_at);
                if (isNaN(date.getTime())) {
                    console.warn(`Fecha inválida en ticket ${ticket.id}:`, ticket.created_at);
                    return;
                }
        
        const dateKey = date.toISOString().split('T')[0];
        const monthKey = date.toISOString().slice(0, 7);
        const yearKey = date.getFullYear().toString();
        const hourKey = date.toISOString().slice(0, 13);
        const dayOfWeek = date.getDay();
        
        // Índice por fecha
        if (!ticketsCache.indices.byDate.has(dateKey)) {
            ticketsCache.indices.byDate.set(dateKey, []);
        }
        ticketsCache.indices.byDate.get(dateKey).push(ticket);
        
        // Índice por status
        if (!ticketsCache.indices.byStatus.has(ticket.status)) {
            ticketsCache.indices.byStatus.set(ticket.status, []);
        }
        ticketsCache.indices.byStatus.get(ticket.status).push(ticket);
        
        // Índice por mes
        if (!ticketsCache.indices.byMonth.has(monthKey)) {
            ticketsCache.indices.byMonth.set(monthKey, []);
        }
        ticketsCache.indices.byMonth.get(monthKey).push(ticket);
        
        // Índice por año
        if (!ticketsCache.indices.byYear.has(yearKey)) {
            ticketsCache.indices.byYear.set(yearKey, []);
        }
        ticketsCache.indices.byYear.get(yearKey).push(ticket);
        
        // Índice por hora
        if (!ticketsCache.indices.byHour.has(hourKey)) {
            ticketsCache.indices.byHour.set(hourKey, []);
        }
        ticketsCache.indices.byHour.get(hourKey).push(ticket);
        
        // Índice por día de la semana
        if (!ticketsCache.indices.byDay.has(dayOfWeek)) {
            ticketsCache.indices.byDay.set(dayOfWeek, []);
        }
        ticketsCache.indices.byDay.get(dayOfWeek).push(ticket);
                
            } catch (ticketError) {
                console.error(`Error procesando ticket en índice ${index}:`, ticketError);
            }
    });
    
    // Calcular estadísticas básicas
        try {
    calculateBasicStats(tickets);
        } catch (statsError) {
            console.error('Error calculando estadísticas básicas:', statsError);
        }
    
    const end = performance.now();
        console.log(`Índices construidos exitosamente en ${(end - start).toFixed(2)}ms`);
        console.log('Tamaños de índices:', {
            byDate: ticketsCache.indices.byDate.size,
            byStatus: ticketsCache.indices.byStatus.size,
            byMonth: ticketsCache.indices.byMonth.size,
            byYear: ticketsCache.indices.byYear.size,
            byHour: ticketsCache.indices.byHour.size,
            byDay: ticketsCache.indices.byDay.size
        });
        
    } catch (error) {
        console.error('Error crítico construyendo índices:', error);
        // Inicializar índices vacíos en caso de error
        ticketsCache.indices = {
            byDate: new Map(),
            byStatus: new Map(),
            byMonth: new Map(),
            byYear: new Map(),
            byHour: new Map(),
            byDay: new Map()
        };
    }
}

// Función para calcular estadísticas básicas
function calculateBasicStats(tickets) {
    if (tickets.length === 0) return;
    
    const dates = tickets.map(t => new Date(t.created_at)).sort();
    const statusCounts = {};
    
    tickets.forEach(ticket => {
        statusCounts[ticket.status] = (statusCounts[ticket.status] || 0) + 1;
    });
    
    ticketsCache.stats = {
        totalTickets: tickets.length,
        dateRange: {
            min: dates[0],
            max: dates[dates.length - 1]
        },
        statusDistribution: statusCounts,
        averagePerDay: tickets.length / Math.max(1, (dates[dates.length - 1] - dates[0]) / (1000 * 60 * 60 * 24)),
        averagePerMonth: tickets.length / Math.max(1, (dates[dates.length - 1] - dates[0]) / (1000 * 60 * 60 * 24 * 30)),
        lastCalculated: Date.now()
    };
}

// Función de filtrado optimizado usando índices
function getFilteredTicketsOptimized(startDate, endDate, additionalFilters = {}) {
    try {
    const start = performance.now();
    
        // Verificar que los índices existan y estén inicializados
        if (!ticketsCache.indices || !ticketsCache.indices.byDate || typeof ticketsCache.indices.byDate.get !== 'function') {
        console.warn('Índices no construidos, usando filtrado tradicional');
        return ticketsCache.data.filter(ticket => {
                try {
            const ticketDate = new Date(ticket.created_at);
            return ticketDate >= new Date(startDate) && ticketDate <= new Date(endDate + 'T23:59:59');
                } catch (filterError) {
                    console.error('Error filtrando ticket:', filterError, ticket);
                    return false;
                }
        });
    }
    
    const startDateObj = new Date(startDate);
    const endDateObj = new Date(endDate + 'T23:59:59');
    const filteredTickets = [];
    
    // Iterar solo sobre las fechas en el rango
    for (let d = new Date(startDateObj); d <= endDateObj; d.setDate(d.getDate() + 1)) {
        const dateKey = d.toISOString().split('T')[0];
        const dayTickets = ticketsCache.indices.byDate.get(dateKey);
        
        if (dayTickets) {
            if (additionalFilters.status) {
                filteredTickets.push(...dayTickets.filter(t => t.status === additionalFilters.status));
            } else {
                filteredTickets.push(...dayTickets);
            }
        }
    }
    
    const end = performance.now();
    console.log(`Filtrado optimizado completado en ${(end - start).toFixed(2)}ms. Tickets: ${filteredTickets.length}`);
    
    return filteredTickets;
        
    } catch (error) {
        console.error('Error en filtrado optimizado:', error);
        // Fallback a filtrado tradicional
        return ticketsCache.data.filter(ticket => {
            try {
                const ticketDate = new Date(ticket.created_at);
                return ticketDate >= new Date(startDate) && ticketDate <= new Date(endDate + 'T23:59:59');
            } catch (filterError) {
                return false;
            }
        });
    }
}

// Análisis avanzado de patrones y tendencias
function performAdvancedAnalysis(tickets) {
    const analysis = {
        patterns: {},
        trends: {},
        predictions: {},
        anomalies: [],
        insights: []
    };
    
    if (tickets.length === 0) return analysis;
    
    analysis.patterns.weeklyPattern = analyzeWeeklyPattern(tickets);
    analysis.patterns.hourlyPattern = analyzeHourlyPattern(tickets);
    analysis.trends.temporal = analyzeTemporal(tickets);
    analysis.anomalies = detectAnomalies(tickets);
    analysis.predictions = generatePredictions(tickets);
    analysis.insights = generateInsights(analysis);
    
    return analysis;
}

// Análisis de patrones semanales
function analyzeWeeklyPattern(tickets) {
    const dayNames = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
    const dayCounts = new Array(7).fill(0);
    
    tickets.forEach(ticket => {
        const dayOfWeek = new Date(ticket.created_at).getDay();
        dayCounts[dayOfWeek]++;
    });
    
    const total = dayCounts.reduce((a, b) => a + b, 0);
    const averagePerDay = total / 7;
    
    const pattern = dayCounts.map((count, index) => ({
        day: dayNames[index],
        count,
        percentage: ((count / total) * 100).toFixed(1),
        deviation: ((count - averagePerDay) / averagePerDay * 100).toFixed(1)
    }));
    
    const busiestDay = pattern.reduce((max, day) => day.count > max.count ? day : max);
    const quietestDay = pattern.reduce((min, day) => day.count < min.count ? day : min);
    
    return {
        pattern,
        busiestDay,
        quietestDay,
        variance: calculateVariance(dayCounts)
    };
}

// Análisis de patrones por hora
function analyzeHourlyPattern(tickets) {
    const hourCounts = new Array(24).fill(0);
    
    tickets.forEach(ticket => {
        const hour = new Date(ticket.created_at).getHours();
        hourCounts[hour]++;
    });
    
    const total = hourCounts.reduce((a, b) => a + b, 0);
    const pattern = hourCounts.map((count, hour) => ({
        hour,
        count,
        percentage: ((count / total) * 100).toFixed(1)
    }));
    
    const peakHour = pattern.reduce((max, hour) => hour.count > max.count ? hour : max);
    const quietestHour = pattern.reduce((min, hour) => hour.count < min.count ? hour : min);
    
    return {
        pattern,
        peakHour,
        quietestHour,
        businessHours: pattern.filter(h => h.hour >= 9 && h.hour <= 17),
        afterHours: pattern.filter(h => h.hour < 9 || h.hour > 17)
    };
}

// Análisis temporal de tendencias
function analyzeTemporal(tickets) {
    if (tickets.length < 7) return { trend: 'insufficient_data' };
    
    // Agrupar por días
    const dailyData = {};
    tickets.forEach(ticket => {
        const date = new Date(ticket.created_at).toISOString().split('T')[0];
        dailyData[date] = (dailyData[date] || 0) + 1;
    });
    
    const sortedDates = Object.keys(dailyData).sort();
    const values = sortedDates.map(date => dailyData[date]);
    
    // Calcular tendencia usando regresión lineal simple
    const trend = calculateLinearTrend(values);
    
    // Calcular volatilidad
    const volatility = calculateVolatility(values);
    
    // Detectar ciclos
    const cycles = detectCycles(values);
    
    return {
        trend: trend.slope > 0.1 ? 'increasing' : trend.slope < -0.1 ? 'decreasing' : 'stable',
        slope: trend.slope,
        correlation: trend.correlation,
        volatility,
        cycles,
        movingAverage: calculateMovingAverage(values, 7)
    };
}

// Detección de anomalías
function detectAnomalies(tickets) {
    const dailyData = {};
    tickets.forEach(ticket => {
        const date = new Date(ticket.created_at).toISOString().split('T')[0];
        dailyData[date] = (dailyData[date] || 0) + 1;
    });
    
    const values = Object.values(dailyData);
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    const stdDev = Math.sqrt(values.reduce((sq, n) => sq + Math.pow(n - mean, 2), 0) / values.length);
    
    const anomalies = [];
    Object.entries(dailyData).forEach(([date, count]) => {
        const zScore = Math.abs((count - mean) / stdDev);
        if (zScore > 2) { // Más de 2 desviaciones estándar
            anomalies.push({
                date,
                count,
                zScore: zScore.toFixed(2),
                type: count > mean ? 'spike' : 'drop',
                significance: zScore > 3 ? 'high' : 'medium'
            });
        }
    });
    
    return anomalies.sort((a, b) => b.zScore - a.zScore);
}

// Generar predicciones
function generatePredictions(tickets) {
    const analysis = analyzeTemporal(tickets);
    
    if (analysis.trend === 'insufficient_data') {
        return { error: 'Datos insuficientes para predicciones' };
    }
    
    const lastValue = analysis.movingAverage[analysis.movingAverage.length - 1];
    const trendMultiplier = analysis.slope;
    
    // Predicciones para los próximos 7, 30 y 90 días
    const predictions = {
        next7Days: Math.max(0, Math.round(lastValue + (trendMultiplier * 7))),
        next30Days: Math.max(0, Math.round(lastValue + (trendMultiplier * 30))),
        next90Days: Math.max(0, Math.round(lastValue + (trendMultiplier * 90))),
        confidence: Math.max(0.1, Math.min(0.9, 1 - analysis.volatility))
    };
    
    return predictions;
}

// Generar insights automáticos
function generateInsights(analysis) {
    const insights = [];
    
    if (analysis.patterns.weeklyPattern) {
        const wp = analysis.patterns.weeklyPattern;
        insights.push(`El ${wp.busiestDay.day} es el día más ocupado con ${wp.busiestDay.count} tickets (${wp.busiestDay.percentage}% del total)`);
        insights.push(`El ${wp.quietestDay.day} es el día más tranquilo con ${wp.quietestDay.count} tickets`);
    }
    
    if (analysis.patterns.hourlyPattern) {
        const hp = analysis.patterns.hourlyPattern;
        insights.push(`La hora pico es ${hp.peakHour.hour}:00 con ${hp.peakHour.count} tickets`);
        
        const businessHoursTotal = hp.businessHours.reduce((sum, h) => sum + h.count, 0);
        const afterHoursTotal = hp.afterHours.reduce((sum, h) => sum + h.count, 0);
        const businessHoursPercentage = ((businessHoursTotal / (businessHoursTotal + afterHoursTotal)) * 100).toFixed(1);
        
        insights.push(`${businessHoursPercentage}% de los tickets ocurren en horario laboral (9-17h)`);
    }
    
    if (analysis.trends.temporal && analysis.trends.temporal.trend !== 'insufficient_data') {
        const trend = analysis.trends.temporal;
        if (trend.trend === 'increasing') {
            insights.push(`Tendencia creciente detectada: aumento promedio de ${trend.slope.toFixed(1)} tickets por día`);
        } else if (trend.trend === 'decreasing') {
            insights.push(`Tendencia decreciente detectada: disminución promedio de ${Math.abs(trend.slope).toFixed(1)} tickets por día`);
        }
        
        if (trend.volatility > 0.5) {
            insights.push('Alta variabilidad en el volumen de tickets detectada');
        }
    }
    
    if (analysis.anomalies.length > 0) {
        const significantAnomalies = analysis.anomalies.filter(a => a.significance === 'high');
        if (significantAnomalies.length > 0) {
            insights.push(`${significantAnomalies.length} anomalías significativas detectadas en el período`);
        }
    }
    
    return insights;
}

// Funciones auxiliares para cálculos estadísticos
function calculateVariance(values) {
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    return values.reduce((sq, n) => sq + Math.pow(n - mean, 2), 0) / values.length;
}

function calculateLinearTrend(values) {
    const n = values.length;
    const x = Array.from({length: n}, (_, i) => i);
    const sumX = x.reduce((a, b) => a + b, 0);
    const sumY = values.reduce((a, b) => a + b, 0);
    const sumXY = x.reduce((sum, xi, i) => sum + xi * values[i], 0);
    const sumXX = x.reduce((sum, xi) => sum + xi * xi, 0);
    
    const slope = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);
    const intercept = (sumY - slope * sumX) / n;
    
    // Calcular correlación
    const meanX = sumX / n;
    const meanY = sumY / n;
    const num = x.reduce((sum, xi, i) => sum + (xi - meanX) * (values[i] - meanY), 0);
    const denX = Math.sqrt(x.reduce((sum, xi) => sum + Math.pow(xi - meanX, 2), 0));
    const denY = Math.sqrt(values.reduce((sum, yi) => sum + Math.pow(yi - meanY, 2), 0));
    const correlation = num / (denX * denY);
    
    return { slope, intercept, correlation };
}

function calculateVolatility(values) {
    if (values.length < 2) return 0;
    const returns = values.slice(1).map((val, i) => (val - values[i]) / Math.max(1, values[i]));
    const meanReturn = returns.reduce((a, b) => a + b, 0) / returns.length;
    const variance = returns.reduce((sq, r) => sq + Math.pow(r - meanReturn, 2), 0) / returns.length;
    return Math.sqrt(variance);
}

function detectCycles(values) {
    // Implementación simple de detección de ciclos usando autocorrelación
    const cycles = [];
    for (let lag = 1; lag <= Math.min(30, Math.floor(values.length / 2)); lag++) {
        const correlation = calculateAutocorrelation(values, lag);
        if (correlation > 0.3) {
            cycles.push({ period: lag, strength: correlation });
        }
    }
    return cycles.sort((a, b) => b.strength - a.strength);
}

function calculateAutocorrelation(values, lag) {
    const n = values.length - lag;
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    
    let num = 0, den = 0;
    for (let i = 0; i < n; i++) {
        num += (values[i] - mean) * (values[i + lag] - mean);
    }
    
    for (let i = 0; i < values.length; i++) {
        den += Math.pow(values[i] - mean, 2);
    }
    
    return den === 0 ? 0 : num / den;
}

function calculateMovingAverage(values, window) {
    const result = [];
    for (let i = window - 1; i < values.length; i++) {
        const avg = values.slice(i - window + 1, i + 1).reduce((a, b) => a + b, 0) / window;
        result.push(avg);
    }
    return result;
}

// Variables globales para la página de carga del sistema
let systemLoadData = {
    activeTickets: [],
    statusDistribution: {},
    priorityDistribution: {},
    unassignedCount: 0,
    urgentCount: 0,
    satisfactionData: null,
    currentPage: 1,
    itemsPerPage: 10,
    filteredTickets: []
};

// Inicializar la página de carga del sistema
function initSystemLoadPage() {
    console.log('Inicializando página de carga del sistema...');
    initStatusPieChart();
    
    // Agregar event listeners para controles de tabla
    const ticketSearch = document.getElementById('ticketSearch');
    if (ticketSearch) {
        ticketSearch.addEventListener('input', debounce(() => {
            systemLoadData.currentPage = 1; // Reset a primera página al buscar
            updateActiveTicketsTable();
        }, 300));
    }
    
    const ticketsPerPage = document.getElementById('ticketsPerPage');
    if (ticketsPerPage) {
        ticketsPerPage.addEventListener('change', () => {
            systemLoadData.currentPage = 1; // Reset a primera página al cambiar items por página
            updateActiveTicketsTable();
        });
    }
    
    // Agregar event listeners para botones - versión mejorada
    const applyFilterBtn = document.getElementById('applyFilterSystemLoad');
    if (applyFilterBtn) {
        applyFilterBtn.addEventListener('click', () => {
            console.log('🔄 Actualizando datos manualmente...');
            
            // Asegurar fechas por defecto si no existen
            const startDate = document.getElementById('startDateSystemLoad');
            const endDate = document.getElementById('endDateSystemLoad');
            
            if (startDate && !startDate.value) {
                const today = new Date();
                const oneWeekAgo = new Date(today);
                oneWeekAgo.setDate(today.getDate() - 7);
                startDate.value = oneWeekAgo.toISOString().split('T')[0];
            }
            
            if (endDate && !endDate.value) {
                endDate.value = new Date().toISOString().split('T')[0];
            }
            
            updateSystemLoad();
        });
    }
    
    const refreshBtn = document.getElementById('refreshSystemLoad');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', () => {
            console.log('🔄 Refrescando datos...');
            
            // Si ya hay datos, usar función robusta para refrescar tabla inmediatamente
            if (systemLoadData.activeTickets && systemLoadData.activeTickets.length > 0) {
                console.log('📋 Refrescando tabla con datos existentes...');
                updateActiveTicketsTableRobust(systemLoadData.activeTickets);
            }
            
            // Luego hacer carga completa
            clearDataCache(); // Limpiar caché
            updateSystemLoad();
        });
    }

    // Cargar datos automáticamente al abrir la página
    setTimeout(() => {
        const startDate = document.getElementById('startDateSystemLoad').value;
        const endDate = document.getElementById('endDateSystemLoad').value;
        
        if (startDate && endDate) {
            console.log('Cargando datos iniciales para carga del sistema...');
            updateSystemLoad();
        } else {
            // Si no hay fechas, usar valores por defecto y cargar
            const today = new Date();
            const oneWeekAgo = new Date(today);
            oneWeekAgo.setDate(today.getDate() - 7);
            
            const startDateElement = document.getElementById('startDateSystemLoad');
            const endDateElement = document.getElementById('endDateSystemLoad');
            
            if (startDateElement && endDateElement) {
                startDateElement.value = oneWeekAgo.toISOString().split('T')[0];
                endDateElement.value = today.toISOString().split('T')[0];
                console.log('📅 Usando fechas por defecto y cargando datos...');
                updateSystemLoad();
            }
        }
    }, 500);
}

// Inicializar gráfico de pastel para estados
function initStatusPieChart() {
    const container = document.getElementById('statusPieChart');
    if (!container) return;

    container.innerHTML = '';
    
    const opts = {
        title: 'Distribución por Estado',
        width: container.clientWidth,
        height: 350,
        series: [
            {},
            {
                label: 'Estados',
                value: (self, rawValue) => rawValue + ' tickets',
                paths: (self, seriesIdx) => {
                    // Generar paths para pie chart - implementación simple
                    return self.data[seriesIdx].map((val, i) => {
                        return `M250,175 L250,25 A150,150 0 0,1 400,175 Z`;
                    });
                },
                stroke: '#fff',
                width: 2
            }
        ],
        legend: {
            show: true,
            live: false
        }
    };

    // Para pie chart usaremos una implementación simplificada
    statusPieChart = { container, data: null };
}
// Obtener datos de tickets por estado (optimizado)
async function getTicketsByStatus() {
    try {
        const statuses = ['new', 'open', 'pending', 'solved', 'closed'];
        
        // Hacer todas las llamadas en paralelo para mayor velocidad
        const promises = statuses.map(async (status) => {
            const query = `type:ticket status:${status}`;
            
            // Intentar usar count endpoint si está disponible, sino usar search con per_page máximo
            try {
                const response = await client.request({
                    url: '/api/v2/search/count.json?query=' + encodeURIComponent(query),
                    type: 'GET'
                });
                return { status, count: response.count || 0 };
            } catch (countError) {
                // Fallback a search con paginación optimizada
                let totalCount = 0;
                let hasMore = true;
                let page = 1;
                
                while (hasMore && page <= 5) { // Limitar a 5 páginas máximo para velocidad
                    const response = await client.request({
                        url: `/api/v2/search.json?query=${encodeURIComponent(query)}&per_page=1000&page=${page}`,
                        type: 'GET'
                    });
                    
                    const results = response.results || [];
                    totalCount += results.length;
                    
                    hasMore = results.length === 1000 && page < 5;
                    page++;
                    
                    // Si es la primera página y no está completa, no hay más
                    if (page === 2 && results.length < 1000) {
                        hasMore = false;
                    }
                }
                
                return { status, count: totalCount };
            }
        });
        
        const results = await Promise.all(promises);
        const statusData = {};
        
        results.forEach(result => {
            statusData[result.status] = result.count;
        });
        
        console.log('Datos por estado obtenidos (optimizado):', statusData);
        return statusData;
    } catch (error) {
        console.error('Error obteniendo tickets por estado:', error);
        return {};
    }
}

// Obtener tickets sin asignar (optimizado)
async function getUnassignedTickets() {
    try {
        const query = 'type:ticket assignee:none';
        
        try {
            // Intentar usar count endpoint primero
            const response = await client.request({
                url: '/api/v2/search/count.json?query=' + encodeURIComponent(query),
                type: 'GET'
            });
            console.log('Tickets sin asignar obtenidos (count):', response.count || 0);
            return response.count || 0;
        } catch (countError) {
            // Fallback a search optimizado con paginación limitada
            let totalCount = 0;
            let hasMore = true;
            let page = 1;
            
            while (hasMore && page <= 3) { // Limitar a 3 páginas para velocidad
                const response = await client.request({
                    url: `/api/v2/search.json?query=${encodeURIComponent(query)}&per_page=1000&page=${page}`,
                    type: 'GET'
                });
                
                const results = response.results || [];
                totalCount += results.length;
                
                hasMore = results.length === 1000 && page < 3;
                page++;
                
                if (page === 2 && results.length < 1000) {
                    hasMore = false;
                }
            }
            
            console.log('Tickets sin asignar obtenidos (search):', totalCount);
            return totalCount;
        }
    } catch (error) {
        console.error('Error obteniendo tickets sin asignar:', error);
        return 0;
    }
}

// Obtener lista de tickets activos (optimizado con paginación inteligente)
async function getActiveTickets() {
    try {
        console.log('🔍 Iniciando obtención de tickets activos...');
        let allTickets = [];
        const maxPages = 3; // Reducir a 3 páginas para carga más rápida
        
        // Primero intentar usar búsqueda filtrada para ser más eficiente
        try {
            console.log('🔍 Intentando búsqueda optimizada con filtros...');
            const activeQuery = 'type:ticket status<solved'; // Excluir solved y closed directamente
            
            const searchResponse = await client.request({
                url: `/api/v2/search.json?query=${encodeURIComponent(activeQuery)}&per_page=1000`,
                type: 'GET'
            });
            
            if (searchResponse.results && searchResponse.results.length > 0) {
                console.log(`✅ Tickets activos obtenidos via búsqueda: ${searchResponse.results.length}`);
                return searchResponse.results;
            }
        } catch (searchError) {
            console.warn('⚠️ Búsqueda filtrada falló, usando método de respaldo:', searchError);
        }
        
        // Método de respaldo: paginación paralela
        console.log('🔍 Usando método de respaldo con paginación paralela...');
        const promises = [];
        
        for (let page = 1; page <= maxPages; page++) {
            promises.push(
                client.request({
                    url: `/api/v2/tickets.json?per_page=1000&page=${page}`,
                    type: 'GET'
                }).then(response => {
                    const tickets = response.tickets || [];
                    console.log(`📄 Página ${page}: ${tickets.length} tickets obtenidos`);
                    return { tickets, page };
                }).catch(error => {
                    console.warn(`❌ Error en página ${page}:`, error);
                    return { tickets: [], page }; // Retornar estructura vacía en caso de error
                })
            );
        }
        
        // Esperar todas las respuestas
        console.log('⏳ Esperando respuestas de páginas paralelas...');
        const responses = await Promise.all(promises);
        
        // Procesar respuestas y combinar tickets
        let stopFetching = false;
        responses.forEach((response) => {
            if (!stopFetching) {
                const tickets = response.tickets || [];
                allTickets = allTickets.concat(tickets);
                
                // Si una página devuelve menos de 1000 tickets, no hay más páginas
                if (tickets.length < 1000) {
                    console.log(`📄 Última página encontrada: ${response.page} con ${tickets.length} tickets`);
                    stopFetching = true;
                }
            }
        });
        
        console.log(`📊 Total de tickets obtenidos: ${allTickets.length}`);
        
        // Filtrar solo tickets realmente activos (excluir cerrados y resueltos)
        const activeTickets = allTickets.filter(ticket => {
            const status = ticket.status;
            return status !== 'closed' && status !== 'solved';
        });
        
        console.log(`✅ Tickets filtrados como activos: ${activeTickets.length} de ${allTickets.length} total`);
        
        if (activeTickets.length === 0) {
            console.warn('⚠️ No se encontraron tickets activos. Verificar permisos o filtros.');
        }
        
        return activeTickets;
    } catch (error) {
        console.error('❌ Error crítico obteniendo tickets activos:', error);
        return [];
    }
}

// Renderizar gráfico de pastel para estados
function renderStatusPieChart(statusData) {
    const container = document.getElementById('statusPieChart');
    if (!container) return;

    const total = Object.values(statusData).reduce((sum, count) => sum + count, 0);
    if (total === 0) {
        container.innerHTML = '<div class="text-center py-5 text-muted">No hay datos disponibles</div>';
        return;
    }

    const colors = {
        'new': '#007bff',
        'open': '#ffc107',
        'pending': '#dc3545',
        'solved': '#28a745',
        'closed': '#6c757d'
    };

    const labels = {
        'new': 'Nuevo',
        'open': 'Abierto',
        'pending': 'Pendiente',
        'solved': 'Resuelto',
        'closed': 'Cerrado'
    };

    let html = '<div class="pie-chart-container">';
    html += '<div class="pie-chart-legend">';
    
    let cumulativePercentage = 0;
    Object.entries(statusData).forEach(([status, count]) => {
        if (count > 0) {
            const percentage = ((count / total) * 100).toFixed(1);
            html += `
                <div class="legend-item">
                    <div class="legend-color" style="background-color: ${colors[status]}"></div>
                    <span class="legend-label">${labels[status]}: ${count} (${percentage}%)</span>
                </div>
            `;
        }
    });
    
    html += '</div></div>';
    container.innerHTML = html;
}


// Actualizar KPIs
function updateKPIs(statusData, priorityData, unassignedCount, satisfactionData) {
    // Total de tickets activos (excluyendo cerrados y resueltos)
    const activeCount = (statusData.new || 0) + (statusData.open || 0) + (statusData.pending || 0);
    document.getElementById('totalActiveTickets').textContent = activeCount.toLocaleString();

    // Tickets sin asignar
    document.getElementById('unassignedTickets').textContent = unassignedCount.toLocaleString();

    // Tickets urgentes
    const urgentCount = priorityData.urgent || 0;
    document.getElementById('urgentTickets').textContent = urgentCount.toLocaleString();

    // Satisfacción promedio
    const avgSatisfaction = satisfactionData?.average || 0;
    document.getElementById('avgSatisfactionSystemLoad').textContent = avgSatisfaction.toFixed(1);
}

// Actualizar información de resumen de los gráficos
function updateChartSummaries(statusData, priorityData) {
    try {
        // Tiempo actual
        const currentTime = new Date().toLocaleTimeString('es-ES', { 
            hour: '2-digit', 
            minute: '2-digit',
            hour12: true 
        });
        
        // Actualizar resumen del gráfico de estados
        const totalActive = (statusData.new || 0) + (statusData.open || 0) + (statusData.pending || 0);
        const totalClosed = (statusData.solved || 0) + (statusData.closed || 0);
        
        // Actualizar solo elementos que existen en el DOM
        const statusChartTime = document.getElementById('statusChartTime');
        const statusChartActive = document.getElementById('statusChartActive');
        const statusChartClosed = document.getElementById('statusChartClosed');
        
        if (statusChartTime) statusChartTime.textContent = currentTime;
        if (statusChartActive) statusChartActive.textContent = totalActive.toLocaleString();
        if (statusChartClosed) statusChartClosed.textContent = totalClosed.toLocaleString();
        
        // NOTA: Elementos de prioridad removidos de la interfaz - No se actualizan
        console.log('📊 Resumen de estados actualizado:', { totalActive, totalClosed, time: currentTime });
        
    } catch (error) {
        console.error('❌ Error actualizando resúmenes de gráficos:', error);
    }
}

// Función deshabilitada - Gráfico temporal removido de la interfaz
// function updateTemporalChartSummary(newTicketsTotal, solvedTicketsTotal) { ... }

// Función robusta para actualizar tabla de tickets activos
function updateActiveTicketsTableRobust(tickets) {
    try {
        console.log('🔍 ROBUST: Actualizando tabla con', tickets.length, 'tickets');
        
        const tbody = document.getElementById('activeTicketsBody');
        const ticketsInfo = document.getElementById('ticketsInfo');
        const ticketsPagination = document.getElementById('ticketsPagination');
        
        // Validación de elementos DOM
        if (!tbody) {
            console.error('❌ ROBUST: No se encontró activeTicketsBody');
            return false;
        }
        
        console.log('✅ ROBUST: Elementos DOM encontrados');
        
        // Si no hay tickets, mostrar mensaje
        if (!tickets || tickets.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" class="text-center py-4 text-muted">No se encontraron tickets activos</td></tr>';
            if (ticketsInfo) ticketsInfo.textContent = 'No hay tickets para mostrar';
            if (ticketsPagination) ticketsPagination.innerHTML = '';
            console.log('📋 ROBUST: Tabla limpiada - Sin tickets');
            return true;
        }
        
        // Crear filas de tabla con validación robusta
        const rows = tickets.slice(0, 10).map((ticket, index) => {
            try {
                console.log(`🔍 ROBUST: Procesando ticket ${index + 1}:`, ticket.id);
                
                // Validación y formateo seguro
                const id = ticket.id || 'N/A';
                const subject = (ticket.subject || 'Sin asunto').substring(0, 40);
                const status = ticket.status || 'unknown';
                const priority = ticket.priority || 'normal';
                const assignee = ticket.assignee_id ? 'Asignado' : 'Sin asignar';
                
                let createdDate = 'N/A';
                try {
                    if (ticket.created_at) {
                        createdDate = new Date(ticket.created_at).toLocaleDateString('es-ES');
                    }
                } catch (dateError) {
                    console.warn('⚠️ ROBUST: Error formateando fecha:', dateError);
                }
                
                return `
                    <tr>
                        <td><strong>#${id}</strong></td>
                        <td title="${ticket.subject || 'Sin asunto'}">${subject}${subject.length >= 40 ? '...' : ''}</td>
                        <td><span class="badge bg-primary">${status}</span></td>
                        <td><span class="badge bg-secondary">${priority}</span></td>
                        <td>${assignee}</td>
                        <td>${createdDate}</td>
                    </tr>
                `;
            } catch (rowError) {
                console.warn('⚠️ ROBUST: Error procesando ticket:', rowError);
                return `
                    <tr>
                        <td><strong>#ERROR</strong></td>
                        <td colspan="5" class="text-danger">Error procesando ticket</td>
                    </tr>
                `;
            }
        });
        
        // Insertar HTML generado
        console.log('🔍 ROBUST: Insertando', rows.length, 'filas');
        tbody.innerHTML = rows.join('');
        
        // Actualizar información de paginación
        if (ticketsInfo) {
            const shown = Math.min(10, tickets.length);
            ticketsInfo.textContent = `Mostrando 1-${shown} de ${tickets.length} tickets`;
        }
        
        // Limpiar paginación (simplificado por ahora)
        if (ticketsPagination) {
            ticketsPagination.innerHTML = '';
        }
        
        console.log('✅ ROBUST: Tabla actualizada exitosamente');
        
        // Intentar llamar a la función original como refinamiento (opcional)
        setTimeout(() => {
            try {
                console.log('🔄 ROBUST: Intentando refinamiento con función original...');
                if (systemLoadData && systemLoadData.activeTickets && systemLoadData.activeTickets.length > 0) {
                    updateActiveTicketsTable();
                } else {
                    console.log('📋 ROBUST: Saltando refinamiento - No hay datos en systemLoadData');
                }
            } catch (refinementError) {
                console.warn('⚠️ ROBUST: Refinamiento falló, pero datos básicos ya están mostrados:', refinementError);
            }
        }, 500); // Reducido a 500ms para ser más rápido
        
        return true;
        
    } catch (robustError) {
        console.error('❌ ROBUST: Error crítico en función robusta:', robustError);
        
        // Último recurso: mostrar error en tabla
        const tbody = document.getElementById('activeTicketsBody');
        if (tbody) {
            tbody.innerHTML = `<tr><td colspan="6" class="text-center py-4 text-danger">Error crítico cargando tickets: ${robustError.message}</td></tr>`;
        }
        
        return false;
    }
}

// Formatear datos de tickets para la tabla
function formatTicketForTable(ticket) {
    // Validar que el ticket es un objeto válido
    if (!ticket || typeof ticket !== 'object') {
        console.warn('⚠️ Ticket inválido recibido:', ticket);
        return {
            id: 'N/A',
            subject: 'Ticket inválido',
            status: 'unknown',
            statusLabel: 'Desconocido',
            statusClass: '',
            priority: 'normal',
            priorityLabel: 'Normal',
            priorityClass: '',
            assignee: 'N/A',
            created: 'N/A'
        };
    }

    const statusClasses = {
        'new': 'status-new',
        'open': 'status-open',
        'pending': 'status-pending',
        'solved': 'status-solved',
        'closed': 'status-closed'
    };

    const priorityClasses = {
        'low': 'priority-low',
        'normal': 'priority-normal',
        'high': 'priority-high',
        'urgent': 'priority-urgent'
    };

    const statusLabels = {
        'new': 'Nuevo',
        'open': 'Abierto',
        'pending': 'Pendiente',
        'solved': 'Resuelto',
        'closed': 'Cerrado'
    };

    const priorityLabels = {
        'low': 'Baja',
        'normal': 'Normal',
        'high': 'Alta',
        'urgent': 'Urgente'
    };

    // Manejar fecha con validación
    let createdDate = 'N/A';
    try {
        if (ticket.created_at) {
            const date = new Date(ticket.created_at);
            if (!isNaN(date.getTime())) {
                createdDate = date.toLocaleDateString('es-ES');
            }
        }
    } catch (dateError) {
        console.warn('Error formateando fecha:', dateError);
    }

    return {
        id: ticket.id || 'N/A',
        subject: ticket.subject || 'Sin asunto',
        status: ticket.status || 'unknown',
        statusLabel: statusLabels[ticket.status] || ticket.status || 'Desconocido',
        statusClass: statusClasses[ticket.status] || '',
        priority: ticket.priority || 'normal',
        priorityLabel: priorityLabels[ticket.priority] || ticket.priority || 'Normal',
        priorityClass: priorityClasses[ticket.priority] || '',
        assignee: ticket.assignee_id ? 'Asignado' : 'Sin asignar',
        created: createdDate
    };
}

// Actualizar tabla de tickets activos
function updateActiveTicketsTable() {
    console.log('🔍 INICIO updateActiveTicketsTable()');
    try {
        console.log('🔍 Obteniendo elementos DOM...');
        const search = document.getElementById('ticketSearch')?.value?.toLowerCase() || '';
        const itemsPerPage = parseInt(document.getElementById('ticketsPerPage')?.value || '10');
        
        console.log('🔍 Búsqueda:', search, 'Items por página:', itemsPerPage);
        
        // Validar que tenemos tickets activos
        if (!systemLoadData.activeTickets || !Array.isArray(systemLoadData.activeTickets)) {
            console.warn('⚠️ No hay tickets activos disponibles para mostrar');
            systemLoadData.activeTickets = [];
        }
        
        console.log(`📋 Actualizando tabla con ${systemLoadData.activeTickets.length} tickets activos`);
        console.log('🔍 Sample ticket:', systemLoadData.activeTickets[0]);
        
        // Filtrar tickets
        console.log('🔍 Iniciando filtrado...');
        let filtered = systemLoadData.activeTickets;
        if (search) {
            console.log('🔍 Aplicando filtro de búsqueda:', search);
            filtered = filtered.filter(ticket => {
                try {
                    const formattedTicket = formatTicketForTable(ticket);
                    return formattedTicket.id.toString().includes(search) ||
                           formattedTicket.subject.toLowerCase().includes(search) ||
                           formattedTicket.statusLabel.toLowerCase().includes(search) ||
                           formattedTicket.priorityLabel.toLowerCase().includes(search);
                } catch (error) {
                    console.warn('Error filtrando ticket:', error);
                    return false;
                }
            });
        }

        console.log('🔍 Tickets filtrados:', filtered.length);
        systemLoadData.filteredTickets = filtered;
        const totalPages = Math.ceil(filtered.length / itemsPerPage);
        const startIndex = (systemLoadData.currentPage - 1) * itemsPerPage;
        const endIndex = Math.min(startIndex + itemsPerPage, filtered.length);
        const pageTickets = filtered.slice(startIndex, endIndex);
        
        console.log('🔍 Paginación:', {
            totalPages,
            currentPage: systemLoadData.currentPage,
            startIndex,
            endIndex,
            pageTicketsCount: pageTickets.length
        });

    // Actualizar tabla
    console.log('🔍 Buscando elemento activeTicketsBody...');
    const tbody = document.getElementById('activeTicketsBody');
    if (!tbody) {
        console.error('❌ Element activeTicketsBody not found in DOM');
        return;
    }
    
    console.log('🔍 Elemento tbody encontrado:', tbody);
    
    if (pageTickets.length === 0) {
        console.log('🔍 No hay tickets para mostrar');
        tbody.innerHTML = '<tr><td colspan="6" class="text-center py-4 text-muted">No se encontraron tickets</td></tr>';
    } else {
        console.log('🔍 Formateando', pageTickets.length, 'tickets para mostrar...');
        
        try {
            const formattedRows = pageTickets.map(ticket => {
                console.log('🔍 Formateando ticket ID:', ticket.id);
                const formatted = formatTicketForTable(ticket);
                console.log('🔍 Ticket formateado:', formatted);
                return `
                    <tr>
                        <td><strong>#${formatted.id}</strong></td>
                        <td class="text-truncate" style="max-width: 200px;" title="${formatted.subject}">${formatted.subject}</td>
                        <td><span class="status-badge ${formatted.statusClass}">${formatted.statusLabel}</span></td>
                        <td><span class="priority-badge ${formatted.priorityClass}">${formatted.priorityLabel}</span></td>
                        <td>${formatted.assignee}</td>
                        <td>${formatted.created}</td>
                    </tr>
                `;
            });
            
            console.log('🔍 Rows HTML generado:', formattedRows.length, 'filas');
            tbody.innerHTML = formattedRows.join('');
            console.log('🔍 HTML insertado en tbody exitosamente');
        } catch (formatError) {
            console.error('❌ Error formateando tickets:', formatError);
            tbody.innerHTML = '<tr><td colspan="6" class="text-center py-4 text-danger">Error formateando tickets</td></tr>';
        }
    }

    // Actualizar información de paginación
    const ticketsInfo = document.getElementById('ticketsInfo');
    if (ticketsInfo) {
        ticketsInfo.textContent = `Mostrando ${startIndex + 1}-${endIndex} de ${filtered.length} tickets`;
    }

        // Actualizar controles de paginación
        updatePagination(totalPages);
        
    } catch (error) {
        console.error('Error actualizando tabla de tickets activos:', error);
        
        // Fallback: mostrar mensaje de error en la tabla
        const tbody = document.getElementById('activeTicketsBody');
        if (tbody) {
            tbody.innerHTML = '<tr><td colspan="6" class="text-center py-4 text-danger">Error cargando tickets activos</td></tr>';
        }
        
        // Resetear información de paginación
        const ticketsInfo = document.getElementById('ticketsInfo');
        if (ticketsInfo) {
            ticketsInfo.textContent = 'Error al cargar datos';
        }
    }
}

// Actualizar controles de paginación
function updatePagination(totalPages) {
    const pagination = document.getElementById('ticketsPagination');
    if (!pagination) {
        console.warn('❌ Element ticketsPagination not found in DOM');
        return;
    }
    
    const currentPage = systemLoadData.currentPage;

    let html = '';
    
    // Botón anterior
    html += `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}">
        <a class="page-link" href="#" onclick="changeTablePage(${currentPage - 1})" tabindex="-1">Anterior</a>
    </li>`;

    // Páginas numeradas
    const startPage = Math.max(1, currentPage - 2);
    const endPage = Math.min(totalPages, currentPage + 2);

    if (startPage > 1) {
        html += '<li class="page-item"><a class="page-link" href="#" onclick="changeTablePage(1)">1</a></li>';
        if (startPage > 2) {
            html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
        }
    }

    for (let i = startPage; i <= endPage; i++) {
        html += `<li class="page-item ${i === currentPage ? 'active' : ''}">
            <a class="page-link" href="#" onclick="changeTablePage(${i})">${i}</a>
        </li>`;
    }

    if (endPage < totalPages) {
        if (endPage < totalPages - 1) {
            html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
        }
        html += `<li class="page-item"><a class="page-link" href="#" onclick="changeTablePage(${totalPages})">${totalPages}</a></li>`;
    }

    // Botón siguiente
    html += `<li class="page-item ${currentPage === totalPages ? 'disabled' : ''}">
        <a class="page-link" href="#" onclick="changeTablePage(${currentPage + 1})">Siguiente</a>
    </li>`;

    pagination.innerHTML = html;
}

// Cambiar página de la tabla
function changeTablePage(page) {
    if (page < 1 || page > Math.ceil(systemLoadData.filteredTickets.length / parseInt(document.getElementById('ticketsPerPage').value))) {
        return;
    }
    
    systemLoadData.currentPage = page;
    updateActiveTicketsTable();
}

// Función principal para actualizar toda la página de carga del sistema
async function updateSystemLoad() {
    try {
        console.log('🚀 Iniciando actualización optimizada del sistema...');
        const startTime = performance.now();
        
        showPerformanceIndicator('Cargando datos del sistema con optimización...', 'info');
        
        const startDate = document.getElementById('startDateSystemLoad').value;
        const endDate = document.getElementById('endDateSystemLoad').value;

        // Mostrar indicadores de carga progresiva
        showSystemLoadLoadingIndicators();
        
        // Mostrar spinner inmediatamente en la tabla
        const tableBody = document.getElementById('activeTicketsBody');
        if (tableBody) {
            tableBody.innerHTML = '<tr><td colspan="6" class="text-center py-4"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Cargando tickets...</span></div><br>Cargando tickets activos...</td></tr>';
            console.log('📋 Spinner de tabla inicializado');
        }

        // Cargar datos críticos en paralelo con prioridades
        const criticalDataPromises = [
            // Prioridad Alta: Datos que se muestran inmediatamente
            loadDataWithCache(() => getTicketsByStatus(), 'status', {}),
            loadDataWithCache(() => getUnassignedTickets(), 'unassigned', 0)
        ];

        // Prioridad Media: Datos para gráficos
        const graphDataPromises = [
            loadDataWithCache(() => getSatisfactionData(startDate, endDate), 'satisfaction', { average: 0, total: 0, ratings: [] })
        ];

        // Prioridad Baja: Datos para tabla (se puede cargar después)
        const tableDataPromise = getActiveTickets();

        try {
            // Fase 1: Cargar datos críticos primero
            console.log('📊 Cargando datos críticos en paralelo...');
            const [statusData, unassignedCount] = await Promise.all(criticalDataPromises);
            
            // Crear objeto de prioridad básico para compatibilidad con KPIs
            const priorityData = { low: 0, normal: 0, high: 0, urgent: 0 };
            
            // Actualizar KPIs inmediatamente con datos críticos
            updateKPIs(statusData, priorityData, unassignedCount, { average: 0 });
            
            // Renderizar gráfico básico inmediatamente
            renderStatusPieChart(statusData);
            updateChartSummaries(statusData, priorityData);

            console.log('✅ Datos críticos cargados y mostrados');

            // Fase 2: Cargar datos de satisfacción
            console.log('📈 Cargando datos de satisfacción...');
            const [satisfactionData] = await Promise.all(graphDataPromises);
            
            // Actualizar satisfacción
            updateKPIs(statusData, priorityData, unassignedCount, satisfactionData);

            console.log('✅ Datos de satisfacción actualizados');

            // Fase 3: Cargar datos de tabla (menos críticos)
            console.log('📋 Cargando datos de tabla...');
            const activeTickets = await tableDataPromise;
            
            // Validar y procesar tickets activos
            const validActiveTickets = getValidatedTickets(activeTickets);
            console.log(`📊 Tickets activos válidos: ${validActiveTickets.length} de ${activeTickets.length} total`);
            
            // Asegurar que la estructura de datos del sistema esté inicializada
            if (!systemLoadData || typeof systemLoadData.activeTickets === 'undefined') {
                systemLoadData = {
                    activeTickets: [],
                    filteredTickets: []
                };
            }
            
            // Actualizar estructura de datos del sistema
            systemLoadData.activeTickets = validActiveTickets;
            systemLoadData.filteredTickets = validActiveTickets;
            
            console.log('📋 systemLoadData actualizado:', {
                activeTickets: systemLoadData.activeTickets.length,
                filteredTickets: systemLoadData.filteredTickets.length
            });
            
            // Procesar y mostrar tabla - Método directo y robusto
            console.log('📋 Iniciando actualización robusta de tabla...');
            
            // Actualización inmediata directa
            try {
                updateActiveTicketsTableRobust(validActiveTickets);
                console.log('✅ Tabla actualizada exitosamente en el flujo principal');
            } catch (tableError) {
                console.error('❌ Error en actualización de tabla:', tableError);
                
                // Fallback: mostrar mensaje básico en la tabla
                const errorTableBody = document.getElementById('activeTicketsBody');
                if (errorTableBody) {
                    errorTableBody.innerHTML = `<tr><td colspan="6" class="text-center py-4 text-warning">
                        Error cargando tabla: ${tableError.message}<br>
                        <button class="btn btn-sm btn-primary mt-2" onclick="forceTableUpdate()">Reintentar</button>
                    </td></tr>`;
                }
            }

            const endTime = performance.now();
            const duration = endTime - startTime;
            const totalRecords = (Object.values(statusData).reduce((a, b) => a + b, 0)) + activeTickets.length;
            
            console.log(`🎉 Actualización optimizada completada en ${duration.toFixed(2)}ms`);
            
            // Mostrar indicador de rendimiento al usuario
            updatePerformanceIndicator('Carga del Sistema', duration, totalRecords);

        } catch (error) {
            console.error('Error en carga de datos:', error);
            showPerformanceIndicator('Error al cargar datos - Usando caché disponible', 'warning');
            // Mostrar datos del caché si están disponibles
            showFallbackData();
        }

    } catch (error) {
        console.error('Error al actualizar sistema:', error);
    } finally {
        hideSystemLoadLoadingIndicators();
    }
}

// Función para mostrar indicadores de carga progresiva
function showSystemLoadLoadingIndicators() {
    // KPIs
    const kpiElements = ['totalActiveTickets', 'unassignedTickets', 'urgentTickets', 'avgSatisfactionSystemLoad'];
    kpiElements.forEach(id => {
        const element = document.getElementById(id);
        if (element) {
            element.innerHTML = '<div class="spinner-border spinner-border-sm" role="status"></div>';
        }
    });

    // Gráfico (solo el que queda activo)
    const chartElements = ['statusPieChart'];
    chartElements.forEach(id => {
        const element = document.getElementById(id);
        if (element) {
            element.style.opacity = '0.5';
        }
    });
}

// Función para ocultar indicadores de carga
function hideSystemLoadLoadingIndicators() {
    const chartElements = ['statusPieChart'];
    chartElements.forEach(id => {
        const element = document.getElementById(id);
        if (element) {
            element.style.opacity = '1';
        }
    });
}

// Función de fallback para mostrar datos del caché cuando hay errores
function showFallbackData() {
    console.log('📋 Mostrando datos de fallback del caché...');
    
    // Intentar obtener datos expirados del caché
    const fallbackStatus = dataCache.status.data || { new: 0, open: 0, pending: 0, solved: 0, closed: 0 };
    const fallbackPriority = { low: 0, normal: 0, high: 0, urgent: 0 }; // Datos básicos para compatibilidad
    const fallbackUnassigned = dataCache.unassigned.data || 0;
    const fallbackSatisfaction = dataCache.satisfaction.data || { average: 0 };

    // Mostrar datos disponibles en gráfico y KPIs
    updateKPIs(fallbackStatus, fallbackPriority, fallbackUnassigned, fallbackSatisfaction);
    renderStatusPieChart(fallbackStatus);
    updateChartSummaries(fallbackStatus, fallbackPriority);
    
    // Limpiar tabla de tickets activos
    systemLoadData.activeTickets = [];
    systemLoadData.filteredTickets = [];
    updateActiveTicketsTable();
    
    // Mostrar mensaje de advertencia
    console.warn('⚠️ Mostrando datos del caché debido a errores de red');
    showPerformanceIndicator('Datos cargados del caché - Verifique su conexión', 'warning');
}

// Función eliminada: updateIndicators() (duplicado de página de indicadores removida)

// Función para limpiar caché manualmente si es necesario
function clearDataCache() {
    console.log('🧹 Limpiando caché de datos...');
    Object.keys(dataCache).forEach(key => {
        dataCache[key].data = null;
        dataCache[key].lastFetch = null;
    });
    
    // También limpiar caché principal de tickets
    ticketsCache.data = [];
    ticketsCache.lastFetch = null;
    ticketsCache.indices = {};
    
    console.log('✅ Caché limpiado completamente');
}

// Función para mostrar información de rendimiento al usuario
function showPerformanceInfo(loadTime, recordsLoaded) {
    console.log(`📊 Rendimiento: ${loadTime}ms para ${recordsLoaded} registros`);
    
    // Mostrar tooltip o notificación si el tiempo es muy alto
    if (loadTime > 10000) { // Más de 10 segundos
        console.warn('⚠️ Tiempo de carga alto detectado. Considera usar filtros de fecha más restrictivos.');
    } else if (loadTime < 2000) { // Menos de 2 segundos
        console.log('🚀 Excelente rendimiento de carga!');
    }
}

// Función para verificar el estado del caché y sugerir limpieza
function checkCacheHealth() {
    const cacheSize = ticketsCache.data.length;
    const cacheAge = ticketsCache.lastFetch ? Date.now() - ticketsCache.lastFetch : 0;
    
    console.log(`📋 Estado del caché: ${cacheSize} tickets, edad: ${Math.round(cacheAge / 1000)}s`);
    
    // Si el caché es muy grande o muy viejo, sugerir limpieza
    if (cacheSize > 15000) {
        console.warn('⚠️ Caché muy grande (>15K tickets). Considera usar clearDataCache() para optimizar memoria.');
    }
    
    if (cacheAge > 30 * 60 * 1000) { // Más de 30 minutos
        console.warn('⚠️ Caché muy antiguo (>30 min). Los datos podrían estar desactualizados.');
    }
}

// Función para mostrar estadísticas de rendimiento después de cargas importantes
function logPerformanceStats(operation, startTime, recordCount = 0) {
    const endTime = performance.now();
    const duration = endTime - startTime;
    const formattedDuration = duration.toFixed(2);
    
    console.log(`⚡ ${operation} completado en ${formattedDuration}ms`);
    
    if (recordCount > 0) {
        const recordsPerSecond = (recordCount / (duration / 1000)).toFixed(0);
        console.log(`📈 Velocidad: ${recordsPerSecond} registros/segundo`);
    }
    
    // Mostrar advertencias de rendimiento
    if (duration > 15000) {
        console.warn('🐌 Rendimiento lento detectado. Tips para mejorar:');
        console.warn('  • Usar filtros de fecha más restrictivos');
        console.warn('  • Limpiar caché con clearDataCache()');
        console.warn('  • Verificar conexión de red');
    }
    
    return duration;
}

// Funciones para el indicador de rendimiento visual
function showPerformanceIndicator(message, type = 'info') {
    const indicator = document.getElementById('performanceIndicator');
    const text = document.getElementById('performanceText');
    
    if (indicator && text) {
        text.textContent = message;
        indicator.className = `alert alert-${type} alert-dismissible fade show`;
        indicator.classList.remove('d-none');
    }
}

function hidePerformanceIndicator() {
    const indicator = document.getElementById('performanceIndicator');
    if (indicator) {
        indicator.classList.add('d-none');
    }
}

function updatePerformanceIndicator(operation, duration, recordCount = 0) {
    let message = `${operation} completado en ${duration.toFixed(0)}ms`;
    let type = 'success';
    
    if (recordCount > 0) {
        const recordsPerSecond = Math.round(recordCount / (duration / 1000));
        message += ` (${recordCount} registros, ${recordsPerSecond}/seg)`;
    }
    
    if (duration > 10000) {
        type = 'warning';
        message += ' - Considera usar filtros más restrictivos';
    } else if (duration < 2000) {
        type = 'success';
        message += ' - Excelente rendimiento! 🚀';
    }
    
    showPerformanceIndicator(message, type);
    
    // Auto-ocultar después de unos segundos
    setTimeout(() => {
        hidePerformanceIndicator();
    }, type === 'warning' ? 8000 : 5000);
}

// Función de validación del sistema para detectar problemas
function validateSystemHealth() {
    const issues = [];
    const warnings = [];
    
    try {
        // 1. Verificar estructura de caché
        if (!ticketsCache || typeof ticketsCache !== 'object') {
            issues.push('Estructura de caché principal no válida');
        }
        
        if (!ticketsCache.indices || typeof ticketsCache.indices !== 'object') {
            warnings.push('Índices de caché no inicializados - usando filtrado tradicional');
        }
        
        // 2. Verificar índices específicos
        const requiredIndices = ['byDate', 'byStatus', 'byMonth', 'byYear', 'byHour', 'byDay'];
        requiredIndices.forEach(indexName => {
            if (!ticketsCache.indices || !ticketsCache.indices[indexName] || typeof ticketsCache.indices[indexName].get !== 'function') {
                warnings.push(`Índice ${indexName} no disponible`);
            }
        });
        
        // 3. Verificar caché de datos específicos
        Object.keys(dataCache).forEach(cacheKey => {
            if (!dataCache[cacheKey] || typeof dataCache[cacheKey] !== 'object') {
                warnings.push(`Caché de ${cacheKey} no válido`);
            }
        });
        
        // 4. Verificar estado de gráficos
        const chartVariables = [
            { name: 'ticketsPlot', variable: ticketsPlot },
            // ticketsEvolutionPlot eliminado con página de indicadores
            { name: 'dailyPlotDetailed', variable: dailyPlotDetailed },
            { name: 'monthlyPlotDetailed', variable: monthlyPlotDetailed },
            { name: 'comparisonPlot1', variable: comparisonPlot1 },
            { name: 'comparisonPlot2', variable: comparisonPlot2 }
        ];
        
        chartVariables.forEach(chart => {
            if (chart.variable && typeof chart.variable.setData !== 'function') {
                warnings.push(`Gráfico ${chart.name} no tiene método setData válido`);
            }
        });
        
        // 5. Verificar elementos del DOM críticos
        const criticalElements = [
            'performanceIndicator',
            'startDate',
            'endDate'
        ];
        
        criticalElements.forEach(elementId => {
            if (!document.getElementById(elementId)) {
                warnings.push(`Elemento DOM crítico '${elementId}' no encontrado`);
            }
        });
        
        // Generar reporte
        const report = {
            status: issues.length === 0 ? 'healthy' : 'issues',
            issues,
            warnings,
            timestamp: new Date().toISOString(),
            cacheSize: ticketsCache.data ? ticketsCache.data.length : 0,
            indicesStatus: ticketsCache.indices ? Object.keys(ticketsCache.indices).length : 0
        };
        
        // Log del reporte
        if (issues.length > 0) {
            console.error('🚨 Problemas críticos detectados:', issues);
        }
        
        if (warnings.length > 0) {
            console.warn('⚠️ Advertencias del sistema:', warnings);
        }
        
        if (issues.length === 0 && warnings.length === 0) {
            console.log('✅ Sistema saludable - Sin problemas detectados');
        }
        
        return report;
        
    } catch (error) {
        console.error('Error durante validación del sistema:', error);
        return {
            status: 'error',
            issues: ['Error durante validación del sistema'],
            warnings: [],
            error: error.message,
            timestamp: new Date().toISOString()
        };
    }
}

// Función para ejecutar validación automática
function runAutomaticValidation() {
    const report = validateSystemHealth();
    
    // Mostrar mensaje al usuario si hay problemas
    if (report.issues.length > 0) {
        showPerformanceIndicator(
            `Problemas detectados: ${report.issues.length} críticos, ${report.warnings.length} advertencias`,
            'danger'
        );
    } else if (report.warnings.length > 0) {
        showPerformanceIndicator(
            `Sistema funcional con ${report.warnings.length} advertencias menores`,
            'warning'
        );
    }
    
    return report;
}

// Función auxiliar para validar si un objeto es un gráfico válido de uPlot
function isValidChart(chart) {
    return chart && 
           typeof chart === 'object' && 
           typeof chart.setData === 'function' &&
           typeof chart.setSize === 'function';
}

// Función auxiliar para inicializar un gráfico de manera segura
function safeChartUpdate(chart, chartName, data) {
    try {
        if (isValidChart(chart)) {
            chart.setData(data);
            console.log(`✅ ${chartName} actualizado exitosamente`);
            return true;
        } else {
            console.warn(`⚠️ ${chartName} no está disponible o no es válido`);
            return false;
        }
    } catch (error) {
        console.error(`❌ Error actualizando ${chartName}:`, error);
        return false;
    }
}

// Función auxiliar para obtener datos con validación
function getValidatedTickets(tickets) {
    if (!Array.isArray(tickets)) {
        console.warn('Tickets no es un array, retornando array vacío');
        return [];
    }
    
    return tickets.filter(ticket => {
        if (!ticket || typeof ticket !== 'object') {
            return false;
        }
        
        if (!ticket.created_at) {
            return false;
        }
        
        const date = new Date(ticket.created_at);
        if (isNaN(date.getTime())) {
            return false;
        }
        
        return true;
    });
}

// Función mejorada para validación de índices
function validateIndices() {
    if (!ticketsCache.indices || typeof ticketsCache.indices !== 'object') {
        console.log('📋 Inicializando estructura de índices...');
        ticketsCache.indices = {
            byDate: new Map(),
            byStatus: new Map(),
            byMonth: new Map(),
            byYear: new Map(),
            byHour: new Map(),
            byDay: new Map()
        };
        return false;
    }
    
    const requiredIndices = ['byDate', 'byStatus', 'byMonth', 'byYear', 'byHour', 'byDay'];
    const missingIndices = [];
    
    requiredIndices.forEach(indexName => {
        if (!ticketsCache.indices[indexName] || typeof ticketsCache.indices[indexName].get !== 'function') {
            ticketsCache.indices[indexName] = new Map();
            missingIndices.push(indexName);
        }
    });
    
    if (missingIndices.length > 0) {
        console.log(`📋 Índices inicializados: ${missingIndices.join(', ')}`);
    }
    
    return true;
}

// Función de testing para forzar actualización de tabla
function forceTableUpdate() {
    console.log('🧪 FORZANDO ACTUALIZACIÓN DE TABLA...');
    console.log('🧪 systemLoadData:', systemLoadData);
    
    if (!systemLoadData.activeTickets || systemLoadData.activeTickets.length === 0) {
        console.log('🧪 No hay tickets activos, creando datos de prueba...');
        systemLoadData.activeTickets = [
            {
                id: 'test1',
                subject: 'Ticket de prueba 1',
                status: 'open',
                priority: 'normal',
                assignee_id: null,
                created_at: new Date().toISOString()
            },
            {
                id: 'test2',
                subject: 'Ticket de prueba 2 con asunto más largo para verificar truncado',
                status: 'pending',
                priority: 'high',
                assignee_id: '12345',
                created_at: new Date(Date.now() - 86400000).toISOString() // Ayer
            }
        ];
        systemLoadData.filteredTickets = systemLoadData.activeTickets;
    }
    
    console.log('🧪 Llamando updateActiveTicketsTableRobust...');
    updateActiveTicketsTableRobust(systemLoadData.activeTickets);
}

// Función de debug completo
function debugTableStatus() {
    console.log('🔍 DEBUG ROBUSTO - Estado completo del sistema:');
    console.log('='.repeat(50));
    
    // Estado de datos
    console.log('📊 DATOS:');
    console.log('- systemLoadData exists:', !!systemLoadData);
    console.log('- activeTickets:', systemLoadData?.activeTickets?.length || 0);
    console.log('- filteredTickets:', systemLoadData?.filteredTickets?.length || 0);
    console.log('- currentPage:', systemLoadData?.currentPage || 'undefined');
    
    // Estado del DOM
    console.log('🏗️ DOM:');
    const tbody = document.getElementById('activeTicketsBody');
    const info = document.getElementById('ticketsInfo');
    const pagination = document.getElementById('ticketsPagination');
    
    console.log('- activeTicketsBody:', tbody ? '✅ Encontrado' : '❌ No encontrado');
    console.log('- ticketsInfo:', info ? '✅ Encontrado' : '❌ No encontrado');
    console.log('- ticketsPagination:', pagination ? '✅ Encontrado' : '❌ No encontrado');
    
    if (tbody) {
        console.log('- Contenido actual tbody:', tbody.innerHTML.substring(0, 200) + '...');
    }
    
    // Sample data
    if (systemLoadData?.activeTickets?.length > 0) {
        console.log('📋 SAMPLE TICKET:', systemLoadData.activeTickets[0]);
    }
    
    console.log('='.repeat(50));
    
    // Test actualización inmediata
    if (systemLoadData?.activeTickets?.length > 0) {
        console.log('🚀 Ejecutando test de actualización...');
        updateActiveTicketsTableRobust(systemLoadData.activeTickets);
    }
}

// Exponer funciones globalmente para debugging
window.debugTableUpdate = function() {
    console.log('🐛 DEBUG: Estado actual del sistema');
    console.log('🐛 systemLoadData:', systemLoadData);
    console.log('🐛 activeTickets count:', systemLoadData.activeTickets?.length || 0);
    console.log('🐛 filteredTickets count:', systemLoadData.filteredTickets?.length || 0);
    
    const tbody = document.getElementById('activeTicketsBody');
    console.log('🐛 tbody element:', tbody);
    console.log('🐛 tbody innerHTML length:', tbody?.innerHTML?.length || 0);
    
    console.log('🐛 Intentando actualizar tabla...');
    updateActiveTicketsTable();
};

window.debugTableStatus = debugTableStatus;
window.forceTableUpdate = forceTableUpdate;
window.updateActiveTicketsTableRobust = updateActiveTicketsTableRobust;

// Función específica para debug del estado de carga
window.debugLoadingState = function() {
    console.log('🔍 ESTADO DE CARGA - Debug detallado:');
    console.log('='.repeat(60));
    
    // Variables globales
    console.log('📊 VARIABLES GLOBALES:');
    console.log('- systemLoadData:', systemLoadData);
    console.log('- dataCache:', dataCache);
    
    // Estado del DOM de la tabla
    console.log('🏗️ ELEMENTOS DOM DE TABLA:');
    const tbody = document.getElementById('activeTicketsBody');
    const info = document.getElementById('ticketsInfo');
    const search = document.getElementById('ticketSearch');
    const perPage = document.getElementById('ticketsPerPage');
    
    console.log('- activeTicketsBody:', tbody ? {
        exists: true,
        innerHTML_length: tbody.innerHTML.length,
        children_count: tbody.children.length
    } : 'NO ENCONTRADO');
    
    console.log('- ticketsInfo:', info ? { 
        exists: true, 
        text: info.textContent 
    } : 'NO ENCONTRADO');
    
    console.log('- ticketSearch:', search ? { 
        exists: true, 
        value: search.value 
    } : 'NO ENCONTRADO');
    
    console.log('- ticketsPerPage:', perPage ? { 
        exists: true, 
        value: perPage.value 
    } : 'NO ENCONTRADO');
    
    // Estado de fechas
    console.log('📅 FECHAS:');
    const startDate = document.getElementById('startDateSystemLoad');
    const endDate = document.getElementById('endDateSystemLoad');
    console.log('- startDate:', startDate ? startDate.value : 'NO ENCONTRADO');
    console.log('- endDate:', endDate ? endDate.value : 'NO ENCONTRADO');
    
    console.log('='.repeat(60));
    
    // Test rápido de actualización
    if (systemLoadData.activeTickets && systemLoadData.activeTickets.length > 0) {
        console.log('🚀 EJECUTANDO TEST DE ACTUALIZACIÓN...');
        updateActiveTicketsTableRobust(systemLoadData.activeTickets);
    } else {
        console.log('⚠️ NO HAY DATOS PARA TEST - Ejecute updateSystemLoad() primero');
    }
};

// ========== FUNCIONES PARA LA PÁGINA DE DISPARADORES ==========

// Variables globales para la página de disparadores
let triggersData = {
    triggers: [],
    customFields: [],
    filteredTriggers: [],
    currentPage: 1,
    itemsPerPage: 25,
    totalPages: 0,
    isLoading: false,
    triggerExecutions: new Map(), // Cache de ejecuciones por trigger ID
    executionsLoading: false
};

// Inicializar la página de disparadores
function initTriggersPage() {
    console.log('🎯 Inicializando página de disparadores...');
    
    // Event listeners para filtros
    setupTriggerFilters();
    
    // Event listeners para paginación
    setupTriggerPagination();
    
    // Event listeners para botones
    setupTriggerButtons();
    
    console.log('✅ Página de disparadores inicializada');
}

// Configurar filtros de disparadores
function setupTriggerFilters() {
    const filterStatus = document.getElementById('filterTriggerStatus');
    const filterTitle = document.getElementById('filterTriggerTitle');
    const filterFunctionality = document.getElementById('filterTriggerFunctionality');
    const filterCustomFields = document.getElementById('filterCustomFields');
    const itemsPerPage = document.getElementById('triggersPerPage');
    
    // Debounce para filtros de texto
    const debouncedFilter = debounce(applyTriggerFilters, 300);
    
    if (filterStatus) {
        filterStatus.addEventListener('change', applyTriggerFilters);
    }
    
    if (filterTitle) {
        filterTitle.addEventListener('input', debouncedFilter);
    }
    
    if (filterFunctionality) {
        filterFunctionality.addEventListener('input', debouncedFilter);
    }
    
    if (filterCustomFields) {
        filterCustomFields.addEventListener('input', debouncedFilter);
    }
    
    if (itemsPerPage) {
        itemsPerPage.addEventListener('change', () => {
            triggersData.itemsPerPage = parseInt(itemsPerPage.value);
            triggersData.currentPage = 1;
            applyTriggerFilters();
        });
    }
}

// Configurar paginación de disparadores
function setupTriggerPagination() {
    // La paginación se manejará dinámicamente en updateTriggerPagination()
}

// Configurar botones de disparadores
function setupTriggerButtons() {
    const refreshBtn = document.getElementById('refreshTriggers');
    const clearFiltersBtn = document.getElementById('clearTriggerFilters');
    const exportBtn = document.getElementById('exportTriggers');
    
    if (refreshBtn) {
        refreshBtn.addEventListener('click', () => {
            console.log('🔄 Refrescando disparadores...');
            loadTriggers(true);
        });
    }
    
    if (clearFiltersBtn) {
        clearFiltersBtn.addEventListener('click', clearTriggerFilters);
    }
    
    if (exportBtn) {
        exportBtn.addEventListener('click', exportTriggersToCSV);
    }
    
    // Botón para refrescar solo conteos de ejecuciones
    const refreshExecutionsBtn = document.getElementById('refreshTriggerExecutions');
    if (refreshExecutionsBtn) {
        refreshExecutionsBtn.addEventListener('click', () => {
            console.log('🔄 Refrescando conteos de ejecuciones...');
            loadTriggerExecutionCounts();
        });
    }
}

// Cargar disparadores desde Zendesk usando ZAF
async function loadTriggers(forceRefresh = false) {
    if (triggersData.isLoading && !forceRefresh) {
        console.log('⏳ Ya hay una carga en progreso...');
        return;
    }
    
    triggersData.isLoading = true;
    showTriggersLoadingState();
    
    try {
        console.log('🎯 Cargando disparadores desde Zendesk...');
        const startTime = performance.now();
        
        // Cargar triggers y custom fields en paralelo
        const [triggers, customFields] = await Promise.all([
            loadAllTriggers(),
            loadCustomFields()
        ]);
        
        // Procesar datos
        triggersData.triggers = triggers;
        triggersData.customFields = customFields;
        
        // Mapear custom fields para fácil acceso
        const customFieldsMap = new Map();
        customFields.forEach(field => {
            customFieldsMap.set(field.id.toString(), field);
        });
        triggersData.customFieldsMap = customFieldsMap;
        
        // Procesar triggers con información adicional
        triggersData.triggers = triggers.map(trigger => ({
            ...trigger,
            functionality: generateTriggerFunctionality(trigger, customFieldsMap),
            customFieldsUsed: extractCustomFieldsUsed(trigger, customFieldsMap),
            processedConditions: processConditions(trigger.conditions, customFieldsMap),
            processedActions: processActions(trigger.actions, customFieldsMap)
        }));
        
        const endTime = performance.now();
        console.log(`✅ Cargados ${triggers.length} disparadores en ${(endTime - startTime).toFixed(2)}ms`);
        
        // Cargar conteos de ejecuciones en segundo plano
        loadTriggerExecutionCounts();
        
        // Aplicar filtros y mostrar resultados
        applyTriggerFilters();
        updateTriggersCounter();
        
    } catch (error) {
        console.error('❌ Error cargando disparadores:', error);
        showTriggersErrorState(error);
    } finally {
        triggersData.isLoading = false;
    }
}

// Obtener tickets desde caché o API
async function getTicketsForExecutionCount() {
    console.log('🎫 Obteniendo tickets para conteo de ejecuciones...');
    
    // Intentar usar tickets desde caché global si están disponibles
    if (ticketsCache && ticketsCache.data && ticketsCache.data.length > 0) {
        const cacheAge = Date.now() - (ticketsCache.lastFetch || 0);
        const maxAge = 5 * 60 * 1000; // 5 minutos
        
        if (cacheAge < maxAge) {
            console.log(`✅ Usando ${ticketsCache.data.length} tickets desde caché (${(cacheAge / 1000 / 60).toFixed(1)} min de antigüedad)`);
            return ticketsCache.data;
        } else {
            console.log(`⏰ Caché expirado (${(cacheAge / 1000 / 60).toFixed(1)} min), obteniendo tickets frescos...`);
        }
    } else {
        console.log('📭 No hay caché de tickets disponible, cargando desde API...');
    }
    
    // Si no hay caché válido, obtener tickets recientes
    try {
        console.log('🔄 Cargando tickets recientes desde API...');
        
        // Intentar con un enfoque más simple primero - tickets más recientes
        const response = await client.request({
            url: '/api/v2/tickets.json?per_page=100&sort_by=updated_at&sort_order=desc',
            type: 'GET'
        });
        
        const tickets = response.tickets || [];
        console.log(`✅ Obtenidos ${tickets.length} tickets recientes para análisis`);
        
        if (tickets.length === 0) {
            console.warn('⚠️ No se obtuvieron tickets desde la API');
        } else {
            console.log(`📊 Rango de fechas de tickets: desde ${tickets[tickets.length-1]?.created_at} hasta ${tickets[0]?.created_at}`);
        }
        
        return tickets;
        
    } catch (error) {
        console.error('❌ Error obteniendo tickets:', error);
        console.log('🔍 Detalles del error:', {
            status: error.status,
            message: error.message,
            responseText: error.responseText
        });
        return [];
    }
}

// Cargar conteos de ejecuciones de triggers
async function loadTriggerExecutionCounts() {
    if (triggersData.executionsLoading) {
        console.log('⏳ Ya se están cargando las ejecuciones...');
        return;
    }
    
    triggersData.executionsLoading = true;
    console.log('📊 Iniciando conteo de ejecuciones de triggers...');
    
    // Timeout para evitar que se quede colgado indefinidamente
    const timeoutId = setTimeout(() => {
        console.warn('⏰ Timeout: Deteniendo conteo de ejecuciones por exceso de tiempo');
        triggersData.executionsLoading = false;
        renderTriggersTable();
    }, 2 * 60 * 1000); // 2 minutos timeout
    
    try {
        // Obtener tickets recientes
        console.log('🎫 Obteniendo tickets...');
        const tickets = await getTicketsForExecutionCount();
        
        if (tickets.length === 0) {
            console.warn('⚠️ No se encontraron tickets para analizar');
            triggersData.triggerExecutions.clear();
            renderTriggersTable();
            return;
        }
        
        console.log(`🔍 Analizando auditorías de ${tickets.length} tickets...`);
        
        // Procesar una muestra más pequeña primero para debugging
        const sampleSize = Math.min(tickets.length, 20);
        const sampleTickets = tickets.slice(0, sampleSize);
        
        console.log(`🧪 Procesando muestra de ${sampleSize} tickets primero...`);
        
        const executionCounts = new Map();
        let processedTickets = 0;
        let totalErrors = 0;
        
        // Procesar tickets secuencialmente para mejor debugging
        for (let i = 0; i < sampleTickets.length; i++) {
            const ticket = sampleTickets[i];
            console.log(`🔍 Procesando ticket ${ticket.id} (${i + 1}/${sampleTickets.length})`);
            
            try {
                const ticketExecutions = await countTriggerExecutionsForTicket(ticket.id);
                
                if (ticketExecutions && ticketExecutions.size > 0) {
                    console.log(`✅ Ticket ${ticket.id}: ${ticketExecutions.size} triggers encontrados`);
                    ticketExecutions.forEach((count, triggerId) => {
                        executionCounts.set(triggerId, (executionCounts.get(triggerId) || 0) + count);
                        console.log(`   📊 Trigger ${triggerId}: +${count} ejecuciones`);
                    });
                } else {
                    console.log(`ℹ️ Ticket ${ticket.id}: sin ejecuciones de triggers`);
                }
                
                processedTickets++;
                
                // Actualizar interfaz cada 5 tickets en modo debug
                if (processedTickets % 5 === 0) {
                    triggersData.triggerExecutions = new Map(executionCounts);
                    renderTriggersTable();
                }
                
            } catch (error) {
                totalErrors++;
                console.warn(`⚠️ Error procesando ticket ${ticket.id}:`, error.message);
                
                // Si hay demasiados errores, detener
                if (totalErrors > 5) {
                    console.error('❌ Demasiados errores, deteniendo análisis');
                    break;
                }
            }
            
            // Pausa más larga para debugging
            await new Promise(resolve => setTimeout(resolve, 200));
        }
        
        // Guardar resultados
        triggersData.triggerExecutions = executionCounts;
        
        console.log(`✅ Conteo completado. ${processedTickets} tickets procesados, ${totalErrors} errores.`);
        console.log(`🎯 Ejecuciones encontradas:`, 
            Array.from(executionCounts.entries()).map(([id, count]) => `Trigger ${id}: ${count}`));
        
        // Si no se encontraron ejecuciones, inicializar todos los triggers con 0
        if (executionCounts.size === 0) {
            console.warn('⚠️ No se encontraron ejecuciones de triggers en la muestra analizada');
            console.log('🔄 Inicializando todos los triggers con 0 ejecuciones...');
            
            // Inicializar todos los triggers conocidos con 0 ejecuciones
            triggersData.triggers.forEach(trigger => {
                executionCounts.set(trigger.id.toString(), 0);
            });
            
            triggersData.triggerExecutions = executionCounts;
            console.log(`✅ Inicializados ${executionCounts.size} triggers con 0 ejecuciones`);
        }
        
        // Actualizar tabla final
        renderTriggersTable();
        
    } catch (error) {
        console.error('❌ Error global contando ejecuciones de triggers:', error);
        console.log('🔄 Aplicando fallback: inicializando todos los triggers con 0 ejecuciones...');
        
        // Mostrar los triggers con 0 ejecuciones en lugar de error
        triggersData.triggerExecutions.clear();
        
        // Inicializar todos los triggers conocidos con 0 ejecuciones como fallback
        triggersData.triggers.forEach(trigger => {
            triggersData.triggerExecutions.set(trigger.id.toString(), 0);
        });
        
        console.log(`✅ Fallback aplicado: ${triggersData.triggerExecutions.size} triggers inicializados con 0 ejecuciones`);
        renderTriggersTable();
    } finally {
        clearTimeout(timeoutId);
        triggersData.executionsLoading = false;
        
        // Asegurar que siempre se muestre algo, incluso si hay errores
        if (triggersData.triggerExecutions.size === 0) {
            console.log('🛟 Último recurso: aplicando fallback final...');
            triggersData.triggers.forEach(trigger => {
                triggersData.triggerExecutions.set(trigger.id.toString(), 0);
            });
            renderTriggersTable();
        }
    }
}

// Contar ejecuciones de triggers para un ticket específico
async function countTriggerExecutionsForTicket(ticketId) {
    try {
        console.log(`   🔍 Obteniendo auditorías del ticket ${ticketId}...`);
        
        const response = await client.request({
            url: `/api/v2/tickets/${ticketId}/audits.json`,
            type: 'GET'
        });
        
        const audits = response.audits || [];
        const triggerCounts = new Map();
        let totalEvents = 0;
        let notificationEvents = 0;
        let ruleEvents = 0;
        
        console.log(`   📋 Analizando ${audits.length} auditorías del ticket ${ticketId}...`);
        
        audits.forEach(audit => {
            if (audit.events && Array.isArray(audit.events)) {
                audit.events.forEach(event => {
                    totalEvents++;
                    
                    // Debug: mostrar algunos eventos para entender la estructura
                    if (totalEvents <= 5) {
                        console.log(`   📄 Evento tipo: ${event.type}, via: ${event.via?.channel}, trigger_id: ${event.trigger_id}`);
                        console.log(`   📋 Todas las propiedades del evento:`, Object.keys(event));
                    }
                    
                    // Buscar triggers en diferentes tipos de eventos
                    let foundTriggerId = null;
                    
                    // Método 1: Eventos de Notification con reglas
                    if (event.type === 'Notification') {
                        notificationEvents++;
                        
                        // Contabilizar eventos por reglas
                        if (event.via && event.via.channel === 'rule') {
                            ruleEvents++;
                            
                            // Mostrar detalles completos del evento para debugging
                            console.log(`   🔍 Evento de regla completo:`, JSON.stringify(event, null, 2));
                            
                            // Buscar trigger_id en diferentes ubicaciones posibles
                            let triggerId = null;
                            
                            if (event.trigger_id) {
                                triggerId = event.trigger_id.toString();
                            } else if (event.via && event.via.source && event.via.source.id) {
                                triggerId = event.via.source.id.toString();
                                console.log(`   🔍 Trigger ID encontrado en via.source.id: ${triggerId}`);
                            } else if (event.via && event.via.source && event.via.source.trigger_id) {
                                triggerId = event.via.source.trigger_id.toString();
                                console.log(`   🔍 Trigger ID encontrado en via.source.trigger_id: ${triggerId}`);
                            } else if (event.body && typeof event.body === 'string') {
                                // Buscar en el cuerpo del evento
                                const triggerMatch = event.body.match(/trigger[_\s]*(?:id)?[_\s]*:?\s*(\d+)/i);
                                if (triggerMatch) {
                                    triggerId = triggerMatch[1];
                                    console.log(`   🔍 Trigger ID encontrado en body: ${triggerId}`);
                                }
                            }
                            
                            if (triggerId) {
                                foundTriggerId = triggerId;
                            } else {
                                console.log(`   ⚠️ Evento de regla sin trigger_id identificable`);
                                // Mostrar todas las propiedades del objeto via para análisis
                                console.log(`   📋 Propiedades de via:`, Object.keys(event.via || {}));
                                if (event.via && event.via.source) {
                                    console.log(`   📋 Propiedades de via.source:`, Object.keys(event.via.source));
                                }
                            }
                        }
                    }
                    
                    // Método 2: Buscar en otros tipos de eventos que podrían contener info de triggers
                    if (!foundTriggerId) {
                        // Buscar en eventos de Change que podrían tener información de triggers
                        if (event.type === 'Change' && event.metadata && event.metadata.system) {
                            const systemData = event.metadata.system;
                            if (systemData.trigger_id) {
                                foundTriggerId = systemData.trigger_id.toString();
                                console.log(`   🔍 Trigger ID encontrado en metadata.system: ${foundTriggerId}`);
                            }
                        }
                        
                        // Buscar en cualquier propiedad que contenga 'trigger'
                        Object.keys(event).forEach(key => {
                            if (key.toLowerCase().includes('trigger') && event[key] && !foundTriggerId) {
                                if (typeof event[key] === 'number' || typeof event[key] === 'string') {
                                    foundTriggerId = event[key].toString();
                                    console.log(`   🔍 Trigger ID encontrado en ${key}: ${foundTriggerId}`);
                                }
                            }
                        });
                        
                        // Buscar recursivamente en objetos anidados
                        if (!foundTriggerId && typeof event === 'object') {
                            const searchForTrigger = (obj, path = '') => {
                                if (foundTriggerId) return;
                                
                                Object.keys(obj || {}).forEach(key => {
                                    if (foundTriggerId) return;
                                    
                                    const fullPath = path ? `${path}.${key}` : key;
                                    const value = obj[key];
                                    
                                    if (key.toLowerCase().includes('trigger') && (typeof value === 'number' || typeof value === 'string')) {
                                        foundTriggerId = value.toString();
                                        console.log(`   🔍 Trigger ID encontrado en ${fullPath}: ${foundTriggerId}`);
                                    } else if (typeof value === 'object' && value !== null && path.split('.').length < 3) {
                                        // Limitar profundidad para evitar recursión infinita
                                        searchForTrigger(value, fullPath);
                                    }
                                });
                            };
                            
                            searchForTrigger(event);
                        }
                    }
                    
                    // Si encontramos un trigger ID, contabilizarlo
                    if (foundTriggerId) {
                        triggerCounts.set(foundTriggerId, (triggerCounts.get(foundTriggerId) || 0) + 1);
                        console.log(`   ✅ Encontrada ejecución del trigger ${foundTriggerId}`);
                    }
                });
            }
        });
        
        console.log(`   📊 Ticket ${ticketId}: ${totalEvents} eventos totales, ${notificationEvents} notificaciones, ${ruleEvents} por reglas, ${triggerCounts.size} triggers únicos`);
        
        return triggerCounts;
        
    } catch (error) {
        console.warn(`⚠️ Error obteniendo auditorías del ticket ${ticketId}:`, {
            status: error.status,
            message: error.message,
            url: error.url
        });
        
        // Si es error de permisos, es normal
        if (error.status === 403) {
            console.log(`   🔒 Sin permisos para auditorías del ticket ${ticketId}`);
        } else if (error.status === 404) {
            console.log(`   🚫 Ticket ${ticketId} no encontrado`);
        }
        
        return new Map();
    }
}

// Cargar todos los triggers paginando automáticamente
async function loadAllTriggers() {
    const allTriggers = [];
    let hasMore = true;
    let nextPage = null;
    let pageCount = 0;
    
    while (hasMore && pageCount < 50) { // Límite de seguridad
        try {
            const url = nextPage || '/api/v2/triggers.json?per_page=100';
            console.log(`📄 Cargando página ${pageCount + 1} de triggers...`);
            
            const response = await client.request({
                url: url,
                type: 'GET'
            });
            
            if (response.triggers && response.triggers.length > 0) {
                allTriggers.push(...response.triggers);
                console.log(`📊 Página ${pageCount + 1}: ${response.triggers.length} triggers (Total: ${allTriggers.length})`);
            }
            
            hasMore = !!response.next_page;
            nextPage = response.next_page;
            pageCount++;
            
            // Pequeña pausa para no sobrecargar la API
            if (hasMore) {
                await new Promise(resolve => setTimeout(resolve, 100));
            }
            
        } catch (error) {
            console.error(`❌ Error cargando página ${pageCount + 1}:`, error);
            hasMore = false;
        }
    }
    
    console.log(`🎯 Total de triggers cargados: ${allTriggers.length}`);
    return allTriggers;
}

// Cargar custom fields
async function loadCustomFields() {
    try {
        console.log('🔧 Cargando custom fields...');
        
        const response = await client.request({
            url: '/api/v2/ticket_fields.json?per_page=100',
            type: 'GET'
        });
        
        const customFields = response.ticket_fields || [];
        console.log(`✅ Cargados ${customFields.length} custom fields`);
        
        return customFields;
        
    } catch (error) {
        console.error('❌ Error cargando custom fields:', error);
        return [];
    }
}

// Generar funcionalidad del trigger
function generateTriggerFunctionality(trigger, customFieldsMap) {
    // Si tiene descripción, usarla directamente
    if (trigger.description && trigger.description.trim()) {
        return trigger.description.trim();
    }
    
    // Generar resumen automático basado en condiciones y acciones
    const summary = [];
    
    // Procesar acciones principales
    if (trigger.actions && trigger.actions.length > 0) {
        const mainActions = trigger.actions.slice(0, 3); // Primeras 3 acciones
        
        mainActions.forEach(action => {
            if (action.field && action.value !== undefined) {
                const fieldName = getFieldDisplayName(action.field, customFieldsMap);
                const actionText = formatActionForSummary(action, fieldName);
                if (actionText) {
                    summary.push(actionText);
                }
            }
        });
    }
    
    // Agregar condiciones clave si no hay acciones claras
    if (summary.length === 0 && trigger.conditions) {
        const keyConditions = getKeyConditions(trigger.conditions, customFieldsMap);
        if (keyConditions.length > 0) {
            summary.push(`Se ejecuta cuando: ${keyConditions.join(' y ')}`);
        }
    }
    
    return summary.length > 0 ? summary.join('. ') : 'Trigger personalizado sin descripción específica';
}

// Formatear acción para resumen
function formatActionForSummary(action, fieldName) {
    if (!action.field || action.value === undefined) return '';
    
    switch (action.field) {
        case 'priority':
            return `Asigna prioridad "${action.value}"`;
        case 'status':
            return `Cambia estado a "${action.value}"`;
        case 'assignee_id':
            return action.value ? `Asigna al agente ID ${action.value}` : 'Desasigna el ticket';
        case 'group_id':
            return `Asigna al grupo ID ${action.value}`;
        case 'comment':
            return 'Agrega comentario automático';
        case 'comment_value':
            return 'Agrega comentario con valor específico';
        default:
            if (action.field.startsWith('custom_fields_')) {
                return `Establece "${fieldName}" como "${action.value}"`;
            }
            return `Modifica ${fieldName}: "${action.value}"`;
    }
}

// Obtener condiciones clave para el resumen
function getKeyConditions(conditions, customFieldsMap) {
    const keyConditions = [];
    
    ['all', 'any'].forEach(conditionType => {
        if (conditions[conditionType] && conditions[conditionType].length > 0) {
            conditions[conditionType].slice(0, 2).forEach(condition => {
                if (condition.field && condition.value !== undefined) {
                    const fieldName = getFieldDisplayName(condition.field, customFieldsMap);
                    const conditionText = formatConditionForSummary(condition, fieldName);
                    if (conditionText) {
                        keyConditions.push(conditionText);
                    }
                }
            });
        }
    });
    
    return keyConditions;
}

// Formatear condición para resumen
function formatConditionForSummary(condition, fieldName) {
    if (!condition.operator || condition.value === undefined) return '';
    
    switch (condition.operator) {
        case 'is':
            return `${fieldName} es "${condition.value}"`;
        case 'is_not':
            return `${fieldName} no es "${condition.value}"`;
        case 'greater_than':
            return `${fieldName} mayor que ${condition.value}`;
        case 'less_than':
            return `${fieldName} menor que ${condition.value}`;
        case 'contains':
            return `${fieldName} contiene "${condition.value}"`;
        default:
            return `${fieldName} ${condition.operator} "${condition.value}"`;
    }
}

// Obtener nombre de campo para mostrar
function getFieldDisplayName(fieldId, customFieldsMap) {
    // Campos estándar de Zendesk
    const standardFields = {
        'priority': 'Prioridad',
        'status': 'Estado',
        'type': 'Tipo',
        'assignee_id': 'Asignado a',
        'group_id': 'Grupo',
        'requester_id': 'Solicitante',
        'organization_id': 'Organización',
        'subject': 'Asunto',
        'description': 'Descripción',
        'tags': 'Etiquetas'
    };
    
    if (standardFields[fieldId]) {
        return standardFields[fieldId];
    }
    
    // Custom fields
    if (fieldId.startsWith('custom_fields_')) {
        const customFieldId = fieldId.replace('custom_fields_', '');
        const customField = customFieldsMap.get(customFieldId);
        if (customField) {
            return customField.title || customField.raw_title || `Campo personalizado ${customFieldId}`;
        }
        return `Campo personalizado ${customFieldId}`;
    }
    
    return fieldId;
}

// Extraer custom fields usados en el trigger
function extractCustomFieldsUsed(trigger, customFieldsMap) {
    const customFieldsUsed = new Map();
    
    // Procesar condiciones
    ['all', 'any'].forEach(conditionType => {
        if (trigger.conditions && trigger.conditions[conditionType]) {
            trigger.conditions[conditionType].forEach(condition => {
                if (condition.field && condition.field.startsWith('custom_fields_')) {
                    const fieldId = condition.field.replace('custom_fields_', '');
                    const field = customFieldsMap.get(fieldId);
                    if (field && condition.value !== undefined) {
                        customFieldsUsed.set(fieldId, {
                            name: field.title || field.raw_title || `Campo ${fieldId}`,
                            value: condition.value,
                            type: 'condition'
                        });
                    }
                }
            });
        }
    });
    
    // Procesar acciones
    if (trigger.actions) {
        trigger.actions.forEach(action => {
            if (action.field && action.field.startsWith('custom_fields_')) {
                const fieldId = action.field.replace('custom_fields_', '');
                const field = customFieldsMap.get(fieldId);
                if (field && action.value !== undefined) {
                    customFieldsUsed.set(fieldId, {
                        name: field.title || field.raw_title || `Campo ${fieldId}`,
                        value: action.value,
                        type: 'action'
                    });
                }
            }
        });
    }
    
    return Array.from(customFieldsUsed.values());
}

// Procesar condiciones para mostrar
function processConditions(conditions, customFieldsMap) {
    if (!conditions) return { all: [], any: [] };
    
    const processed = { all: [], any: [] };
    
    ['all', 'any'].forEach(conditionType => {
        if (conditions[conditionType] && Array.isArray(conditions[conditionType])) {
            processed[conditionType] = conditions[conditionType].map(condition => ({
                ...condition,
                fieldDisplayName: getFieldDisplayName(condition.field, customFieldsMap),
                displayText: formatConditionDisplay(condition, customFieldsMap)
            }));
        }
    });
    
    return processed;
}

// Formatear condición para mostrar
function formatConditionDisplay(condition, customFieldsMap) {
    const fieldName = getFieldDisplayName(condition.field, customFieldsMap);
    const operator = condition.operator || 'is';
    const value = condition.value || '';
    
    return `${fieldName} ${operator} "${value}"`;
}

// Procesar acciones para mostrar
function processActions(actions, customFieldsMap) {
    if (!actions || !Array.isArray(actions)) return [];
    
    return actions.map(action => ({
        ...action,
        fieldDisplayName: getFieldDisplayName(action.field, customFieldsMap),
        displayText: formatActionDisplay(action, customFieldsMap)
    }));
}

// Formatear acción para mostrar
function formatActionDisplay(action, customFieldsMap) {
    const fieldName = getFieldDisplayName(action.field, customFieldsMap);
    const value = action.value || '';
    
    return `${fieldName}: "${value}"`;
}

// Aplicar filtros a los disparadores
function applyTriggerFilters() {
    const filterStatus = document.getElementById('filterTriggerStatus')?.value || '';
    const filterTitle = document.getElementById('filterTriggerTitle')?.value || '';
    const filterFunctionality = document.getElementById('filterTriggerFunctionality')?.value || '';
    const filterCustomFields = document.getElementById('filterCustomFields')?.value || '';
    
    let filtered = [...triggersData.triggers];
    
    // Filtro por estado
    if (filterStatus === 'active') {
        filtered = filtered.filter(trigger => trigger.active === true);
    } else if (filterStatus === 'inactive') {
        filtered = filtered.filter(trigger => trigger.active === false);
    }
    
    // Filtro por título
    if (filterTitle) {
        const titleLower = filterTitle.toLowerCase();
        filtered = filtered.filter(trigger => 
            trigger.title && trigger.title.toLowerCase().includes(titleLower)
        );
    }
    
    // Filtro por funcionalidad
    if (filterFunctionality) {
        const functionalityLower = filterFunctionality.toLowerCase();
        filtered = filtered.filter(trigger => 
            trigger.functionality && trigger.functionality.toLowerCase().includes(functionalityLower)
        );
    }
    
    // Filtro por campos personalizados
    if (filterCustomFields) {
        const customFieldsLower = filterCustomFields.toLowerCase();
        filtered = filtered.filter(trigger => {
            if (!trigger.customFieldsUsed || trigger.customFieldsUsed.length === 0) return false;
            return trigger.customFieldsUsed.some(field => 
                field.name.toLowerCase().includes(customFieldsLower) ||
                field.value.toString().toLowerCase().includes(customFieldsLower)
            );
        });
    }
    
    // Ordenar por updated_at descendente
    filtered.sort((a, b) => new Date(b.updated_at) - new Date(a.updated_at));
    
    triggersData.filteredTriggers = filtered;
    triggersData.currentPage = 1;
    triggersData.totalPages = Math.ceil(filtered.length / triggersData.itemsPerPage);
    
    renderTriggersTable();
    updateTriggerPagination();
    updateFilterStatus();
}

// Limpiar filtros
function clearTriggerFilters() {
    document.getElementById('filterTriggerStatus').value = '';
    document.getElementById('filterTriggerTitle').value = '';
    document.getElementById('filterTriggerFunctionality').value = '';
    document.getElementById('filterCustomFields').value = '';
    
    applyTriggerFilters();
}

// Renderizar tabla de disparadores
function renderTriggersTable() {
    const tableBody = document.getElementById('triggersTableBody');
    if (!tableBody) return;
    
    if (triggersData.filteredTriggers.length === 0) {
        tableBody.innerHTML = `
            <tr>
                <td colspan="9" class="text-center py-4">
                    <div class="text-muted">
                        <i class="fas fa-search mb-2" style="font-size: 2rem;"></i>
                        <div>No se encontraron disparadores con los filtros aplicados</div>
                        <small>Intenta modificar los criterios de búsqueda</small>
                    </div>
                </td>
            </tr>
        `;
        return;
    }
    
    const startIndex = (triggersData.currentPage - 1) * triggersData.itemsPerPage;
    const endIndex = startIndex + triggersData.itemsPerPage;
    const pageItems = triggersData.filteredTriggers.slice(startIndex, endIndex);
    
    const rows = pageItems.map(trigger => createTriggerRow(trigger)).join('');
    tableBody.innerHTML = rows;
    
    // Actualizar información de paginación
    updateTriggersInfo();
}

// Crear fila de la tabla para un disparador
function createTriggerRow(trigger) {
    const isInactive = !trigger.active;
    const rowClass = isInactive ? 'trigger-inactive' : '';
    
    // Debug: Verificar datos del trigger
    if (isInactive) {
        console.log('🔍 Trigger inactivo:', {
            id: trigger.id,
            title: trigger.title,
            active: trigger.active,
            processedConditions: trigger.processedConditions,
            processedActions: trigger.processedActions,
            functionality: trigger.functionality,
            customFieldsUsed: trigger.customFieldsUsed
        });
    }
    
    // Asegurar que todos los campos tengan valores válidos
    const safeTitle = trigger.title || 'Sin título';
    const safeConditions = trigger.processedConditions || { all: [], any: [] };
    const safeActions = trigger.processedActions || [];
    const safeFunctionality = trigger.functionality || 'Sin descripción';
    const safeCustomFields = trigger.customFieldsUsed || [];
    
    // Obtener número de ejecuciones
    const executionCount = triggersData.triggerExecutions.get(trigger.id.toString()) || 0;
    const executionDisplay = formatTriggerExecutions(executionCount, triggersData.executionsLoading);

    return `
        <tr class="${rowClass}">
            <td class="trigger-id-col">
                <a href="https://${window.location.hostname}/admin/objects-rules/rules/triggers/${trigger.id}" 
                   target="_blank" class="trigger-link">${trigger.id || 'N/A'}</a>
            </td>
            <td class="trigger-title-col">
                <div class="trigger-title-content" title="${escapeHtml(safeTitle)}">
                    <a href="https://${window.location.hostname}/admin/objects-rules/rules/triggers/${trigger.id}" 
                       target="_blank" class="trigger-link">${escapeHtml(safeTitle)}</a>
                </div>
            </td>
            <td class="trigger-status-col">
                <span class="trigger-status-badge ${trigger.active ? 'trigger-status-active' : 'trigger-status-inactive'}">
                    ${trigger.active ? '✅' : '❌'}
                </span>
            </td>
            <td class="trigger-executions-col">
                ${executionDisplay}
            </td>
            <td class="trigger-dates-col">
                <div class="trigger-cell-content">
                    <div style="font-size: 0.7rem;">
                        <strong>Creado:</strong><br>
                        ${formatTriggerDate(trigger.created_at)}<br>
                        <strong>Actualizado:</strong><br>
                        ${formatTriggerDate(trigger.updated_at)}
                    </div>
                </div>
            </td>
            <td class="trigger-conditions-col">
                <div class="trigger-cell-content">
                    ${formatConditions(safeConditions)}
                </div>
            </td>
            <td class="trigger-actions-col">
                <div class="trigger-cell-content">
                    ${formatActions(safeActions)}
                </div>
            </td>
            <td class="trigger-functionality-col">
                <div class="trigger-functionality-content" title="${escapeHtml(safeFunctionality)}">
                    ${escapeHtml(safeFunctionality)}
                </div>
            </td>
            <td class="trigger-custom-fields-col">
                <div class="trigger-cell-content">
                    ${formatCustomFields(safeCustomFields)}
                </div>
            </td>
        </tr>
    `;
}

// Formatear condiciones para mostrar
function formatConditions(processedConditions) {
    // Validación mejorada de datos
    if (!processedConditions || 
        typeof processedConditions !== 'object' ||
        (!Array.isArray(processedConditions.all) && !Array.isArray(processedConditions.any)) ||
        ((!processedConditions.all || processedConditions.all.length === 0) && 
         (!processedConditions.any || processedConditions.any.length === 0))) {
        return '<em style="color: #6c757d; font-size: 0.7rem;">Sin condiciones</em>';
    }
    
    let html = '';
    
    // Procesar condiciones ALL
    if (processedConditions.all && Array.isArray(processedConditions.all) && processedConditions.all.length > 0) {
        html += `
            <div class="condition-group">
                <div class="condition-group-title">TODAS:</div>
                ${processedConditions.all.slice(0, 2).map(condition => {
                    if (!condition) return '';
                    const text = condition.displayText || condition.field || 'Condición sin formato';
                    const safeText = typeof text === 'string' ? text : String(text);
                    return `<div class="condition-item">${escapeHtml(safeText.length > 60 ? safeText.substring(0, 60) + '...' : safeText)}</div>`;
                }).filter(Boolean).join('')}
                ${processedConditions.all.length > 2 ? `<div class="condition-item" style="color: #9e9e9e; font-style: italic;">+${processedConditions.all.length - 2} más...</div>` : ''}
            </div>
        `;
    }
    
    // Procesar condiciones ANY
    if (processedConditions.any && Array.isArray(processedConditions.any) && processedConditions.any.length > 0) {
        html += `
            <div class="condition-group">
                <div class="condition-group-title">CUALQUIERA:</div>
                ${processedConditions.any.slice(0, 2).map(condition => {
                    if (!condition) return '';
                    const text = condition.displayText || condition.field || 'Condición sin formato';
                    const safeText = typeof text === 'string' ? text : String(text);
                    return `<div class="condition-item">${escapeHtml(safeText.length > 60 ? safeText.substring(0, 60) + '...' : safeText)}</div>`;
                }).filter(Boolean).join('')}
                ${processedConditions.any.length > 2 ? `<div class="condition-item" style="color: #9e9e9e; font-style: italic;">+${processedConditions.any.length - 2} más...</div>` : ''}
            </div>
        `;
    }
    
    return html || '<em style="color: #6c757d; font-size: 0.7rem;">Sin condiciones válidas</em>';
}

// Formatear acciones para mostrar
function formatActions(processedActions) {
    // Validación mejorada de datos
    if (!processedActions || !Array.isArray(processedActions) || processedActions.length === 0) {
        return '<em style="color: #6c757d; font-size: 0.7rem;">Sin acciones</em>';
    }
    
    const actionsToShow = processedActions.filter(action => action && typeof action === 'object').slice(0, 3);
    
    if (actionsToShow.length === 0) {
        return '<em style="color: #6c757d; font-size: 0.7rem;">Sin acciones válidas</em>';
    }
    
    let html = actionsToShow.map(action => {
        if (!action) return '';
        
        const fieldName = action.fieldDisplayName || action.field || 'Campo';
        const value = action.value !== undefined ? String(action.value) : 'Valor vacío';
        
        const safeFieldName = typeof fieldName === 'string' ? fieldName : String(fieldName);
        const safeValue = typeof value === 'string' ? value : String(value);
        
        const truncatedField = safeFieldName.length > 20 ? safeFieldName.substring(0, 20) + '...' : safeFieldName;
        const truncatedValue = safeValue.length > 25 ? safeValue.substring(0, 25) + '...' : safeValue;
        
        return `
            <div class="action-item">
                <span class="action-field">${escapeHtml(truncatedField)}</span>:
                <span class="action-value">${escapeHtml(truncatedValue)}</span>
            </div>
        `;
    }).filter(Boolean).join('');
    
    if (processedActions.length > 3) {
        html += `<div class="action-item" style="color: #9e9e9e; font-style: italic; background-color: #f5f5f5;">+${processedActions.length - 3} acciones más...</div>`;
    }
    
    return html || '<em style="color: #6c757d; font-size: 0.7rem;">Sin acciones válidas</em>';
}

// Formatear campos personalizados para mostrar
function formatCustomFields(customFieldsUsed) {
    // Validación mejorada de datos
    if (!customFieldsUsed || !Array.isArray(customFieldsUsed) || customFieldsUsed.length === 0) {
        return '<em style="color: #6c757d; font-size: 0.7rem;">Sin campos personalizados</em>';
    }
    
    const fieldsToShow = customFieldsUsed.filter(field => field && typeof field === 'object').slice(0, 4);
    
    if (fieldsToShow.length === 0) {
        return '<em style="color: #6c757d; font-size: 0.7rem;">Sin campos personalizados válidos</em>';
    }
    
    let html = fieldsToShow.map(field => {
        if (!field) return '';
        
        const name = field.name || field.id || 'Campo';
        const value = field.value !== undefined ? String(field.value) : 'Sin valor';
        
        const safeName = typeof name === 'string' ? name : String(name);
        const safeValue = typeof value === 'string' ? value : String(value);
        
        const truncatedName = safeName.length > 15 ? safeName.substring(0, 15) + '...' : safeName;
        const truncatedValue = safeValue.length > 15 ? safeValue.substring(0, 15) + '...' : safeValue;
        
        return `
            <div class="custom-field-item" title="${escapeHtml(safeName)}: ${escapeHtml(safeValue)}">
                <span class="custom-field-name">${escapeHtml(truncatedName)}</span>:
                <span class="custom-field-value">${escapeHtml(truncatedValue)}</span>
            </div>
        `;
    }).filter(Boolean).join('');
    
    if (customFieldsUsed.length > 4) {
        html += `<div class="custom-field-item" style="color: #9e9e9e; font-style: italic; background-color: #f0f0f0;">+${customFieldsUsed.length - 4} más...</div>`;
    }
    
    return html || '<em style="color: #6c757d; font-size: 0.7rem;">Sin campos personalizados válidos</em>';
}

// Formatear fecha para triggers
function formatTriggerDate(dateString) {
    if (!dateString) return 'N/A';
    
    try {
        const date = new Date(dateString);
        const now = new Date();
        const diffTime = Math.abs(now - date);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        
        const formattedDate = date.toLocaleDateString('es-ES', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
        
        const formattedTime = date.toLocaleTimeString('es-ES', {
            hour: '2-digit',
            minute: '2-digit'
        });
        
        let timeAgo = '';
        if (diffDays === 0) {
            timeAgo = ' (hoy)';
        } else if (diffDays === 1) {
            timeAgo = ' (ayer)';
        } else if (diffDays <= 7) {
            timeAgo = ` (${diffDays}d)`;
        } else if (diffDays <= 30) {
            const weeks = Math.floor(diffDays / 7);
            timeAgo = ` (${weeks}sem)`;
        } else if (diffDays <= 365) {
            const months = Math.floor(diffDays / 30);
            timeAgo = ` (${months}m)`;
        } else {
            const years = Math.floor(diffDays / 365);
            timeAgo = ` (${years}a)`;
        }
        
        return `${formattedDate}<br><small style="color: #6c757d;">${formattedTime}${timeAgo}</small>`;
    } catch (error) {
        return 'Fecha inválida';
    }
}

// Formatear número de ejecuciones de trigger
function formatTriggerExecutions(count, isLoading = false) {
    if (isLoading) {
        return `
            <div class="trigger-executions-content">
                <div class="spinner-border spinner-border-sm text-primary" role="status">
                    <span class="sr-only">Cargando...</span>
                </div>
                <small class="text-muted d-block mt-1">Contando...</small>
            </div>
        `;
    }
    
    if (count === 0) {
        return `
            <div class="trigger-executions-content">
                <span class="badge bg-light text-dark">0</span>
                <small class="text-muted d-block">Sin ejecuciones</small>
            </div>
        `;
    }
    
    // Determinar clase de badge según número de ejecuciones
    let badgeClass = 'bg-secondary';
    let icon = '📊';
    
    if (count >= 100) {
        badgeClass = 'bg-danger text-white';
        icon = '🔥';
    } else if (count >= 50) {
        badgeClass = 'bg-warning text-dark';
        icon = '⚡';
    } else if (count >= 10) {
        badgeClass = 'bg-success text-white';
        icon = '✅';
    } else if (count > 0) {
        badgeClass = 'bg-info text-white';
        icon = '🔵';
    }
    
    return `
        <div class="trigger-executions-content" title="Ejecuciones en los últimos 90 días">
            <span class="badge ${badgeClass} mb-1">
                ${icon} ${count.toLocaleString('es-ES')}
            </span>
            <small class="text-muted d-block">
                ${count === 1 ? 'ejecución' : 'ejecuciones'}
            </small>
        </div>
    `;
}

// Escapar HTML para prevenir XSS
function escapeHtml(text) {
    if (text === null || text === undefined) return '';
    if (typeof text !== 'string') {
        text = String(text);
    }
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Mostrar estado de carga
function showTriggersLoadingState() {
    const tableBody = document.getElementById('triggersTableBody');
    const counter = document.getElementById('triggersCounter');
    
    if (tableBody) {
        tableBody.innerHTML = `
            <tr>
                <td colspan="9" class="text-center py-5">
                    <div class="d-flex flex-column align-items-center">
                        <div class="spinner-border text-primary mb-3" role="status">
                            <span class="sr-only">Cargando...</span>
                        </div>
                        <div class="text-muted">Cargando disparadores desde Zendesk...</div>
                        <small class="text-muted mt-2">Esto puede tardar unos segundos</small>
                    </div>
                </td>
            </tr>
        `;
    }
    
    if (counter) {
        counter.textContent = 'Cargando...';
        counter.className = 'badge bg-secondary fs-6';
    }
}

// Mostrar estado de error
function showTriggersErrorState(error) {
    const tableBody = document.getElementById('triggersTableBody');
    const counter = document.getElementById('triggersCounter');
    
    if (tableBody) {
        tableBody.innerHTML = `
            <tr>
                <td colspan="9" class="text-center py-5">
                    <div class="d-flex flex-column align-items-center">
                        <i class="fas fa-exclamation-triangle text-danger mb-3" style="font-size: 2rem;"></i>
                        <div class="text-danger mb-2">Error al cargar disparadores</div>
                        <small class="text-muted">${escapeHtml(error.message || 'Error desconocido')}</small>
                        <button onclick="loadTriggers(true)" class="btn btn-primary btn-sm mt-3">
                            <i class="fas fa-retry"></i> Reintentar
                        </button>
                    </div>
                </td>
            </tr>
        `;
    }
    
    if (counter) {
        counter.textContent = 'Error';
        counter.className = 'badge bg-danger fs-6';
    }
}

// Actualizar contador de disparadores
function updateTriggersCounter() {
    const counter = document.getElementById('triggersCounter');
    if (counter) {
        const total = triggersData.triggers.length;
        const active = triggersData.triggers.filter(t => t.active).length;
        const inactive = total - active;
        
        counter.innerHTML = `
            <span title="Total: ${total} | Activos: ${active} | Inactivos: ${inactive}">
                ${total} disparadores
            </span>
        `;
        counter.className = 'badge bg-primary fs-6';
    }
}

// Actualizar información de la tabla
function updateTriggersInfo() {
    const info = document.getElementById('triggersInfo');
    if (info) {
        const start = (triggersData.currentPage - 1) * triggersData.itemsPerPage + 1;
        const end = Math.min(start + triggersData.itemsPerPage - 1, triggersData.filteredTriggers.length);
        const total = triggersData.filteredTriggers.length;
        
        info.textContent = `Mostrando ${start}-${end} de ${total} disparadores`;
    }
}

// Actualizar estado de filtros
function updateFilterStatus() {
    const status = document.getElementById('triggerFilterStatus');
    if (status) {
        const total = triggersData.triggers.length;
        const filtered = triggersData.filteredTriggers.length;
        
        if (filtered === total) {
            status.textContent = 'Mostrando todos los disparadores';
        } else {
            status.textContent = `Mostrando ${filtered} de ${total} disparadores (filtrados)`;
        }
    }
}

// Actualizar paginación
function updateTriggerPagination() {
    const pagination = document.getElementById('triggersPagination');
    if (!pagination) return;
    
    const totalPages = triggersData.totalPages;
    const currentPage = triggersData.currentPage;
    
    if (totalPages <= 1) {
        pagination.innerHTML = '';
        return;
    }
    
    let paginationHTML = '';
    
    // Botón anterior
    paginationHTML += `
        <li class="page-item ${currentPage === 1 ? 'disabled' : ''}">
            <a class="page-link" href="#" onclick="changeTriggerPage(${currentPage - 1})" tabindex="-1">Anterior</a>
        </li>
    `;
    
    // Páginas
    const startPage = Math.max(1, currentPage - 2);
    const endPage = Math.min(totalPages, currentPage + 2);
    
    if (startPage > 1) {
        paginationHTML += `<li class="page-item"><a class="page-link" href="#" onclick="changeTriggerPage(1)">1</a></li>`;
        if (startPage > 2) {
            paginationHTML += `<li class="page-item disabled"><span class="page-link">...</span></li>`;
        }
    }
    
    for (let i = startPage; i <= endPage; i++) {
        paginationHTML += `
            <li class="page-item ${i === currentPage ? 'active' : ''}">
                <a class="page-link" href="#" onclick="changeTriggerPage(${i})">${i}</a>
            </li>
        `;
    }
    
    if (endPage < totalPages) {
        if (endPage < totalPages - 1) {
            paginationHTML += `<li class="page-item disabled"><span class="page-link">...</span></li>`;
        }
        paginationHTML += `<li class="page-item"><a class="page-link" href="#" onclick="changeTriggerPage(${totalPages})">${totalPages}</a></li>`;
    }
    
    // Botón siguiente
    paginationHTML += `
        <li class="page-item ${currentPage === totalPages ? 'disabled' : ''}">
            <a class="page-link" href="#" onclick="changeTriggerPage(${currentPage + 1})">Siguiente</a>
        </li>
    `;
    
    pagination.innerHTML = paginationHTML;
}

// Cambiar página de disparadores
function changeTriggerPage(page) {
    if (page < 1 || page > triggersData.totalPages) return;
    
    triggersData.currentPage = page;
    renderTriggersTable();
    updateTriggerPagination();
    
    // Scroll al top de la tabla
    const table = document.getElementById('triggersTable');
    if (table) {
        table.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
}

// Exportar disparadores a Excel (XLSX)
function exportTriggersToCSV() {
    try {
        console.log('📊 Generando archivo Excel...');
        
        // Preparar datos para Excel
        const excelData = triggersData.filteredTriggers.map(trigger => {
            const executionCount = triggersData.triggerExecutions.get(trigger.id.toString()) || 0;
            
            return {
                'ID': trigger.id,
                'Título': trigger.title || 'Sin título',
                'Estado': trigger.active ? 'Activo' : 'Inactivo',
                'Ejecuciones (90 días)': executionCount,
                'Creado': formatTriggerDate(trigger.created_at),
                'Actualizado': formatTriggerDate(trigger.updated_at),
                'Funcionalidad': trigger.functionality || 'Sin descripción',
                'Condiciones (ALL)': formatConditionsForExcel(trigger.processedConditions?.all || []),
                'Condiciones (ANY)': formatConditionsForExcel(trigger.processedConditions?.any || []),
                'Acciones': formatActionsForExcel(trigger.processedActions || []),
                'Campos Personalizados': formatCustomFieldsForExcel(trigger.customFieldsUsed || []),
                'URL': `https://${window.location.hostname}/admin/objects-rules/rules/triggers/${trigger.id}`
            };
        });
        
        // Crear workbook
        const wb = XLSX.utils.book_new();
        
        // Crear hoja principal con todos los triggers
        const ws1 = XLSX.utils.json_to_sheet(excelData);
        
        // Ajustar anchos de columna
        const colWidths = [
            { wch: 10 },  // ID
            { wch: 30 },  // Título
            { wch: 10 },  // Estado
            { wch: 15 },  // Ejecuciones
            { wch: 18 },  // Creado
            { wch: 18 },  // Actualizado
            { wch: 50 },  // Funcionalidad
            { wch: 40 },  // Condiciones ALL
            { wch: 40 },  // Condiciones ANY
            { wch: 40 },  // Acciones
            { wch: 30 },  // Campos Personalizados
            { wch: 60 }   // URL
        ];
        ws1['!cols'] = colWidths;
        
        // Agregar hoja principal
        XLSX.utils.book_append_sheet(wb, ws1, 'Todos los Triggers');
        
        // Crear hoja de resumen estadístico
        const summaryData = generateTriggersSummary();
        const ws2 = XLSX.utils.json_to_sheet(summaryData);
        ws2['!cols'] = [{ wch: 25 }, { wch: 15 }];
        XLSX.utils.book_append_sheet(wb, ws2, 'Resumen');
        
        // Crear hoja solo con triggers activos
        const activeTriggersData = excelData.filter(trigger => trigger.Estado === 'Activo');
        if (activeTriggersData.length > 0) {
            const ws3 = XLSX.utils.json_to_sheet(activeTriggersData);
            ws3['!cols'] = colWidths;
            XLSX.utils.book_append_sheet(wb, ws3, 'Triggers Activos');
        }
        
        // Crear hoja solo con triggers inactivos
        const inactiveTriggersData = excelData.filter(trigger => trigger.Estado === 'Inactivo');
        if (inactiveTriggersData.length > 0) {
            const ws4 = XLSX.utils.json_to_sheet(inactiveTriggersData);
            ws4['!cols'] = colWidths;
            XLSX.utils.book_append_sheet(wb, ws4, 'Triggers Inactivos');
        }
        
        // Generar archivo y descargarlo
        const fileName = `Zendesk_Triggers_${new Date().toISOString().split('T')[0]}_${new Date().toTimeString().split(' ')[0].replace(/:/g, '-')}.xlsx`;
        XLSX.writeFile(wb, fileName);
        
        console.log('✅ Archivo Excel generado y descargado:', fileName);
        
        // Mostrar mensaje de éxito
        showExportSuccessMessage(fileName, excelData.length);
        
    } catch (error) {
        console.error('❌ Error exportando Excel:', error);
        alert('Error al generar el archivo Excel. Verifica que la librería SheetJS esté cargada correctamente.');
    }
}

// Generar resumen estadístico para Excel
function generateTriggersSummary() {
    const total = triggersData.filteredTriggers.length;
    const active = triggersData.filteredTriggers.filter(t => t.active).length;
    const inactive = total - active;
    const withCustomFields = triggersData.filteredTriggers.filter(t => t.customFieldsUsed && t.customFieldsUsed.length > 0).length;
    const withDescription = triggersData.filteredTriggers.filter(t => t.description && t.description.trim()).length;
    
    // Contar por fechas de actualización
    const today = new Date();
    const thisWeek = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
    const thisMonth = new Date(today.getFullYear(), today.getMonth(), 1);
    const thisYear = new Date(today.getFullYear(), 0, 1);
    
    const updatedThisWeek = triggersData.filteredTriggers.filter(t => new Date(t.updated_at) >= thisWeek).length;
    const updatedThisMonth = triggersData.filteredTriggers.filter(t => new Date(t.updated_at) >= thisMonth).length;
    const updatedThisYear = triggersData.filteredTriggers.filter(t => new Date(t.updated_at) >= thisYear).length;
    
    return [
        { 'Métrica': '📊 RESUMEN GENERAL', 'Valor': '' },
        { 'Métrica': 'Total de Triggers', 'Valor': total },
        { 'Métrica': 'Triggers Activos', 'Valor': active },
        { 'Métrica': 'Triggers Inactivos', 'Valor': inactive },
        { 'Métrica': 'Porcentaje Activos', 'Valor': total > 0 ? `${((active / total) * 100).toFixed(1)}%` : '0%' },
        { 'Métrica': '', 'Valor': '' },
        { 'Métrica': '📋 CONTENIDO', 'Valor': '' },
        { 'Métrica': 'Con Campos Personalizados', 'Valor': withCustomFields },
        { 'Métrica': 'Con Descripción', 'Valor': withDescription },
        { 'Métrica': 'Sin Descripción', 'Valor': total - withDescription },
        { 'Métrica': '', 'Valor': '' },
        { 'Métrica': '📅 ACTIVIDAD RECIENTE', 'Valor': '' },
        { 'Métrica': 'Actualizados esta semana', 'Valor': updatedThisWeek },
        { 'Métrica': 'Actualizados este mes', 'Valor': updatedThisMonth },
        { 'Métrica': 'Actualizados este año', 'Valor': updatedThisYear },
        { 'Métrica': '', 'Valor': '' },
        { 'Métrica': '📄 INFORMACIÓN DEL REPORTE', 'Valor': '' },
        { 'Métrica': 'Fecha de Generación', 'Valor': new Date().toLocaleDateString('es-ES') },
        { 'Métrica': 'Hora de Generación', 'Valor': new Date().toLocaleTimeString('es-ES') },
        { 'Métrica': 'Filtros Aplicados', 'Valor': total === triggersData.triggers.length ? 'Ninguno' : 'Sí' }
    ];
}

// Mostrar mensaje de éxito de exportación
function showExportSuccessMessage(fileName, recordCount) {
    // Crear elemento de notificación
    const notification = document.createElement('div');
    notification.className = 'alert alert-success alert-dismissible fade show position-fixed';
    notification.style.cssText = `
        top: 20px;
        right: 20px;
        z-index: 9999;
        min-width: 300px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    `;
    
    notification.innerHTML = `
        <div class="d-flex align-items-center">
            <i class="fas fa-check-circle text-success me-2" style="font-size: 1.2rem;"></i>
            <div>
                <strong>¡Exportación exitosa!</strong><br>
                <small>📄 ${fileName}<br>
                📊 ${recordCount} registros exportados</small>
            </div>
        </div>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    // Agregar al DOM
    document.body.appendChild(notification);
    
    // Auto-remover después de 5 segundos
    setTimeout(() => {
        if (notification.parentNode) {
            notification.parentNode.removeChild(notification);
        }
    }, 5000);
}

// Formatear condiciones para Excel
function formatConditionsForExcel(conditions) {
    if (!conditions || conditions.length === 0) return 'Sin condiciones';
    return conditions.map(c => c.displayText || `${c.field} ${c.operator} ${c.value}`).join('\n• ');
}

// Formatear acciones para Excel
function formatActionsForExcel(actions) {
    if (!actions || actions.length === 0) return 'Sin acciones';
    return actions.map(a => a.displayText || `${a.field}: ${a.value}`).join('\n• ');
}

// Formatear campos personalizados para Excel
function formatCustomFieldsForExcel(customFields) {
    if (!customFields || customFields.length === 0) return 'Sin campos personalizados';
    return customFields.map(f => `${f.name}: ${f.value}`).join('\n• ');
}

// Mantener funciones CSV por compatibilidad (aunque ya no se usen)
function formatConditionsForCSV(conditions) {
    if (!conditions || conditions.length === 0) return '';
    return conditions.map(c => c.displayText || `${c.field} ${c.operator} ${c.value}`).join('; ');
}

function formatActionsForCSV(actions) {
    if (!actions || actions.length === 0) return '';
    return actions.map(a => a.displayText || `${a.field}: ${a.value}`).join('; ');
}

function formatCustomFieldsForCSV(customFields) {
    if (!customFields || customFields.length === 0) return '';
    return customFields.map(f => `${f.name}: ${f.value}`).join('; ');
}

// Función global para cambiar página (necesaria para onclick en HTML generado)
window.changeTriggerPage = changeTriggerPage;

// ========== FUNCIONALIDAD PARA LA PÁGINA DE TICKETS ==========

// Variables globales para tickets
const ticketsData = {
    tickets: [],
    ticketFields: [],
    users: new Map(), // Cache de usuarios
    filteredTickets: [],
    currentPage: 1,
    itemsPerPage: 25,
    totalPages: 0,
    isLoading: false,
    customFieldsMap: new Map(),
    dynamicColumns: []
};

// Inicializar página de tickets
function initTicketsPage() {
    console.log('🎫 Inicializando página de tickets...');
    
    // Setup event listeners
    setupTicketFilters();
    setupTicketButtons();
    setupTicketPagination();
    
    // Cargar datos automáticamente
    loadTicketsData();
}

// Configurar filtros para tickets
function setupTicketFilters() {
    const filters = [
        'filterTicketStatus',
        'filterTicketPriority', 
        'filterTicketType',
        'filterTicketSubject',
        'filterTicketRequester',
        'filterTicketAssignee',
        'filterTicketTags',
        'filterTicketCustomFields',
        'filterTicketFunctionality'
    ];
    
    const debouncedFilter = debounce(applyTicketFilters, 300);
    
    filters.forEach(filterId => {
        const element = document.getElementById(filterId);
        if (element) {
            if (element.tagName === 'SELECT') {
                element.addEventListener('change', debouncedFilter);
            } else {
                element.addEventListener('input', debouncedFilter);
            }
        }
    });
    
    // Setup items per page
    const itemsPerPageSelect = document.getElementById('ticketsPerPageMain');
    if (itemsPerPageSelect) {
        itemsPerPageSelect.addEventListener('change', function() {
            ticketsDataMain.itemsPerPage = parseInt(this.value);
            ticketsDataMain.currentPage = 1;
            renderTicketsTable();
            updateTicketPagination();
        });
    }
}

// Configurar botones de tickets
function setupTicketButtons() {
    const refreshBtn = document.getElementById('refreshTickets');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', () => loadTicketsData(true));
    }
    
    const clearFiltersBtn = document.getElementById('clearTicketFilters');
    if (clearFiltersBtn) {
        clearFiltersBtn.addEventListener('click', clearTicketFilters);
    }
    
    const exportBtn = document.getElementById('exportTickets');
    if (exportBtn) {
        exportBtn.addEventListener('click', exportTicketsToExcel);
    }
}

// Configurar paginación de tickets
function setupTicketPagination() {
    // La paginación se manejará dinámicamente en updateTicketPagination()
}

// Cargar todos los datos de tickets
async function loadTicketsData(forceRefresh = false) {
    if (ticketsDataMain.isLoading && !forceRefresh) {
        console.log('⏳ Ya hay una carga en progreso...');
        return;
    }
    
    ticketsDataMain.isLoading = true;
    showTicketsLoadingState();
    
    try {
        console.log('🎫 Cargando tickets desde Zendesk...');
        const startTime = performance.now();
        
        // Cargar datos en paralelo
        const [tickets, ticketFields] = await Promise.all([
            loadAllTickets(),
            loadTicketFields()
        ]);
        
        // Procesar y almacenar datos
        ticketsDataMain.tickets = tickets;
        ticketsDataMain.ticketFields = ticketFields;
        
        // Crear mapa de campos personalizados
        const customFieldsMap = new Map();
        ticketFields.forEach(field => {
            customFieldsMap.set(field.id.toString(), field);
        });
        ticketsDataMain.customFieldsMap = customFieldsMap;
        
        // Determinar columnas dinámicas
        determineTicketColumns(tickets, ticketFields);
        
        // Procesar tickets con información adicional
        ticketsDataMain.tickets = await Promise.all(
            tickets.map(ticket => enrichTicketData(ticket, customFieldsMap))
        );
        
        const endTime = performance.now();
        console.log(`✅ Cargados ${tickets.length} tickets en ${(endTime - startTime).toFixed(2)}ms`);
        
        // Aplicar filtros y mostrar resultados
        applyTicketFilters();
        updateTicketsCounter();
        populateTicketTypeFilter();
        
    } catch (error) {
        console.error('❌ Error cargando tickets:', error);
        showTicketsErrorState(error);
    } finally {
        ticketsDataMain.isLoading = false;
    }
}

// ========== FUNCIONALIDAD PARA LA PÁGINA DE TICKETS ==========

// Variables globales para tickets
const ticketsDataMain = {
    tickets: [],
    ticketFields: [],
    users: new Map(), // Cache de usuarios
    filteredTickets: [],
    currentPage: 1,
    itemsPerPage: 25,
    totalPages: 0,
    isLoading: false,
    customFieldsMap: new Map(),
    dynamicColumns: []
};

// Inicializar página de tickets
function initTicketsPage() {
    console.log('🎫 Inicializando página de tickets...');
    
    // Setup event listeners
    setupTicketFilters();
    setupTicketButtons();
    setupTicketPagination();
}

// Configurar filtros para tickets
function setupTicketFilters() {
    const filters = [
        'filterTicketStatus',
        'filterTicketPriority', 
        'filterTicketType',
        'filterTicketSubject',
        'filterTicketRequester',
        'filterTicketAssignee',
        'filterTicketTags',
        'filterTicketCustomFields',
        'filterTicketFunctionality'
    ];
    
    const debouncedFilter = debounce(applyTicketFilters, 300);
    
    filters.forEach(filterId => {
        const element = document.getElementById(filterId);
        if (element) {
            if (element.tagName === 'SELECT') {
                element.addEventListener('change', debouncedFilter);
            } else {
                element.addEventListener('input', debouncedFilter);
            }
        }
    });
    
    // Setup items per page
    const itemsPerPageSelect = document.getElementById('ticketsPerPageMain');
    if (itemsPerPageSelect) {
        itemsPerPageSelect.addEventListener('change', function() {
            ticketsDataMain.itemsPerPage = parseInt(this.value);
            ticketsDataMain.currentPage = 1;
            renderTicketsTable();
            updateTicketPagination();
        });
    }
}

// Configurar botones de tickets
function setupTicketButtons() {
    const refreshBtn = document.getElementById('refreshTickets');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', () => loadTicketsData(true));
    }
    
    const clearFiltersBtn = document.getElementById('clearTicketFilters');
    if (clearFiltersBtn) {
        clearFiltersBtn.addEventListener('click', clearTicketFilters);
    }
    
    const exportBtn = document.getElementById('exportTickets');
    if (exportBtn) {
        exportBtn.addEventListener('click', exportTicketsToExcel);
    }
}

// Configurar paginación de tickets
function setupTicketPagination() {
    // La paginación se manejará dinámicamente en updateTicketPagination()
}

// Cargar todos los datos de tickets
async function loadTicketsData(forceRefresh = false) {
    if (ticketsDataMain.isLoading && !forceRefresh) {
        console.log('⏳ Ya hay una carga en progreso...');
        return;
    }
    
    ticketsDataMain.isLoading = true;
    showTicketsLoadingState();
    
    try {
        console.log('🎫 Cargando tickets desde Zendesk...');
        const startTime = performance.now();
        
        // Cargar datos en paralelo
        const [tickets, ticketFields] = await Promise.all([
            loadAllTicketsForPage(),
            loadTicketFieldsForPage()
        ]);
        
        // Procesar y almacenar datos
        ticketsDataMain.tickets = tickets;
        ticketsDataMain.ticketFields = ticketFields;
        
        // Crear mapa de campos personalizados
        const customFieldsMap = new Map();
        ticketFields.forEach(field => {
            customFieldsMap.set(field.id.toString(), field);
        });
        ticketsDataMain.customFieldsMap = customFieldsMap;
        
        // Determinar columnas dinámicas
        determineTicketColumns(tickets, ticketFields);
        
        // Procesar tickets con información adicional
        ticketsDataMain.tickets = await Promise.all(
            tickets.map(ticket => enrichTicketData(ticket, customFieldsMap))
        );
        
        const endTime = performance.now();
        console.log(`✅ Cargados ${tickets.length} tickets en ${(endTime - startTime).toFixed(2)}ms`);
        
        // Aplicar filtros y mostrar resultados
        applyTicketFilters();
        updateTicketsCounter();
        populateTicketTypeFilter();
        
    } catch (error) {
        console.error('❌ Error cargando tickets:', error);
        showTicketsErrorState(error);
    } finally {
        ticketsDataMain.isLoading = false;
    }
}

// Cargar todos los tickets con paginación automática
async function loadAllTicketsForPage() {
    const allTickets = [];
    let hasMore = true;
    let nextPage = null;
    let pageCount = 0;
    
    while (hasMore && pageCount < 30) { // Límite de seguridad
        try {
            const url = nextPage || '/api/v2/tickets.json?per_page=100&include=users';
            console.log(`📄 Cargando página ${pageCount + 1} de tickets...`);
            
            const response = await client.request({
                url: url,
                type: 'GET'
            });
            
            if (response.tickets && response.tickets.length > 0) {
                allTickets.push(...response.tickets);
                console.log(`📊 Página ${pageCount + 1}: ${response.tickets.length} tickets (Total: ${allTickets.length})`);
                
                // Cache de usuarios incluidos
                if (response.users) {
                    response.users.forEach(user => {
                        ticketsDataMain.users.set(user.id, user);
                    });
                }
            }
            
            hasMore = !!response.next_page;
            nextPage = response.next_page;
            pageCount++;
            
            // Pausa para no sobrecargar la API
            if (hasMore) {
                await new Promise(resolve => setTimeout(resolve, 150));
            }
            
        } catch (error) {
            console.error(`❌ Error cargando página ${pageCount + 1}:`, error);
            hasMore = false;
        }
    }
    
    console.log(`🎫 Total de tickets cargados: ${allTickets.length}`);
    return allTickets;
}

// Cargar campos de tickets para página
async function loadTicketFieldsForPage() {
    try {
        console.log('🔧 Cargando campos de tickets...');
        
        const response = await client.request({
            url: '/api/v2/ticket_fields.json?per_page=100',
            type: 'GET'
        });
        
        const ticketFields = response.ticket_fields || [];
        console.log(`✅ Cargados ${ticketFields.length} campos de tickets`);
        
        return ticketFields;
        
    } catch (error) {
        console.error('❌ Error cargando campos de tickets:', error);
        return [];
    }
}



// Determinar columnas dinámicas basadas en tickets y campos
function determineTicketColumns(tickets, ticketFields) {
    const columns = [
        { key: 'id', title: 'ID', type: 'id', width: '80px' },
        { key: 'subject', title: 'Asunto', type: 'subject', width: '300px' },
        { key: 'status', title: 'Estado', type: 'status', width: '100px' },
        { key: 'priority', title: 'Prioridad', type: 'priority', width: '100px' },
        { key: 'type', title: 'Tipo', type: 'type', width: '120px' },
        { key: 'requester_id', title: 'Solicitante', type: 'user', width: '180px' },
        { key: 'assignee_id', title: 'Agente Asignado', type: 'user', width: '180px' },
        { key: 'group_id', title: 'Grupo', type: 'group', width: '150px' },
        { key: 'organization_id', title: 'Organización', type: 'organization', width: '150px' },
        { key: 'follower_ids', title: 'Seguidores', type: 'followers', width: '200px' },
        { key: 'tags', title: 'Etiquetas', type: 'tags', width: '200px' }
    ];
    
    // Encontrar campos personalizados que se usan
    const usedCustomFields = new Set();
    const availableFields = new Set(); // Campos adicionales del sistema
    
    if (tickets && Array.isArray(tickets)) {
        tickets.forEach(ticket => {
            // Detectar custom fields
            if (ticket.custom_fields && Array.isArray(ticket.custom_fields)) {
                ticket.custom_fields.forEach(cf => {
                    if (cf.value && cf.value !== '') {
                        usedCustomFields.add(cf.id.toString());
                    }
                });
            }
            
            // Detectar campos adicionales del sistema que tienen valor
            const systemFields = [
                'submitter_id', 'collaborator_ids', 'external_id', 
                'problem_id', 'forum_topic_id', 'brand_id',
                'satisfaction_rating', 'sharing_agreement_ids',
                'via', 'raw_subject', 'description'
            ];
            
            systemFields.forEach(field => {
                if (ticket[field] && ticket[field] !== null && ticket[field] !== '') {
                    availableFields.add(field);
                }
            });
        });
    }
    
    // Agregar campos del sistema que se detectaron
    if (availableFields.has('submitter_id')) {
        columns.push({
            key: 'submitter_id',
            title: 'Enviado por',
            type: 'user',
            width: '150px'
        });
    }
    
    if (availableFields.has('organization_id')) {
        // Ya está en la lista base, no agregar duplicado
    }
    
    if (availableFields.has('brand_id')) {
        columns.push({
            key: 'brand_id',
            title: 'Marca',
            type: 'brand',
            width: '120px'
        });
    }
    
    if (availableFields.has('via')) {
        columns.push({
            key: 'via',
            title: 'Canal',
            type: 'via',
            width: '100px'
        });
    }
    
    if (availableFields.has('satisfaction_rating')) {
        columns.push({
            key: 'satisfaction_rating',
            title: 'Satisfacción',
            type: 'satisfaction',
            width: '120px'
        });
    }
    
    // Agregar columnas de campos personalizados
    if (ticketFields && Array.isArray(ticketFields)) {
        // Ordenar campos personalizados por title para consistencia
        const sortedCustomFields = Array.from(usedCustomFields)
            .map(fieldId => {
                const field = ticketFields.find(f => f.id.toString() === fieldId);
                return { fieldId, field };
            })
            .filter(item => item.field)
            .sort((a, b) => (a.field.title || '').localeCompare(b.field.title || ''));
            
        sortedCustomFields.forEach(({ fieldId, field }) => {
            columns.push({
                key: `custom_field_${fieldId}`,
                title: field.title || `Campo ${fieldId}`,
                type: 'custom_field',
                fieldId: fieldId,
                fieldType: field.type || 'text',
                width: field.type === 'date' ? '150px' : '150px'
            });
        });
    }
    
    // Agregar columna de funcionalidad
    columns.push({
        key: 'functionality',
        title: 'Funcionalidad',
        type: 'functionality',
        width: '350px'
    });
    
    // Agregar columnas de fechas importantes (siempre al final)
    const dateColumns = [
        { key: 'created_at', title: 'Fecha Creación', type: 'date', width: '180px' },
        { key: 'updated_at', title: 'Última Actualización', type: 'date', width: '180px' }
    ];
    
    // Agregar fechas adicionales si están disponibles
    if (availableFields.has('due_at')) {
        dateColumns.splice(1, 0, {
            key: 'due_at',
            title: 'Fecha Vencimiento',
            type: 'date',
            width: '180px'
        });
    }
    
    if (availableFields.has('solved_at')) {
        dateColumns.splice(-1, 0, {
            key: 'solved_at',
            title: 'Fecha Resolución',
            type: 'date',
            width: '180px'
        });
    }
    
    // Detectar custom fields de tipo fecha
    if (ticketFields && Array.isArray(ticketFields)) {
        ticketFields.forEach(field => {
            if (field.type === 'date' && usedCustomFields.has(field.id.toString())) {
                // Ya se agregó arriba en la sección de custom fields
            }
        });
    }
    
    columns.push(...dateColumns);
    
    ticketsDataMain.dynamicColumns = columns;
    console.log(`🏗️ Generadas ${columns.length} columnas dinámicas`);
    console.log('📋 Columnas incluidas:', columns.map(c => c.title).join(', '));
}

// Enriquecer datos del ticket
async function enrichTicketData(ticket, customFieldsMap) {
    try {
        // Generar funcionalidad automática
        const functionality = await generateTicketFunctionality(ticket, customFieldsMap);
        
        // Procesar campos personalizados
        const customFieldsUsed = extractTicketCustomFields(ticket, customFieldsMap);
        
        return {
            ...ticket,
            functionality: functionality,
            customFieldsUsed: customFieldsUsed,
            requesterName: await getUserName(ticket.requester_id),
            assigneeName: await getUserName(ticket.assignee_id),
            submitterName: await getUserName(ticket.submitter_id),
            followerNames: await getFollowerNames(ticket.follower_ids)
        };
        
    } catch (error) {
        console.error('Error enriqueciendo ticket:', error);
        return {
            ...ticket,
            functionality: 'Error procesando ticket',
            customFieldsUsed: [],
            requesterName: 'Usuario desconocido',
            assigneeName: ticket.assignee_id ? 'Agente desconocido' : 'Sin asignar',
            followerNames: []
        };
    }
}

// Generar funcionalidad automática del ticket
async function generateTicketFunctionality(ticket, customFieldsMap) {
    // Si tiene descripción útil, usarla
    if (ticket.description && ticket.description.trim().length > 20) {
        const cleanDesc = ticket.description.replace(/<[^>]*>/g, '').trim();
        if (cleanDesc.length > 20 && cleanDesc.length < 200) {
            return cleanDesc;
        }
    }
    
    // Generar resumen basado en campos
    const summary = [];
    
    // Información del asunto
    if (ticket.subject) {
        summary.push(`Ticket: ${ticket.subject}`);
    }
    
    // Información de campos personalizados importantes
    if (ticket.custom_fields) {
        const importantFields = ticket.custom_fields.filter(cf => 
            cf.value && cf.value !== '' && customFieldsMap.has(cf.id.toString())
        ).slice(0, 2);
        
        importantFields.forEach(cf => {
            const field = customFieldsMap.get(cf.id.toString());
            if (field) {
                summary.push(`${field.title}: ${cf.value}`);
            }
        });
    }
    
    // Información del estado y prioridad si son relevantes
    if (ticket.priority && ticket.priority !== 'normal') {
        summary.push(`Prioridad: ${ticket.priority}`);
    }
    
    if (ticket.type && ticket.type !== 'ticket') {
        summary.push(`Tipo: ${ticket.type}`);
    }
    
    return summary.length > 0 ? summary.join(' | ') : 'Ticket estándar sin información adicional';
}

// Extraer campos personalizados del ticket
function extractTicketCustomFields(ticket, customFieldsMap) {
    if (!ticket.custom_fields) return [];
    
    return ticket.custom_fields
        .filter(cf => cf.value && cf.value !== '')
        .map(cf => {
            const field = customFieldsMap.get(cf.id.toString());
            return {
                id: cf.id,
                name: field ? field.title : `Campo ${cf.id}`,
                value: cf.value,
                type: field ? field.type : 'text'
            };
        })
        .slice(0, 5); // Máximo 5 campos para evitar sobrecarga
}

// Obtener nombre de usuario
async function getUserName(userId) {
    if (!userId) return 'Sin asignar';
    
    // Verificar cache
    if (ticketsDataMain.users.has(userId)) {
        const user = ticketsDataMain.users.get(userId);
        return user.name || user.email || 'Usuario desconocido';
    }
    
    // Cargar usuario desde API
    try {
        const response = await client.request({
            url: `/api/v2/users/${userId}.json`,
            type: 'GET'
        });
        
        if (response.user) {
            ticketsDataMain.users.set(userId, response.user);
            return response.user.name || response.user.email || 'Usuario desconocido';
        }
    } catch (error) {
        console.warn(`Error cargando usuario ${userId}:`, error);
    }
    
    return 'Usuario desconocido';
}

// Obtener nombres de seguidores
async function getFollowerNames(followerIds) {
    if (!followerIds || followerIds.length === 0) return [];
    
    const names = [];
    
    for (const userId of followerIds.slice(0, 3)) { // Máximo 3 para evitar sobrecarga
        const name = await getUserName(userId);
        if (name !== 'Usuario desconocido') {
            names.push(name);
        }
    }
    
    return names;
}

// Aplicar filtros a los tickets
function applyTicketFilters() {
    console.log('🔍 Aplicando filtros de tickets...');
    
    // Verificar que tenemos tickets
    if (!ticketsDataMain.tickets || !Array.isArray(ticketsDataMain.tickets)) {
        console.error('❌ No hay tickets para filtrar');
        ticketsDataMain.filteredTickets = [];
        ticketsDataMain.currentPage = 1;
        ticketsDataMain.totalPages = 0;
        renderTicketsTable();
        updateTicketPagination();
        updateTicketFilterStatus();
        return;
    }
    
    const filterStatus = document.getElementById('filterTicketStatus')?.value || '';
    const filterPriority = document.getElementById('filterTicketPriority')?.value || '';
    const filterType = document.getElementById('filterTicketType')?.value || '';
    const filterSubject = document.getElementById('filterTicketSubject')?.value || '';
    const filterRequester = document.getElementById('filterTicketRequester')?.value || '';
    const filterAssignee = document.getElementById('filterTicketAssignee')?.value || '';
    const filterTags = document.getElementById('filterTicketTags')?.value || '';
    const filterCustomFields = document.getElementById('filterTicketCustomFields')?.value || '';
    const filterFunctionality = document.getElementById('filterTicketFunctionality')?.value || '';
    
    let filtered = [...ticketsDataMain.tickets];
    
    // Filtro por estado
    if (filterStatus) {
        filtered = filtered.filter(ticket => ticket.status === filterStatus);
    }
    
    // Filtro por prioridad
    if (filterPriority) {
        filtered = filtered.filter(ticket => ticket.priority === filterPriority);
    }
    
    // Filtro por tipo
    if (filterType) {
        filtered = filtered.filter(ticket => ticket.type === filterType);
    }
    
    // Filtro por asunto
    if (filterSubject) {
        const subjectLower = filterSubject.toLowerCase();
        filtered = filtered.filter(ticket => 
            ticket.subject && ticket.subject.toLowerCase().includes(subjectLower)
        );
    }
    
    // Filtro por solicitante
    if (filterRequester) {
        const requesterLower = filterRequester.toLowerCase();
        filtered = filtered.filter(ticket => 
            ticket.requesterName && ticket.requesterName.toLowerCase().includes(requesterLower)
        );
    }
    
    // Filtro por agente asignado
    if (filterAssignee) {
        const assigneeLower = filterAssignee.toLowerCase();
        filtered = filtered.filter(ticket => 
            ticket.assigneeName && ticket.assigneeName.toLowerCase().includes(assigneeLower)
        );
    }
    
    // Filtro por etiquetas
    if (filterTags) {
        const tagsLower = filterTags.toLowerCase();
        filtered = filtered.filter(ticket => 
            ticket.tags && ticket.tags.some(tag => tag.toLowerCase().includes(tagsLower))
        );
    }
    
    // Filtro por campos personalizados
    if (filterCustomFields) {
        const customFieldsLower = filterCustomFields.toLowerCase();
        filtered = filtered.filter(ticket => {
            if (!ticket.customFieldsUsed || ticket.customFieldsUsed.length === 0) return false;
            return ticket.customFieldsUsed.some(field => 
                field.name.toLowerCase().includes(customFieldsLower) ||
                field.value.toString().toLowerCase().includes(customFieldsLower)
            );
        });
    }
    
    // Filtro por funcionalidad
    if (filterFunctionality) {
        const functionalityLower = filterFunctionality.toLowerCase();
        filtered = filtered.filter(ticket => 
            ticket.functionality && ticket.functionality.toLowerCase().includes(functionalityLower)
        );
    }
    
    // Ordenar por updated_at descendente
    filtered.sort((a, b) => new Date(b.updated_at) - new Date(a.updated_at));
    
    ticketsDataMain.filteredTickets = filtered;
    ticketsDataMain.currentPage = 1;
    ticketsDataMain.totalPages = Math.ceil(filtered.length / ticketsDataMain.itemsPerPage);
    
    console.log(`✅ Filtros aplicados: ${filtered.length} tickets de ${ticketsDataMain.tickets.length} total`);
    console.log('🎨 Llamando renderTicketsTable...');
    
    renderTicketsTable();
    updateTicketPagination();
    updateTicketFilterStatus();
    
    console.log('✅ Proceso de filtros completado');
}

// Limpiar filtros de tickets
function clearTicketFilters() {
    document.getElementById('filterTicketStatus').value = '';
    document.getElementById('filterTicketPriority').value = '';
    document.getElementById('filterTicketType').value = '';
    document.getElementById('filterTicketSubject').value = '';
    document.getElementById('filterTicketRequester').value = '';
    document.getElementById('filterTicketAssignee').value = '';
    document.getElementById('filterTicketTags').value = '';
    document.getElementById('filterTicketCustomFields').value = '';
    document.getElementById('filterTicketFunctionality').value = '';
    
    applyTicketFilters();
}

// Renderizar tabla de tickets dinámicamente
function renderTicketsTable() {
    console.log('🎨 Iniciando renderTicketsTable');
    
    const tableHead = document.getElementById('ticketsTableHead');
    const tableBody = document.getElementById('ticketsMainTableBody');
    const ticketsPage = document.getElementById('tickets-page');
    
    console.log('📋 Elementos DOM encontrados:', { 
        tableHead: !!tableHead, 
        tableBody: !!tableBody,
        ticketsPage: !!ticketsPage,
        pageVisible: ticketsPage ? !ticketsPage.classList.contains('d-none') : false
    });
    
    if (!tableHead || !tableBody) {
        console.error('❌ No se encontraron elementos de tabla:', { tableHead: !!tableHead, tableBody: !!tableBody });
        return;
    }
    
    // Verificar que tenemos columnas dinámicas
    if (!ticketsDataMain.dynamicColumns || ticketsDataMain.dynamicColumns.length === 0) {
        console.error('❌ No hay columnas dinámicas definidas');
        tableBody.innerHTML = `
            <tr>
                <td colspan="20" class="text-center py-4">
                    <div class="text-muted">
                        <i class="fas fa-exclamation-triangle mb-2" style="font-size: 2rem;"></i>
                        <div>Error en la configuración de columnas</div>
                    </div>
                </td>
            </tr>
        `;
        return;
    }
    
    // Generar cabecera dinámica
    const headerHTML = `
        <tr>
            ${ticketsDataMain.dynamicColumns.map(col => `
                <th class="ticket-${col.type}-col" style="min-width: ${col.width};">
                    ${col.title}
                </th>
            `).join('')}
        </tr>
    `;
    tableHead.innerHTML = headerHTML;
    
    // Verificar si hay tickets filtrados
    if (ticketsDataMain.filteredTickets.length === 0) {
        tableBody.innerHTML = `
            <tr>
                <td colspan="${ticketsDataMain.dynamicColumns.length}" class="text-center py-4">
                    <div class="text-muted">
                        <i class="fas fa-search mb-2" style="font-size: 2rem;"></i>
                        <div>No se encontraron tickets con los filtros aplicados</div>
                        <small>Intenta modificar los criterios de búsqueda</small>
                    </div>
                </td>
            </tr>
        `;
        return;
    }
    
    // Generar filas de tickets
    const startIndex = (ticketsDataMain.currentPage - 1) * ticketsDataMain.itemsPerPage;
    const endIndex = startIndex + ticketsDataMain.itemsPerPage;
    const pageItems = ticketsDataMain.filteredTickets.slice(startIndex, endIndex);
    
    console.log(`📊 Renderizando ${pageItems.length} tickets (página ${ticketsDataMain.currentPage})`);
    
    const rows = pageItems.map(ticket => createTicketRow(ticket)).join('');
    
    console.log('🔧 HTML generado:', {
        rowsLength: rows.length,
        rowsPreview: rows.substring(0, 200) + (rows.length > 200 ? '...' : ''),
        pageItemsCount: pageItems.length
    });
    
    tableBody.innerHTML = rows;
    
    console.log(`✅ Tabla actualizada con ${rows.length > 0 ? pageItems.length : 0} filas`);
    console.log('📝 Contenido actual del tbody:', tableBody.innerHTML.substring(0, 300) + '...');
    
    // Actualizar información de paginación
    updateTicketsInfo();
}

// Crear fila de ticket
function createTicketRow(ticket) {
    const isClosed = ticket.status === 'closed';
    const rowClass = isClosed ? 'ticket-closed' : '';
    
    const cells = ticketsDataMain.dynamicColumns.map(col => {
        const content = formatTicketCellContent(ticket, col);
        return `<td class="ticket-${col.type}-col">${content}</td>`;
    }).join('');
    
    return `<tr class="${rowClass}">${cells}</tr>`;
}

// Formatear contenido de celda según tipo
function formatTicketCellContent(ticket, column) {
    const { key, type, fieldId } = column;
    
    switch (type) {
        case 'id':
            return `<a href="https://${window.location.hostname}/agent/tickets/${ticket.id}" target="_blank" class="ticket-link">${ticket.id}</a>`;
            
        case 'subject':
            return `
                <div class="ticket-subject-content" title="${escapeHtml(ticket.subject || 'Sin asunto')}">
                    <a href="https://${window.location.hostname}/agent/tickets/${ticket.id}" target="_blank" class="ticket-link">
                        ${escapeHtml(ticket.subject || 'Sin asunto')}
                    </a>
                </div>
            `;
            
        case 'status':
            return `<span class="ticket-status-badge status-${ticket.status}">${formatTicketStatus(ticket.status)}</span>`;
            
        case 'priority':
            return `<span class="ticket-priority-badge priority-${ticket.priority}">${formatTicketPriority(ticket.priority)}</span>`;
            
        case 'type':
            return `<span class="badge bg-secondary">${formatTicketType(ticket.type)}</span>`;
            
        case 'user':
            if (key === 'requester_id') {
                return formatTicketUser(ticket.requesterName, ticket.requester_id);
            } else if (key === 'assignee_id') {
                return formatTicketUser(ticket.assigneeName, ticket.assignee_id);
            } else if (key === 'submitter_id') {
                return formatTicketUser(ticket.submitterName, ticket.submitter_id);
            }
            return 'N/A';
            
        case 'group':
            return formatTicketGroup(ticket.group_id);
            
        case 'organization':
            return formatTicketOrganization(ticket.organization_id);
            
        case 'brand':
            return formatTicketBrand(ticket.brand_id);
            
        case 'via':
            return formatTicketVia(ticket.via);
            
        case 'satisfaction':
            return formatTicketSatisfaction(ticket.satisfaction_rating);
            
        case 'followers':
            return formatTicketFollowers(ticket.followerNames);
            
        case 'tags':
            return formatTicketTags(ticket.tags);
            
        case 'custom_field':
            const customField = ticket.custom_fields?.find(cf => cf.id.toString() === fieldId);
            return formatTicketCustomField(customField, fieldId);
            
        case 'functionality':
            return `
                <div class="ticket-functionality-content" title="${escapeHtml(ticket.functionality || 'Sin descripción')}">
                    ${escapeHtml(ticket.functionality || 'Sin descripción')}
                </div>
            `;
            
        case 'date':
            return formatTicketDate(ticket[key]);
            
        default:
            return escapeHtml(ticket[key] || 'N/A');
    }
}

// Funciones auxiliares de formateo para tickets
function formatTicketStatus(status) {
    const statusMap = {
        'new': 'Nuevo',
        'open': 'Abierto',
        'pending': 'Pendiente',
        'solved': 'Resuelto',
        'closed': 'Cerrado'
    };
    return statusMap[status] || status;
}

function formatTicketPriority(priority) {
    const priorityMap = {
        'urgent': 'Urgente',
        'high': 'Alta',
        'normal': 'Normal',
        'low': 'Baja'
    };
    return priorityMap[priority] || priority;
}

function formatTicketType(type) {
    const typeMap = {
        'question': 'Pregunta',
        'incident': 'Incidente',
        'problem': 'Problema',
        'task': 'Tarea'
    };
    return typeMap[type] || type || 'Ticket';
}

function formatTicketUser(userName, userId) {
    if (!userName || userName === 'Sin asignar') {
        return '<em style="color: #6c757d;">Sin asignar</em>';
    }
    
    return `
        <div class="ticket-user" title="ID: ${userId}">
            ${escapeHtml(userName)}
        </div>
    `;
}

function formatTicketFollowers(followerNames) {
    if (!followerNames || followerNames.length === 0) {
        return '<em style="color: #6c757d;">Sin seguidores</em>';
    }
    
    const displayNames = followerNames.slice(0, 2);
    const html = displayNames.map(name => 
        `<span class="ticket-follower">${escapeHtml(name)}</span>`
    ).join('');
    
    if (followerNames.length > 2) {
        return html + `<span class="ticket-follower">+${followerNames.length - 2} más</span>`;
    }
    
    return html;
}

function formatTicketTags(tags) {
    if (!tags || tags.length === 0) {
        return '<em style="color: #6c757d;">Sin etiquetas</em>';
    }
    
    const displayTags = tags.slice(0, 3);
    const html = displayTags.map(tag => 
        `<span class="ticket-tag">${escapeHtml(tag)}</span>`
    ).join('');
    
    if (tags.length > 3) {
        return html + `<span class="ticket-tag">+${tags.length - 3} más</span>`;
    }
    
    return html;
}

function formatTicketCustomField(customField, fieldId) {
    if (!customField || !customField.value) {
        return '<em style="color: #6c757d;">Sin valor</em>';
    }
    
    const fieldInfo = ticketsDataMain.customFieldsMap.get(fieldId);
    const fieldName = fieldInfo ? fieldInfo.title : `Campo ${fieldId}`;
    
    return `
        <div class="ticket-custom-field" title="${escapeHtml(fieldName)}: ${escapeHtml(customField.value)}">
            <span class="ticket-custom-field-name">${escapeHtml(fieldName)}:</span>
            <span class="ticket-custom-field-value">${escapeHtml(customField.value)}</span>
        </div>
    `;
}

function formatTicketDate(dateString) {
    if (!dateString) return 'N/A';
    
    try {
        const date = new Date(dateString);
        const now = new Date();
        const diffTime = Math.abs(now - date);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        
        const formattedDate = date.toLocaleDateString('es-ES', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
        
        const formattedTime = date.toLocaleTimeString('es-ES', {
            hour: '2-digit',
            minute: '2-digit'
        });
        
        let timeAgo = '';
        if (diffDays === 0) {
            timeAgo = ' (hoy)';
        } else if (diffDays === 1) {
            timeAgo = ' (ayer)';
        } else if (diffDays <= 7) {
            timeAgo = ` (${diffDays}d)`;
        } else if (diffDays <= 30) {
            const weeks = Math.floor(diffDays / 7);
            timeAgo = ` (${weeks}sem)`;
        } else if (diffDays <= 365) {
            const months = Math.floor(diffDays / 30);
            timeAgo = ` (${months}m)`;
        }
        
        return `${formattedDate}<br><small style="color: #6c757d;">${formattedTime}${timeAgo}</small>`;
    } catch (error) {
        return 'Fecha inválida';
    }
}

// Funciones de formateo para nuevos tipos de campos
function formatTicketGroup(groupId) {
    if (!groupId) return '<em style="color: #6c757d;">Sin grupo</em>';
    
    // Aquí podrías implementar un cache de grupos si es necesario
    return `<span class="badge bg-info text-dark">Grupo ${groupId}</span>`;
}

function formatTicketOrganization(organizationId) {
    if (!organizationId) return '<em style="color: #6c757d;">Sin organización</em>';
    
    // Aquí podrías implementar un cache de organizaciones si es necesario
    return `<span class="badge bg-warning text-dark">Org ${organizationId}</span>`;
}

function formatTicketBrand(brandId) {
    if (!brandId) return '<em style="color: #6c757d;">Sin marca</em>';
    
    return `<span class="badge bg-primary">Marca ${brandId}</span>`;
}

function formatTicketVia(via) {
    if (!via || !via.channel) return '<em style="color: #6c757d;">Desconocido</em>';
    
    const channelIcons = {
        'web': '🌐',
        'email': '📧',
        'phone': '📞',
        'chat': '💬',
        'api': '🔧',
        'mobile': '📱',
        'facebook': '📘',
        'twitter': '🐦'
    };
    
    const icon = channelIcons[via.channel] || '📄';
    const channelName = via.channel.charAt(0).toUpperCase() + via.channel.slice(1);
    
    return `<span class="badge bg-secondary" title="Canal: ${channelName}">${icon} ${channelName}</span>`;
}

function formatTicketSatisfaction(satisfaction) {
    if (!satisfaction || !satisfaction.score) {
        return '<em style="color: #6c757d;">Sin calificar</em>';
    }
    
    const score = satisfaction.score;
    const comment = satisfaction.comment;
    
    let badgeClass = 'bg-secondary';
    let emoji = '❓';
    
    if (score === 'good') {
        badgeClass = 'bg-success';
        emoji = '😊';
    } else if (score === 'bad') {
        badgeClass = 'bg-danger';
        emoji = '😞';
    }
    
    const title = comment ? `${score.toUpperCase()}: ${comment}` : score.toUpperCase();
    
    return `<span class="badge ${badgeClass}" title="${escapeHtml(title)}">${emoji} ${score.charAt(0).toUpperCase() + score.slice(1)}</span>`;
}

// Estados de carga y actualización para tickets
function showTicketsLoadingState() {
    const tableBody = document.getElementById('ticketsMainTableBody');
    const counter = document.getElementById('ticketsCounter');
    
    if (tableBody) {
        tableBody.innerHTML = `
            <tr>
                <td colspan="20" class="text-center py-5">
                    <div class="d-flex flex-column align-items-center">
                        <div class="spinner-border text-primary mb-3" role="status">
                            <span class="sr-only">Cargando...</span>
                        </div>
                        <div class="text-muted">Cargando tickets desde Zendesk...</div>
                        <small class="text-muted mt-2">Esto puede tardar unos minutos</small>
                    </div>
                </td>
            </tr>
        `;
    }
    
    if (counter) {
        counter.textContent = 'Cargando...';
        counter.className = 'badge bg-secondary fs-6';
    }
}

function showTicketsErrorState(error) {
    const tableBody = document.getElementById('ticketsMainTableBody');
    const counter = document.getElementById('ticketsCounter');
    
    if (tableBody) {
        tableBody.innerHTML = `
            <tr>
                <td colspan="20" class="text-center py-5">
                    <div class="d-flex flex-column align-items-center">
                        <i class="fas fa-exclamation-triangle text-danger mb-3" style="font-size: 2rem;"></i>
                        <div class="text-danger mb-2">Error al cargar tickets</div>
                        <small class="text-muted">${escapeHtml(error.message || 'Error desconocido')}</small>
                        <button onclick="loadTicketsData(true)" class="btn btn-primary btn-sm mt-3">
                            <i class="fas fa-retry"></i> Reintentar
                        </button>
                    </div>
                </td>
            </tr>
        `;
    }
    
    if (counter) {
        counter.textContent = 'Error';
        counter.className = 'badge bg-danger fs-6';
    }
}

function updateTicketsCounter() {
    const counter = document.getElementById('ticketsCounter');
    console.log('🔢 Actualizando contador de tickets:', !!counter);
    
    if (counter) {
        const total = ticketsDataMain.tickets.length;
        const closed = ticketsDataMain.tickets.filter(t => t.status === 'closed').length;
        const active = total - closed;
        
        counter.innerHTML = `
            <span title="Total: ${total} | Activos: ${active} | Cerrados: ${closed}">
                ${total} tickets
            </span>
        `;
        counter.className = 'badge bg-primary fs-6';
        
        console.log(`✅ Contador actualizado: ${total} tickets total`);
    } else {
        console.error('❌ No se encontró elemento ticketsCounter');
    }
}

function updateTicketsInfo() {
    const info = document.getElementById('ticketsMainInfo');
    if (info) {
        const start = (ticketsDataMain.currentPage - 1) * ticketsDataMain.itemsPerPage + 1;
        const end = Math.min(start + ticketsDataMain.itemsPerPage - 1, ticketsDataMain.filteredTickets.length);
        const total = ticketsDataMain.filteredTickets.length;
        
        info.textContent = `Mostrando ${start}-${end} de ${total} tickets`;
    }
}

function updateTicketFilterStatus() {
    const status = document.getElementById('ticketFilterStatus');
    if (status) {
        const total = ticketsDataMain.tickets.length;
        const filtered = ticketsDataMain.filteredTickets.length;
        
        if (filtered === total) {
            status.textContent = 'Mostrando todos los tickets';
        } else {
            status.textContent = `Mostrando ${filtered} de ${total} tickets (filtrados)`;
        }
    }
}

function updateTicketPagination() {
    const pagination = document.getElementById('ticketsMainPagination');
    if (!pagination) return;
    
    const totalPages = ticketsDataMain.totalPages;
    const currentPage = ticketsDataMain.currentPage;
    
    if (totalPages <= 1) {
        pagination.innerHTML = '';
        return;
    }
    
    let paginationHTML = '';
    
    // Botón anterior
    paginationHTML += `
        <li class="page-item ${currentPage === 1 ? 'disabled' : ''}">
            <a class="page-link" href="#" onclick="changeTicketPage(${currentPage - 1})" tabindex="-1">Anterior</a>
        </li>
    `;
    
    // Páginas
    const startPage = Math.max(1, currentPage - 2);
    const endPage = Math.min(totalPages, currentPage + 2);
    
    if (startPage > 1) {
        paginationHTML += `<li class="page-item"><a class="page-link" href="#" onclick="changeTicketPage(1)">1</a></li>`;
        if (startPage > 2) {
            paginationHTML += `<li class="page-item disabled"><span class="page-link">...</span></li>`;
        }
    }
    
    for (let i = startPage; i <= endPage; i++) {
        paginationHTML += `
            <li class="page-item ${i === currentPage ? 'active' : ''}">
                <a class="page-link" href="#" onclick="changeTicketPage(${i})">${i}</a>
            </li>
        `;
    }
    
    if (endPage < totalPages) {
        if (endPage < totalPages - 1) {
            paginationHTML += `<li class="page-item disabled"><span class="page-link">...</span></li>`;
        }
        paginationHTML += `<li class="page-item"><a class="page-link" href="#" onclick="changeTicketPage(${totalPages})">${totalPages}</a></li>`;
    }
    
    // Botón siguiente
    paginationHTML += `
        <li class="page-item ${currentPage === totalPages ? 'disabled' : ''}">
            <a class="page-link" href="#" onclick="changeTicketPage(${currentPage + 1})">Siguiente</a>
        </li>
    `;
    
    pagination.innerHTML = paginationHTML;
}

function changeTicketPage(page) {
    if (page < 1 || page > ticketsDataMain.totalPages) return;
    
    ticketsDataMain.currentPage = page;
    renderTicketsTable();
    updateTicketPagination();
    
    // Scroll to top
    document.querySelector('#ticketsMainTable').scrollIntoView({ 
        behavior: 'smooth', 
        block: 'start' 
    });
}

function populateTicketTypeFilter() {
    const typeFilter = document.getElementById('filterTicketType');
    console.log('🎯 Poblando filtro de tipos:', !!typeFilter);
    
    if (!typeFilter) {
        console.error('❌ No se encontró elemento filterTicketType');
        return;
    }
    
    const types = new Set();
    if (ticketsDataMain.tickets && Array.isArray(ticketsDataMain.tickets)) {
        ticketsDataMain.tickets.forEach(ticket => {
            if (ticket.type) {
                types.add(ticket.type);
            }
        });
    }
    
    // Limpiar opciones existentes (excepto "Todos")
    typeFilter.innerHTML = '<option value="">Todos</option>';
    
    // Agregar tipos encontrados
    Array.from(types).sort().forEach(type => {
        const option = document.createElement('option');
        option.value = type;
        option.textContent = formatTicketType(type);
        typeFilter.appendChild(option);
    });
    
    console.log(`✅ Filtro de tipos poblado con ${types.size} tipos`);
}

function exportTicketsToExcel() {
    if (ticketsDataMain.filteredTickets.length === 0) {
        alert('No hay tickets para exportar');
        return;
    }
    
    try {
        const wb = XLSX.utils.book_new();
        
        // Preparar datos para la hoja principal
        const ticketsForExport = ticketsDataMain.filteredTickets.map(ticket => {
            const row = {};
            
            ticketsDataMain.dynamicColumns.forEach(col => {
                let value = '';
                
                switch (col.type) {
                    case 'id':
                        value = ticket.id;
                        break;
                    case 'subject':
                        value = ticket.subject || 'Sin asunto';
                        break;
                    case 'status':
                        value = formatTicketStatus(ticket.status);
                        break;
                    case 'priority':
                        value = formatTicketPriority(ticket.priority);
                        break;
                    case 'type':
                        value = formatTicketType(ticket.type);
                        break;
                    case 'user':
                        if (col.key === 'requester_id') {
                            value = ticket.requesterName || 'Sin asignar';
                        } else if (col.key === 'assignee_id') {
                            value = ticket.assigneeName || 'Sin asignar';
                        }
                        break;
                    case 'followers':
                        value = ticket.followerNames ? ticket.followerNames.join(', ') : 'Sin seguidores';
                        break;
                    case 'tags':
                        value = ticket.tags ? ticket.tags.join(', ') : 'Sin etiquetas';
                        break;
                    case 'custom_field':
                        const customField = ticket.custom_fields?.find(cf => cf.id.toString() === col.fieldId);
                        value = customField ? customField.value : 'Sin valor';
                        break;
                    case 'group':
                        value = ticket.group_id ? `Grupo ${ticket.group_id}` : 'Sin grupo';
                        break;
                    case 'organization':
                        value = ticket.organization_id ? `Organización ${ticket.organization_id}` : 'Sin organización';
                        break;
                    case 'brand':
                        value = ticket.brand_id ? `Marca ${ticket.brand_id}` : 'Sin marca';
                        break;
                    case 'via':
                        value = ticket.via?.channel ? ticket.via.channel.charAt(0).toUpperCase() + ticket.via.channel.slice(1) : 'Desconocido';
                        break;
                    case 'satisfaction':
                        value = ticket.satisfaction_rating?.score ? ticket.satisfaction_rating.score.charAt(0).toUpperCase() + ticket.satisfaction_rating.score.slice(1) : 'Sin calificar';
                        break;
                    case 'functionality':
                        value = ticket.functionality || 'Sin descripción';
                        break;
                    case 'date':
                        value = ticket[col.key] ? new Date(ticket[col.key]).toLocaleString('es-ES') : 'N/A';
                        break;
                    default:
                        value = ticket[col.key] || 'N/A';
                }
                
                row[col.title] = value;
            });
            
            return row;
        });
        
        // Crear hoja principal
        const ws = XLSX.utils.json_to_sheet(ticketsForExport);
        XLSX.utils.book_append_sheet(wb, ws, "Todos los Tickets");
        
        // Crear hoja de resumen
        const summary = generateTicketsSummary();
        const summaryWs = XLSX.utils.json_to_sheet(summary);
        XLSX.utils.book_append_sheet(wb, summaryWs, "Resumen");
        
        // Generar archivo
        const timestamp = new Date().toISOString().slice(0, 19).replace(/:/g, '-');
        const fileName = `tickets_zendesk_${timestamp}.xlsx`;
        
        XLSX.writeFile(wb, fileName);
        
        showExportSuccessMessage(fileName, ticketsDataMain.filteredTickets.length);
        
    } catch (error) {
        console.error('Error exportando tickets:', error);
        alert('Error al exportar tickets. Inténtalo nuevamente.');
    }
}

function generateTicketsSummary() {
    const total = ticketsDataMain.tickets.length;
    const filtered = ticketsDataMain.filteredTickets.length;
    
    // Estadísticas por estado
    const statusStats = {};
    ticketsDataMain.tickets.forEach(ticket => {
        const status = formatTicketStatus(ticket.status);
        statusStats[status] = (statusStats[status] || 0) + 1;
    });
    
    // Estadísticas por prioridad
    const priorityStats = {};
    ticketsDataMain.tickets.forEach(ticket => {
        const priority = formatTicketPriority(ticket.priority);
        priorityStats[priority] = (priorityStats[priority] || 0) + 1;
    });
    
    // Estadísticas por tipo
    const typeStats = {};
    ticketsDataMain.tickets.forEach(ticket => {
        const type = formatTicketType(ticket.type);
        typeStats[type] = (typeStats[type] || 0) + 1;
    });
    
    const summary = [
        { 'Métrica': 'Total de Tickets', 'Valor': total },
        { 'Métrica': 'Tickets Mostrados', 'Valor': filtered },
        { 'Métrica': 'Fecha de Exportación', 'Valor': new Date().toLocaleString('es-ES') },
        { 'Métrica': '', 'Valor': '' },
        { 'Métrica': '=== ESTADÍSTICAS POR ESTADO ===', 'Valor': '' }
    ];
    
    Object.entries(statusStats).forEach(([status, count]) => {
        summary.push({
            'Métrica': status,
            'Valor': `${count} (${((count / total) * 100).toFixed(1)}%)`
        });
    });
    
    summary.push({ 'Métrica': '', 'Valor': '' });
    summary.push({ 'Métrica': '=== ESTADÍSTICAS POR PRIORIDAD ===', 'Valor': '' });
    
    Object.entries(priorityStats).forEach(([priority, count]) => {
        summary.push({
            'Métrica': priority,
            'Valor': `${count} (${((count / total) * 100).toFixed(1)}%)`
        });
    });
    
    summary.push({ 'Métrica': '', 'Valor': '' });
    summary.push({ 'Métrica': '=== ESTADÍSTICAS POR TIPO ===', 'Valor': '' });
    
    Object.entries(typeStats).forEach(([type, count]) => {
        summary.push({
            'Métrica': type,
            'Valor': `${count} (${((count / total) * 100).toFixed(1)}%)`
        });
    });
    
    return summary;
}

// Funciones globales para la página de tickets
window.changeTicketPage = changeTicketPage;
window.loadTicketsData = loadTicketsData;

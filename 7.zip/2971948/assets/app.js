const client = ZAFClient.init();
let ticketsPlot = null;
let updateIntervalId = null; // Variable para almacenar el ID del intervalo de actualización

// Configuración de fechas por defecto
function setDefaultDates() {
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - 30);
    
    document.getElementById('startDate').value = startDate.toISOString().split('T')[0];
    document.getElementById('endDate').value = endDate.toISOString().split('T')[0];
}

// Función para alternar el modo oscuro
function toggleDarkMode() {
    document.body.classList.toggle('dark-mode');
    const isDarkMode = document.body.classList.contains('dark-mode');
    localStorage.setItem('darkMode', isDarkMode);
}

// Función para controlar la sincronización automática
function togglePeriodicUpdates() {
    const syncToggleButton = document.getElementById('syncToggle');
    if (updateIntervalId) {
        clearInterval(updateIntervalId);
        updateIntervalId = null;
        syncToggleButton.textContent = 'Iniciar Sincronización';
        console.log('Sincronización automática detenida.');
    } else {
        startPeriodicUpdates();
        syncToggleButton.textContent = 'Parar Sincronización';
        console.log('Sincronización automática iniciada.');
    }
}

// Inicializar la aplicación
async function init() {
    try {
        setDefaultDates();
        // Aplicar modo oscuro si estaba guardado
        if (localStorage.getItem('darkMode') === 'true') {
            document.body.classList.add('dark-mode');
        }
        await updateDashboard();
        // Esperar a que el DOM esté listo antes de inicializar el gráfico
        if (document.getElementById('realtimeTrend')) {
            initTicketsPlot();
            startPeriodicUpdates(); // Iniciar sincronización al inicio
            document.getElementById('syncToggle').textContent = 'Parar Sincronización'; // Establecer texto inicial del botón
        }

        // Event listener para el botón de modo oscuro
        const darkModeToggleButton = document.getElementById('darkModeToggle');
        if (darkModeToggleButton) {
            darkModeToggleButton.addEventListener('click', toggleDarkMode);
        }

        // Event listener para el botón de sincronización
        const syncToggleButton = document.getElementById('syncToggle');
        if (syncToggleButton) {
            syncToggleButton.addEventListener('click', togglePeriodicUpdates);
        }

    } catch (error) {
        console.error('Error al inicializar la aplicación:', error);
    }
}

document.addEventListener('DOMContentLoaded', init);

// Inicializar gráfico de tickets
function initTicketsPlot() {
    const container = document.getElementById('realtimeTrend');
    if (!container) {
        console.error('No se encontró el contenedor del gráfico');
        return;
    }

    const opts = {
        width: container.offsetWidth,
        height: 300,
        title: "Tickets por Hora",
        cursor: {
            show: true,
            sync: {
                key: "ticketSync"
            }
        },
        scales: {
            x: {
                time: true,
            },
            y: {
                auto: true,
            }
        },
        axes: [
            {
                stroke: "#03363d",
                grid: { show: true, stroke: "#d8dcde" },
                ticks: { show: true, stroke: "#03363d" },
                font: "12px Arial",
                // Formatear el eje X para mostrar la fecha y hora en la zona horaria de Ecuador
                values: (self, splits) => splits.map(s => {
                    const date = new Date(s * 1000);
                    return new Intl.DateTimeFormat('es-EC', {
                        month: 'short',
                        day: 'numeric',
                        timeZone: 'America/Guayaquil'
                    }).format(date);
                }),
            },
            {
                stroke: "#03363d",
                grid: { show: true, stroke: "#d8dcde" },
                ticks: { show: true, stroke: "#03363d" },
                font: "12px Arial",
            }
        ],
        series: [
            {}, // Serie para el eje X
            {
                stroke: "#03363d",
                width: 2,
                fill: "rgba(3, 54, 61, 0.1)",
                label: "Tickets reales", // Línea azul
            },
            {
                label: "Límite superior",
                stroke: "gold",
                width: 2,
                dash: [1, 5], // Línea punteada amarilla
            }
        ]
    };

    ticketsPlot = new uPlot(opts, [[], []], container);
}

// Obtener tickets de Zendesk
async function getTickets() {
    try {
        const response = await client.request({
            url: '/api/v2/tickets.json',
            type: 'GET',
            contentType: 'application/json',
            headers: {
                'Accept': 'application/json'
            }
        });
        return response.tickets || [];
    } catch (error) {
        console.error('Error al obtener tickets:', error);
        return [];
    }
}

// Actualizar datos del gráfico
async function updateTicketsData() {
    try {
        const startDate = document.getElementById('startDate').value;
        const endDate = document.getElementById('endDate').value;
        
        const tickets = await getTickets();
        const currentTickets = tickets.filter(ticket => {
            const ticketDate = new Date(ticket.created_at);
            return ticketDate >= new Date(startDate) && ticketDate <= new Date(endDate + 'T23:59:59');
        });
        
        const hourlyData = {};
        currentTickets.forEach(ticket => {
            const date = new Date(ticket.created_at);
            const hourKey = date.toISOString().slice(0, 13);
            hourlyData[hourKey] = (hourlyData[hourKey] || 0) + 1;
        });

        // Generar timestamps para el rango de fechas seleccionado y datos para las bandas
        const timestamps = [];
        const values = [];
        const superiorLimitValues = [];

        const start = new Date(startDate);
        const end = new Date(endDate + 'T23:59:59');
        
        // Valores constantes para las bandas
        const SUPERIOR_LIMIT_VALUE = 12;

        for (let d = new Date(start); d <= end; d.setHours(d.getHours() + 1)) {
            const hourKey = d.toISOString().slice(0, 13);
            timestamps.push(d.getTime() / 1000); // uPlot espera segundos
            values.push(hourlyData[hourKey] || 0);
            superiorLimitValues.push(SUPERIOR_LIMIT_VALUE);
        }

        if (ticketsPlot) {
            ticketsPlot.setData([
                timestamps, 
                values, 
                superiorLimitValues
            ]);
        }
    } catch (error) {
        console.error('Error al actualizar datos del gráfico:', error);
    }
}

// Iniciar actualizaciones periódicas
function startPeriodicUpdates() {
    updateTicketsData();
    // Limpiar cualquier intervalo existente antes de iniciar uno nuevo
    if (updateIntervalId) {
        clearInterval(updateIntervalId);
    }
    // Actualizar cada 5 minutos (300000 ms)
    updateIntervalId = setInterval(updateTicketsData, 300000);
}

// Actualizar el dashboard
async function updateDashboard() {
    try {
        const startDate = document.getElementById('startDate').value;
        const endDate = document.getElementById('endDate').value;
        
        const tickets = await getTickets();
        const filteredTickets = tickets.filter(ticket => {
            const ticketDate = new Date(ticket.created_at);
            return ticketDate >= new Date(startDate) && ticketDate <= new Date(endDate + 'T23:59:59');
        });
        
        const data = analyzeTickets(filteredTickets);
        updateMetrics(data);
    } catch (error) {
        console.error('Error al actualizar el dashboard:', error);
    }
}

// Analizar tickets
function analyzeTickets(tickets) {
    const today = new Date().toISOString().split('T')[0];
    const totalTickets = tickets.length;
    const ticketsToday = tickets.filter(t => t.created_at.startsWith(today)).length;
    const pendingTickets = tickets.filter(t => t.status === 'pending').length;
    const resolvedTickets = tickets.filter(t => t.status === 'solved').length;
    const resolutionRate = totalTickets > 0 ? (resolvedTickets / totalTickets * 100).toFixed(1) : 0;

    return {
        totalTickets,
        ticketsToday,
        pendingTickets,
        resolutionRate
    };
}

// Actualizar métricas
function updateMetrics(data) {
    document.getElementById('total-tickets').textContent = data.totalTickets;
    document.getElementById('tickets-hoy').textContent = data.ticketsToday;
    document.getElementById('tickets-pendientes').textContent = data.pendingTickets;
    document.getElementById('tasa-resolucion').textContent = `${data.resolutionRate}%`;
}

// Event listener para el botón de filtro
document.getElementById('applyFilter').addEventListener('click', async () => {
    const startDate = document.getElementById('startDate').value;
    const endDate = document.getElementById('endDate').value;
    
    if (!startDate || !endDate || new Date(startDate) > new Date(endDate)) {
        document.getElementById('date-filter-alert').classList.remove('d-none');
        return;
    }
    
    document.getElementById('date-filter-alert').classList.add('d-none');
    await Promise.all([updateDashboard(), updateTicketsData()]);
});